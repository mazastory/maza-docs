// background.js

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "START_TISTORY_SETUP") {
    const { domain, searchConsoleTag, gaTrackingId, adsensePubId } = request.payload;
    console.log("[Background] Starting Tistory setup for", domain);

    // Parse the blog name from the domain (e.g., myblog.tistory.com -> myblog)
    const blogName = domain.split(".")[0];
    const tistoryEditUrl = `https://${blogName}.tistory.com/manage/design/skin/edit`;

    // Create a new tab to edit the skin
    chrome.tabs.create({ url: tistoryEditUrl, active: true }, (tab) => {
      // Store the payload so the content script can retrieve it
      chrome.storage.local.set({
        tistorySetupPayload: {
          searchConsoleTag,
          gaTrackingId,
          adsensePubId,
          tabId: tab.id
        }
      }, () => {
        sendResponse({ status: "STARTED", message: "티스토리 스킨 편집 창을 열었습니다." });
      });
    });

    return true;
  }

  if (request.action === "START_TISTORY_POST") {
    const { platform, title, content, domain } = request.payload;
    console.log("[Background] Starting Tistory post for", domain);

    const blogName = domain ? domain.split(".")[0] : "www";
    const tistoryWriteUrl = `https://${blogName}.tistory.com/manage/post/write`;

    chrome.tabs.create({ url: tistoryWriteUrl, active: true }, (tab) => {
      chrome.storage.local.set({
        tistoryPostPayload: {
          title,
          content,
          tabId: tab.id
        }
      }, () => {
        sendResponse({ status: "STARTED", message: "티스토리 글쓰기 창을 열었습니다." });
      });
    });
    return true;
  }
});
