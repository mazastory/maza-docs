# MAZA Studio - Chrome Web Store 등록 정보

## 기본 정보

- **이름**: MAZA Studio - 애드센스 챌린지 도우미
- **요약** (132자 이내):
  AI가 생성한 고품질 블로그 콘텐츠를 티스토리에 1클릭으로 발행하는 애드센스 승인 챌린지 도우미

- **카테고리**: Productivity (생산성)
- **언어**: 한국어

---

## 상세 설명 (Web Store 등록용)

```
마자 스튜디오(MAZA Studio)와 함께 20일 애드센스 승인 챌린지를 완수하세요!

🚀 주요 기능

• AI 글 1클릭 발행 — 마자 스튜디오에서 생성된 고품질 콘텐츠를 티스토리 에디터에 자동 주입
• 발행 대기열 확인 — 팝업 창에서 오늘 발행할 글 목록을 한눈에 확인
• 자동 URL 보고 — 발행 완료 시 URL을 자동 감지하여 챌린지 진행률에 반영
• 알림 기능 — 새 콘텐츠가 준비되면 알림으로 안내

📋 사용 방법

1. 마자 스튜디오(mazastudio.kr)에 로그인
2. AI Writer로 고품질 블로그 글 생성
3. 익스텐션 아이콘 클릭 → 발행할 글 선택
4. 티스토리 에디터에서 "MAZA 콘텐츠 불러오기" 버튼 클릭
5. 제목과 본문이 자동 입력 → 검토 후 발행!

✅ 지원 플랫폼

• 티스토리 (tistory.com)
• 네이버 블로그 (blog.naver.com) — 지원 예정

🔒 개인정보 보호

• 브라우징 기록 수집 없음
• 마자 스튜디오 로그인 세션만 사용
• 언제든 로그아웃으로 데이터 삭제 가능

애드센스 승인까지, 마자 스튜디오가 함께합니다.
```

---

## Chrome Web Store 제출 체크리스트

- [x] manifest.json (MV3)
- [x] 아이콘 16px, 48px, 128px
- [x] 스크린샷 1280x800 × 2장 (store/screenshot1.png, screenshot2.png)
- [x] 개인정보처리방침 URL 필요 → store/privacy-policy.html 호스팅 필요
- [x] 카테고리: Productivity
- [x] 설명문 작성 완료
- [ ] 개발자 계정 $5 등록: https://chrome.google.com/webstore/devconsole
- [ ] privacy-policy.html을 공개 URL에 업로드 (예: mazastudio.kr/privacy-extension)
- [ ] maza-extension.zip 업로드

---

## 패키징 명령어

```bash
cd /Users/m/Downloads/adsense-challenge
zip -r maza-extension.zip extension/ \
  --exclude "extension/store/*" \
  --exclude "extension/.DS_Store" \
  --exclude "*/.DS_Store"
```
