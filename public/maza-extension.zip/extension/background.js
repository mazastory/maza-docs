/**
 * =============================================
 * MAZA Studio Chrome Extension - Background Service Worker
 * 마자 스튜디오 서버와 통신하는 핵심 브릿지
 * =============================================
 */

const MAZA_SERVER = 'http://localhost:3001';
const POLL_INTERVAL_MS = 30 * 1000; // 30초마다 새 콘텐츠 확인

// ─── 저장소 관리 ─────────────────────────────────────────────────

async function getAuthToken() {
  const data = await chrome.storage.local.get(['maza_token', 'maza_user_id']);
  return { token: data.maza_token, userId: data.maza_user_id };
}

async function setAuth(token, userId) {
  await chrome.storage.local.set({ maza_token: token, maza_user_id: userId });
}

// ─── 서버 통신 ───────────────────────────────────────────────────

async function fetchPendingPosts() {
  const { token, userId } = await getAuthToken();
  if (!token || !userId) return [];

  try {
    const res = await fetch(`${MAZA_SERVER}/api/extension/pending-posts?user_id=${userId}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) return [];
    const data = await res.json();
    return data.posts || [];
  } catch (e) {
    console.warn('[MAZA BG] fetchPendingPosts failed:', e);
    return [];
  }
}

async function markPublished(postId, publishedUrl) {
  const { token, userId } = await getAuthToken();
  if (!token) return;

  try {
    await fetch(`${MAZA_SERVER}/api/extension/mark-published`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ post_id: postId, published_url: publishedUrl, user_id: userId })
    });
  } catch (e) {
    console.warn('[MAZA BG] markPublished failed:', e);
  }
}

// ─── 배지 업데이트 ───────────────────────────────────────────────

async function updateBadge() {
  const posts = await fetchPendingPosts();
  const count = posts.length;

  await chrome.storage.local.set({ pending_posts: posts });

  if (count > 0) {
    chrome.action.setBadgeText({ text: String(count) });
    chrome.action.setBadgeBackgroundColor({ color: '#2563EB' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }

  return posts;
}

// ─── 알림 ────────────────────────────────────────────────────────

function showNotification(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon48.png',
    title: `MAZA Studio - ${title}`,
    message
  });
}

// ─── 폴링 시작 ───────────────────────────────────────────────────

async function startPolling() {
  const posts = await updateBadge();
  
  if (posts.length > 0) {
    showNotification('새 콘텐츠 준비됨', `${posts.length}개의 글이 발행 대기 중입니다.`);
  }
}

function schedulePolling() {
  chrome.alarms.create('maza_poll_alarm', { periodInMinutes: 0.5 });
  startPolling();
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'maza_poll_alarm') {
    startPolling();
  }
});

// ─── 메시지 핸들러 (팝업 ↔ 백그라운드 ↔ 컨텐츠 스크립트) ─────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_PENDING_POSTS') {
    chrome.storage.local.get(['pending_posts'], (data) => {
      sendResponse({ posts: data.pending_posts || [] });
    });
    return true; // 비동기 응답
  }

  if (message.type === 'INJECT_POST') {
    // 현재 활성 탭에 콘텐츠 주입 명령
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: 'INJECT_CONTENT',
          post: message.post
        });
        sendResponse({ success: true });
      }
    });
    return true;
  }

  if (message.type === 'OPEN_TISTORY') {
    // 티스토리 글쓰기 페이지 열기
    const blogName = message.blogName || '';
    chrome.tabs.create({
      url: `https://${blogName}.tistory.com/manage/newpost`
    });
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'MARK_PUBLISHED') {
    markPublished(message.postId, message.publishedUrl).then(() => {
      updateBadge();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'DELETE_POST') {
    (async () => {
      const { token, userId } = await getAuthToken();
      if (!token || !userId) return sendResponse({ success: false });

      try {
        const res = await fetch(`${MAZA_SERVER}/api/extension/delete-post`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ post_id: message.postId, user_id: userId })
        });
        
        if (res.ok) {
          await updateBadge();
          sendResponse({ success: true });
        } else {
          sendResponse({ success: false });
        }
      } catch (e) {
        sendResponse({ success: false });
      }
    })();
    return true;
  }

  if (message.type === 'DIRECT_INJECT' || message.type === 'PUBLISH_POST') {
    // 자동발행 요청 수신 (Zero-Click AutoPilot)
    // 1. Storage에 임시 저장
    chrome.storage.local.set({ direct_inject_post: message.payload }, () => {
      // 2. 새 탭 열기 (티스토리 에디터)
      chrome.tabs.create({ url: 'https://www.tistory.com/manage/newpost' });
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.action === "START_TISTORY_SETUP" || message.type === "START_TISTORY_SETUP" || message.type === 'SETUP_INFRA') {
    const payload = message.payload;
    let blogName = payload.domain || 'www';
    
    // 도메인 형식 정규화 (zerowork.tistory.com -> zerowork)
    if (blogName.includes('.tistory.com')) {
      blogName = blogName.split('.')[0];
    }
    
    if (blogName === 'www' || !blogName) {
      alert("도메인 정보가 정확하지 않습니다. 마자 스튜디오 Setup 페이지에서 도메인을 입력하고 저장해 주세요.");
      return true;
    }

    const tistoryEditUrl = `https://${blogName}.tistory.com/manage/design/skin/edit`;
    console.log("[MAZA] Opening Tistory Edit URL:", tistoryEditUrl);

    chrome.tabs.create({ url: tistoryEditUrl, active: true }, (tab) => {
      // Wait for tab to load, then execute script
      const onTabUpdate = (tabId, info) => {
        if (tabId === tab.id && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(onTabUpdate);
          
          // Inject into the page context (MAIN world) to access CodeMirror
          chrome.scripting.executeScript({
            target: { tabId: tab.id },
            world: 'MAIN',
            func: (scTag, gaId) => {
              console.log("MazaStudio: Automation v4 started (Monaco Support)");
              let htmlEditClicked = false;
              let retryCount = 0;
              
              const setupAutomation = setInterval(() => {
                // 1. 에디터 감지 (Monaco or CodeMirror)
                const monacoEditor = window.monaco && window.monaco.editor;
                const codeMirrorElement = document.querySelector('.CodeMirror');
                
                let editorType = "";
                let editorInstance = null;

                if (monacoEditor && monacoEditor.getModels().length > 0) {
                  editorType = "monaco";
                  editorInstance = monacoEditor.getModels()[0];
                } else if (codeMirrorElement && codeMirrorElement.CodeMirror) {
                  editorType = "codemirror";
                  editorInstance = codeMirrorElement.CodeMirror;
                }

                // 에디터가 발견되면 주입 시도
                if (editorType && editorInstance) {
                  clearInterval(setupAutomation);
                  console.log(`MazaStudio: ${editorType} editor ready!`);
                  
                  const content = editorInstance.getValue();
                  const combinedTags = `\n<!-- MazaStudio Auto Injected -->\n${scTag ? '<meta name="google-site-verification" content="' + scTag + '" />\n' : ''}${gaId ? '<!-- GA4 -->\n<script async src="https://www.googletagmanager.com/gtag/js?id=' + gaId + '"></script>\n<script>\n  window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag(\'js\', new Date());\n  gtag(\'config\', \'' + gaId + '\');\n</script>\n' : ''}<!-- End MazaStudio -->\n`;
                  
                  if (!content.includes('MazaStudio Auto Injected')) {
                    const newContent = content.replace(/<head>/i, `<head>${combinedTags}`);
                    
                    if (editorType === "monaco") {
                      editorInstance.setValue(newContent);
                    } else {
                      editorInstance.setValue(newContent);
                    }
                    
                    console.log("MazaStudio: Injection successful");
                    alert("MazaStudio: 코드가 성공적으로 주입되었습니다! [적용] 버튼을 눌러 설정을 완료해 주세요.");
                  } else {
                    alert("MazaStudio: 이미 코드가 주입되어 있습니다.");
                  }
                  return;
                }

                // 2. 'html 편집' 버튼 클릭 시도 (최대 10회)
                if (!htmlEditClicked && retryCount < 10) {
                  const editBtn = document.querySelector('#whole-area .btn_edit') || 
                                  Array.from(document.querySelectorAll('button, a')).find(el => el.textContent.includes('html 편집'));
                  
                  if (editBtn) {
                    htmlEditClicked = true;
                    editBtn.click();
                    console.log("MazaStudio: Clicked 'html 편집' button");
                  } else {
                    retryCount++;
                  }
                }
              }, 1000);
            },
            args: [payload.sc_verification || payload.searchConsoleTag, payload.ga_measurement_id || payload.gaTrackingId]
          });
        }
      };
      chrome.tabs.onUpdated.addListener(onTabUpdate);
      sendResponse({ status: "STARTED", message: "티스토리 스킨 편집 창을 열고 주입을 대기합니다." });
    });
    return true;
  }

  if (message.type === 'SET_AUTH') {
    setAuth(message.token, message.userId).then(() => {
      schedulePolling();
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'REFRESH_POSTS') {
    updateBadge().then((posts) => {
      sendResponse({ posts });
    });
    return true;
  }
  if (message.type === 'GET_SERVER_URL') {
    sendResponse({ url: MAZA_SERVER });
    return true;
  }

});

// ─── 설치/업데이트 이벤트 ────────────────────────────────────────

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('[MAZA] Extension installed');
    // 설치 후 팝업 열기
    chrome.action.openPopup?.();
  }
  schedulePolling();
});

// ─── 서비스 워커 활성화 유지 ─────────────────────────────────────

chrome.runtime.onStartup.addListener(() => {
  schedulePolling();
});

// 초기 실행
schedulePolling();
