/**
 * =============================================
 * MAZA Studio - App Sync Content Script
 * 웹 앱의 인증 세션을 익스텐션으로 동기화
 * =============================================
 */

// 허용된 앱 Origin 목록 (보안: XSS 방어)
const ALLOWED_ORIGINS = [
  'https://mazastudio.kr',
  'https://www.mazastudio.kr',
  'http://localhost:3000',
  'http://localhost:5173',
  'http://localhost:5174'
];

window.addEventListener('message', (event) => {
  // [SECURITY] Origin 검증: 허용된 출처에서 온 메시지만 처리
  if (!ALLOWED_ORIGINS.includes(event.origin)) {
    return; // 알 수 없는 origin은 무조건 무시
  }

  if (event.data && event.data.type === 'MAZA_SYNC_AUTH') {
    const { token, userId, email } = event.data;
    
    if (token && userId) {
      console.log('[MAZA Extension] Auth sync received from app');
      chrome.runtime.sendMessage({
        type: 'SET_AUTH',
        token,
        userId,
        email
      });
    }
  }

  // 자동발행 메시지 수신 (PostListBlock.tsx의 COPY_POST)
  if (event.data && event.data.type === 'COPY_POST') {
    const payload = event.data.payload;
    if (payload && payload.title && payload.html) {
      console.log('[MAZA Extension] Direct inject request received');
      chrome.runtime.sendMessage({
        type: 'DIRECT_INJECT',
        payload: payload
      });
    }
  }

  // MazaStory 자동 발행 수신
  if (event.data && event.data.type === 'MAZA_PUBLISH_POST') {
    const payload = event.data.payload;
    if (payload && payload.title && payload.content) {
      console.log('[MAZA Extension] Publish request received');
      chrome.runtime.sendMessage({
        type: 'PUBLISH_POST',
        payload: payload
      });
    }
  }

  // MazaStory 자동 인프라 셋업 수신
  if (event.data && event.data.type === 'MAZA_SETUP_INFRA') {
    const payload = event.data.payload;
    if (payload) {
      console.log('[MAZA Extension] Setup Infra request received');
      chrome.runtime.sendMessage({
        type: 'SETUP_INFRA',
        payload: payload
      });
    }
  }
});

// 초기 로드시 localStorage에서 세션 추출 시도 (폴백)
function trySyncFromStorage() {
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.includes('-auth-token')) {
      try {
        const val = JSON.parse(localStorage.getItem(key) || '{}');
        if (val?.access_token && val?.user?.id) {
          chrome.runtime.sendMessage({
            type: 'SET_AUTH',
            token: val.access_token,
            userId: val.user.id,
            email: val.user.email
          });
        }
      } catch (e) {
        // ignore
      }
    }
  }
}

// [DETECTION] 전역 플래그를 페이지의 Main World에 직접 주입
function injectDetectionScript() {
  const script = document.createElement('script');
  script.textContent = `window.__MAZA_EXTENSION_INSTALLED__ = true;`;
  (document.head || document.documentElement).appendChild(script);
  script.remove();
}

injectDetectionScript();

// 앱에서 보낸 핑에 응답 (postMessage는 세계를 넘나들 수 있습니다)
window.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'MAZA_PING_EXTENSION') {
    window.postMessage({ type: 'MAZA_PONG_EXTENSION', version: '1.0.0' }, '*');
  }
});

trySyncFromStorage();
