/**
 * Tistory Skin Setup RPA Script
 * Injects GA4/Search Console codes into the <head> tag of Tistory skin editor.
 */

console.log("[MAZA] Tistory Setup RPA Loaded");

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'INJECT_SETUP_CODE') {
    const { htmlCode } = request.payload;
    handleInjection(htmlCode);
  }
});

// Auto-inject if payload exists in storage
chrome.storage.local.get(['tistorySetupPayload'], (data) => {
  if (data.tistorySetupPayload) {
    console.log("[MAZA] Found setup payload. Auto-injecting...");
    const payload = data.tistorySetupPayload;
    
    let code = '';
    if (payload.gaTrackingId) {
      code += `\n<!-- Google tag (gtag.js) -->\n<script async src="https://www.googletagmanager.com/gtag/js?id=${payload.gaTrackingId}"></script>\n<script>\n  window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag('js', new Date());\n  gtag('config', '${payload.gaTrackingId}');\n</script>\n`;
    }
    if (payload.searchConsoleTag) {
      const tagContent = payload.searchConsoleTag.replace('google-site-verification=', '').replace(/['"]/g, '');
      code += `\n<meta name="google-site-verification" content="${tagContent}" />\n`;
    }
    
    // Editor needs some time to load the HTML
    setTimeout(() => {
      handleInjection(code);
      chrome.storage.local.remove(['tistorySetupPayload']);
    }, 3000);
  }
});

async function handleInjection(codeToInject) {
  try {
    console.log("[MAZA] Starting injection...");
    
    // 1. Find the editor (Tistory uses CodeMirror or a plain textarea)
    const editor = document.querySelector('.CodeMirror') || document.querySelector('#content');
    
    if (!editor) {
      alert("티스토리 HTML 에디터를 찾을 수 없습니다. 'HTML 편집' 버튼을 눌러주세요.");
      return;
    }

    let currentContent = "";
    let isCodeMirror = editor.classList.contains('CodeMirror');

    if (isCodeMirror) {
      currentContent = editor.CodeMirror.getValue();
    } else {
      currentContent = editor.value;
    }

    // 2. Check if already injected
    if (currentContent.includes("MAZA_STUDIO_SETUP")) {
      if (!confirm("이미 마자 스튜디오 코드가 삽입되어 있습니다. 다시 삽입할까요?")) {
        return;
      }
    }

    // 3. Find <head> tag and inject after it
    const headTag = "<head>";
    const headIndex = currentContent.indexOf(headTag);

    if (headIndex === -1) {
      alert("<head> 태그를 찾을 수 없습니다. HTML 구조를 확인해주세요.");
      return;
    }

    const commentStart = "\n<!-- MAZA_STUDIO_SETUP_START -->\n";
    const commentEnd = "\n<!-- MAZA_STUDIO_SETUP_END -->\n";
    const fullInjection = commentStart + codeToInject + commentEnd;

    const newContent = currentContent.slice(0, headIndex + headTag.length) + 
                       fullInjection + 
                       currentContent.slice(headIndex + headTag.length);

    // 4. Update editor content
    if (isCodeMirror) {
      editor.CodeMirror.setValue(newContent);
    } else {
      editor.value = newContent;
      // Trigger input event for React/Vue listeners
      editor.dispatchEvent(new Event('input', { bubbles: true }));
    }

    // 5. Success feedback
    alert("인프라 코드가 성공적으로 삽입되었습니다! 우측 상단의 '적용' 버튼을 눌러 저장하세요.");
    
    // Optional: Auto-click save button
    const saveBtn = document.querySelector('.btn_apply') || document.querySelector('#btn_save');
    if (saveBtn) {
      console.log("[MAZA] Found save button, prompting user...");
    }

  } catch (err) {
    console.error("[MAZA] Injection failed:", err);
    alert("코드 삽입 중 오류가 발생했습니다: " + err.message);
  }
}
