// tistory-injector.js

console.log("[TistoryInjector] Content script loaded.");

// Helper function to sleep
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function injectCodes(payload) {
  console.log("[TistoryInjector] Starting injection sequence with payload:", payload);
  
  try {
    // 1. Wait for the HTML editor tab to be visible
    // Tistory's skin editor uses an iframe or specific UI elements.
    // Click on "HTML 편집" (HTML Edit) button if we are not already in HTML mode
    const htmlEditBtn = document.querySelector('a[href="#html"]');
    if (htmlEditBtn) {
      console.log("[TistoryInjector] Clicking HTML Edit button...");
      htmlEditBtn.click();
      await sleep(2000); // Wait for the editor to load
    }

    // Tistory uses CodeMirror for the HTML editor.
    // We need to access the CodeMirror instance or the underlying textarea.
    // The textarea is usually hidden, and CodeMirror manages the display.
    
    // Instead of manipulating CodeMirror directly from content script (which is sandboxed),
    // we inject a script tag into the page context to interact with window.editor or CodeMirror.
    
    const injectionCode = `
      (function() {
        try {
          console.log("[TistoryInjector-PageContext] Attempting to modify HTML...");
          // In Tistory skin editor, the CodeMirror instance is often attached to the textarea's next sibling
          // or accessible via a global variable. Let's try to find it.
          
          let cmInstance = null;
          const editorElement = document.querySelector('.CodeMirror');
          if (editorElement && editorElement.CodeMirror) {
            cmInstance = editorElement.CodeMirror;
          }
          
          if (!cmInstance) {
            console.error("[TistoryInjector] CodeMirror instance not found!");
            window.postMessage({ type: 'INJECTION_FAILED', error: 'Editor not found' }, '*');
            return;
          }
          
          let htmlContent = cmInstance.getValue();
          
          // Prepare the tags to inject
          const scTag = \`${payload.searchConsoleTag || ''}\`;
          let gaTag = '';
          if (\`${payload.gaTrackingId || ''}\`) {
            gaTag = \`
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=${payload.gaTrackingId}"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '${payload.gaTrackingId}');
</script>\`;
          }
          
          let adsenseTag = '';
          if (\`${payload.adsensePubId || ''}\`) {
            adsenseTag = \`
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${payload.adsensePubId}" crossorigin="anonymous"></script>\`;
          }
          
          const tagsToInject = [scTag, gaTag, adsenseTag].filter(Boolean).join('\\n');
          
          if (tagsToInject.length === 0) {
            console.log("[TistoryInjector] No tags to inject.");
            window.postMessage({ type: 'INJECTION_SUCCESS' }, '*');
            return;
          }
          
          // Inject right after <head>
          if (!htmlContent.includes(scTag) && !htmlContent.includes(payload.gaTrackingId || 'NON_EXISTENT_ID')) {
            htmlContent = htmlContent.replace(/<head>/i, \`<head>\\n  <!-- MazaStudio Auto Injected -->\\n  \${tagsToInject}\\n  <!-- End MazaStudio -->\`);
            cmInstance.setValue(htmlContent);
            console.log("[TistoryInjector] Injection successful.");
            
            // Click the Save button
            const saveBtn = document.querySelector('.btn_apply');
            if (saveBtn) {
              saveBtn.click();
              console.log("[TistoryInjector] Save button clicked.");
            }
            
            window.postMessage({ type: 'INJECTION_SUCCESS' }, '*');
          } else {
            console.log("[TistoryInjector] Tags already exist. Skipping.");
            window.postMessage({ type: 'INJECTION_SKIPPED' }, '*');
          }
          
        } catch (e) {
          console.error("[TistoryInjector-PageContext] Error:", e);
          window.postMessage({ type: 'INJECTION_FAILED', error: e.message }, '*');
        }
      })();
    `;

    // Inject the script into the page context
    const script = document.createElement('script');
    script.textContent = injectionCode;
    (document.head || document.documentElement).appendChild(script);
    script.remove();

  } catch (err) {
    console.error("[TistoryInjector] Critical error:", err);
  }
}

// Listen for messages from the injected script
window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  
  if (event.data.type === 'INJECTION_SUCCESS' || event.data.type === 'INJECTION_SKIPPED') {
    alert("MazaStudio: 티스토리 설정이 성공적으로 자동 완료되었습니다! 이제 창을 닫아도 됩니다.");
    // Optionally communicate back to background script to mark as done
  } else if (event.data.type === 'INJECTION_FAILED') {
    alert("MazaStudio: 자동 설정에 실패했습니다. 수동으로 코드를 입력해주세요. 에러: " + event.data.error);
  }
});

// Check if we have a pending payload in storage
chrome.storage.local.get("tistorySetupPayload", (data) => {
  if (data.tistorySetupPayload) {
    // Only execute if this tab matches the one we requested
    // (In content script we don't have tab.id, but we assume it's the right one if data exists)
    setTimeout(() => {
      injectCodes(data.tistorySetupPayload);
      // Clear the payload so it doesn't run again on reload
      chrome.storage.local.remove("tistorySetupPayload");
    }, 2000);
  }
});
