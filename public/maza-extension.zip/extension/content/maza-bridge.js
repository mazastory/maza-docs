// maza-bridge.js
// Listens for events from the MazaStudio web app and passes them to the background script.

window.addEventListener("message", (event) => {
  // Only accept messages from the same window
  if (event.source !== window) return;

  const type = event.data.type;
  if (type === "MAZA_AUTOMATION_START" || type === "AUTO_POST") {
    console.log(`[MazaBridge] Received ${type} request:`, event.data);
    
    // Map AUTO_POST or explicit payload action
    let action = "START_TISTORY_SETUP";
    if (type === "AUTO_POST" || event.data.payload?.action === "AUTO_POST") {
      action = "START_TISTORY_POST";
    }
    
    chrome.runtime.sendMessage({
      action: action,
      payload: event.data.payload
    }, (response) => {
      window.postMessage({
        type: "MAZA_AUTOMATION_RESPONSE",
        status: response?.status || "ERROR",
        message: response?.message || "Unknown error"
      }, "*");
    });
  }
});

// Let the Web App know the extension is installed
const extensionIdTag = document.createElement("meta");
extensionIdTag.name = "maza-extension-installed";
extensionIdTag.content = "true";
const target = document.head || document.documentElement;
if (target) {
  target.appendChild(extensionIdTag);
  console.log("[MazaBridge] Injected installation marker.");
}
