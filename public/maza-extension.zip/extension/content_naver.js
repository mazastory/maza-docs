/**
 * =============================================
 * MAZA Studio - Naver Blog Content Script
 * 네이버 블로그 스마트에디터 ONE에 AI 콘텐츠를 주입
 *
 * 지원 에디터: 스마트에디터 ONE (2021년 이후 표준)
 * =============================================
 */

let injectedPostId = null;

// ─── 네이버 스마트에디터 ONE 감지 ──────────────────────────────────

function waitForNaverEditor(callback, maxWait = 15000) {
  const start = Date.now();

  const check = () => {
    // 스마트에디터 ONE: 제목 입력 영역
    const titleEl =
      document.querySelector('.se-title-text') ||          // 스마트에디터 ONE 제목
      document.querySelector('[contenteditable="true"].se-title-text') ||
      document.querySelector('#post_title') ||             // 구형 에디터
      document.querySelector('.se-module-text-titletext'); // 대안 셀렉터

    // 스마트에디터 ONE: 본문 영역 (contenteditable)
    const bodyEl =
      document.querySelector('.se-main-container') ||
      document.querySelector('.se-component-content') ||
      document.querySelector('[contenteditable="true"].se-text-paragraph') ||
      document.querySelector('.se_textarea');              // 구형 에디터 폴백

    if (titleEl || bodyEl) {
      callback({ titleEl, bodyEl });
    } else if (Date.now() - start < maxWait) {
      setTimeout(check, 800);
    } else {
      console.warn('[MAZA] Naver editor not detected within timeout.');
    }
  };

  check();
}

// ─── MAZA 플로팅 버튼 삽입 ───────────────────────────────────────

function injectMazaButton() {
  if (document.getElementById('maza-naver-btn')) return;

  const btn = document.createElement('div');
  btn.id = 'maza-naver-btn';
  btn.innerHTML = `
    <div class="maza-fab" id="maza-naver-fab">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" fill="#fff" stroke="#fff" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <span>MAZA 콘텐츠 불러오기</span>
    </div>
    <div class="maza-panel" id="maza-naver-panel" style="display:none">
      <div class="maza-panel-header">
        <span>📝 발행 대기 중인 콘텐츠</span>
        <button class="maza-close" id="maza-naver-close">✕</button>
      </div>
      <div class="maza-panel-body" id="maza-naver-post-list">
        <div class="maza-loading">불러오는 중...</div>
      </div>
    </div>
  `;
  document.body.appendChild(btn);

  // FAB 클릭 → 패널 토글
  document.getElementById('maza-naver-fab').addEventListener('click', () => {
    const panel = document.getElementById('maza-naver-panel');
    const isVisible = panel.style.display !== 'none';
    panel.style.display = isVisible ? 'none' : 'block';
    if (!isVisible) loadNaverPostList();
  });

  // 닫기 버튼
  document.getElementById('maza-naver-close').addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('maza-naver-panel').style.display = 'none';
  });
}

// ─── 대기 중 포스트 목록 로드 ────────────────────────────────────

function loadNaverPostList() {
  chrome.runtime.sendMessage({ type: 'GET_PENDING_POSTS' }, (res) => {
    const list = document.getElementById('maza-naver-post-list');
    const posts = res?.posts || [];

    if (posts.length === 0) {
      list.innerHTML = `
        <div class="maza-empty">
          <span>대기 중인 콘텐츠가 없습니다.</span>
          <a href="https://mazastudio.kr/writer" target="_blank" class="maza-link">마자 스튜디오에서 생성하기 →</a>
        </div>`;
      return;
    }

    list.innerHTML = posts.map(post => `
      <div class="maza-post-item" data-post-id="${post.id}">
        <div class="maza-post-title">${post.content?.title || '제목 없음'}</div>
        <div class="maza-post-meta">
          <span class="maza-tag">${post.content?.keyword || ''}</span>
          <span class="maza-date">${new Date(post.publish_at).toLocaleDateString('ko-KR')}</span>
        </div>
        <button class="maza-inject-post-btn" data-post-id="${post.id}">이 글 에디터에 넣기 →</button>
      </div>
    `).join('');

    list.querySelectorAll('.maza-inject-post-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const postId = btn.dataset.postId;
        const post = posts.find(p => p.id === postId);
        if (post) injectIntoNaverEditor(post);
      });
    });
  });
}

// ─── 스마트에디터 ONE에 콘텐츠 주입 ─────────────────────────────

function injectIntoNaverEditor(post) {
  const content = post.content;
  const title = content.title || '';
  const blocks = content.blocks || [];

  injectedPostId = post.id;

  // 1. 제목 주입
  const titleEl =
    document.querySelector('.se-title-text') ||
    document.querySelector('[contenteditable="true"].se-title-text') ||
    document.querySelector('#post_title');

  if (titleEl) {
    if (titleEl.tagName === 'INPUT') {
      titleEl.value = title;
      titleEl.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      // contenteditable div 방식 (스마트에디터 ONE)
      titleEl.focus();
      titleEl.textContent = '';
      document.execCommand('insertText', false, title);
    }
  }

  // 2. 본문 주입 — 스마트에디터 ONE은 직접 DOM 조작이 제한됨
  //    가장 안정적인 방법: HTML을 클립보드에 올리고 execCommand('paste') 시도
  //    폴백: 단락을 하나씩 타이핑 시뮬레이션

  const html = buildNaverHtml(content, blocks);

  // 스마트에디터 ONE 본문 첫 번째 paragraph 포커스
  const firstPara =
    document.querySelector('.se-component.se-text .se-text-paragraph') ||
    document.querySelector('[contenteditable="true"].se-text-paragraph') ||
    document.querySelector('.se_textarea');

  if (firstPara) {
    firstPara.focus();
    try {
      // 방법 A: 네이버 에디터 전역 API 사용 (존재하는 경우)
      if (window.SE && typeof window.SE.insertHtml === 'function') {
        window.SE.insertHtml(html);
        finishNaverInjection(title, post.id);
        return;
      }

      // 방법 B: execCommand insertHTML (일부 브라우저에서 동작)
      const inserted = document.execCommand('insertHTML', false, html);
      if (inserted) {
        finishNaverInjection(title, post.id);
        return;
      }
    } catch (e) {
      console.warn('[MAZA] execCommand failed:', e);
    }
  }

  // 방법 C: 클립보드 폴백 — HTML을 클립보드에 복사하고 유저에게 안내
  fallbackCopyToClipboard(html, title, post.id);
}

// ─── 네이버 블로그용 HTML 빌더 ─────────────────────────────────

function buildNaverHtml(content, blocks) {
  // blocks 배열이 있으면 우선 사용 (AI Writer 출력 형식)
  if (blocks && blocks.length > 0) {
    return blocks.map(block => {
      switch (block.type) {
        case 'heading':
          return `<h${block.level || 2}>${block.text}</h${block.level || 2}>`;
        case 'paragraph':
        case 'intro':
          return `<p>${(block.text || '').replace(/\n/g, '<br>')}</p>`;
        case 'summary':
          return `<blockquote><strong>📌 핵심 요약</strong><br>${block.text}</blockquote>`;
        case 'insight':
          return `<blockquote><strong>💡 전문가 인사이트</strong><br>${block.text}</blockquote>`;
        case 'experience':
          return `<blockquote><strong>✅ 실제 경험담</strong><br>${block.text}</blockquote>`;
        case 'image':
          return block.url
            ? `<p><img src="${block.url}" alt="${block.alt || ''}" style="max-width:100%"/></p>`
            : '';
        case 'faq':
          return (block.items || []).map(item =>
            `<p><strong>Q: ${item.q || item.question}</strong></p><p>A: ${item.a || item.answer}</p>`
          ).join('');
        case 'links':
          return (block.items || []).map(link =>
            `<p>🔗 <a href="${link.url}" target="_blank">${link.title}</a></p>`
          ).join('');
        default:
          return block.text ? `<p>${block.text}</p>` : '';
      }
    }).join('\n');
  }

  // 구형 필드 기반 폴백
  let html = '';
  if (content.intro)       html += `<p>${content.intro}</p>`;
  if (content.content1)    html += `<p>${content.content1}</p>`;
  if (content.insightBox)  html += `<blockquote><strong>💡 전문가 팁</strong><br>${content.insightBox}</blockquote>`;
  if (content.content2)    html += `<p>${content.content2}</p>`;
  if (content.detailedFaqs?.length) {
    html += '<h3>자주 묻는 질문</h3>';
    content.detailedFaqs.forEach(faq => {
      html += `<p><strong>Q: ${faq.q}</strong></p><p>A: ${faq.a}</p>`;
    });
  }
  if (content.outro) html += `<p>${content.outro}</p>`;
  return html || '<p>콘텐츠를 불러오는 중 오류가 발생했습니다.</p>';
}

// ─── 주입 완료 처리 ─────────────────────────────────────────────

function finishNaverInjection(title, postId) {
  document.getElementById('maza-naver-panel').style.display = 'none';
  showNaverToast(`"${title}" 콘텐츠가 에디터에 삽입되었습니다! 검토 후 발행해주세요.`, 'success');
  listenForNaverPublish(postId);
}

function fallbackCopyToClipboard(html, title, postId) {
  // HTML blob + text/html MIME으로 클립보드 복사 시도
  try {
    const blob = new Blob([html], { type: 'text/html' });
    const clipItem = new ClipboardItem({ 'text/html': blob });
    navigator.clipboard.write([clipItem]).then(() => {
      document.getElementById('maza-naver-panel').style.display = 'none';
      showNaverToast(
        `"${title}" HTML이 클립보드에 복사됐습니다. 에디터 본문을 클릭한 뒤 Ctrl+V(Cmd+V)로 붙여넣기 해주세요.`,
        'info'
      );
      listenForNaverPublish(postId);
    });
  } catch (e) {
    // 최후 폴백: 텍스트로라도 복사
    navigator.clipboard.writeText(html.replace(/<[^>]*>/g, '')).catch(() => {});
    showNaverToast('에디터에 직접 붙여넣기 해주세요. 팝업에서 내용을 확인할 수 있습니다.', 'info');
  }
}

// ─── 발행 완료 감지 ──────────────────────────────────────────────

function listenForNaverPublish(postId) {
  if (!postId) return;

  let lastUrl = location.href;

  const urlObserver = setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;

      // 네이버 블로그 발행 완료 URL 패턴
      // 예: /PostView.naver?blogId=...&logNo=... 또는 /<blogId>/<postNo>
      const isPublished =
        location.href.includes('PostView.naver') ||
        location.href.match(/blog\.naver\.com\/[^/]+\/\d+$/) ||
        (!location.href.includes('PostWriteForm') && !location.href.includes('/edit'));

      if (isPublished) {
        const publishedUrl = location.href;
        chrome.runtime.sendMessage({
          type: 'MARK_PUBLISHED',
          postId,
          publishedUrl,
          platform: 'naver'
        });
        clearInterval(urlObserver);
        showNaverToast('✅ 발행 완료! URL이 마자 스튜디오에 자동 등록되었습니다.', 'success');

        const fabEl = document.getElementById('maza-naver-btn');
        if (fabEl) fabEl.style.display = 'none';
      }
    }
  }, 1000);

  // 30분 후 자동 정리
  setTimeout(() => clearInterval(urlObserver), 30 * 60 * 1000);
}

// ─── 토스트 메시지 ───────────────────────────────────────────────

function showNaverToast(message, type = 'info') {
  const existing = document.getElementById('maza-naver-toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.id = 'maza-naver-toast';
  toast.className = `maza-toast maza-toast-${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.classList.add('maza-toast-show'), 10);
  setTimeout(() => {
    toast.classList.remove('maza-toast-show');
    setTimeout(() => toast.remove(), 300);
  }, 5000);
}

// ─── 메시지 수신 (백그라운드로부터) ─────────────────────────────

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'INJECT_CONTENT') {
    injectIntoNaverEditor(message.post);
  }
});

// ─── 초기화 ──────────────────────────────────────────────────────

waitForNaverEditor(() => {
  injectMazaButton();
  console.log('[MAZA] Naver Smart Editor ONE detected. Floating button injected.');
});
