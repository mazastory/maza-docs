/**
 * =============================================
 * MAZA Studio Extension - Popup Script
 * =============================================
 */

// 배포 환경
// 배포 환경 (로컬 개발 시 localhost:3001)
const MAZA_URL = 'http://localhost:5174';
const MAZA_BACKEND = 'http://localhost:3001';

// ─── DOM Elements ────────────────────────────────────────────────
const loginSection  = document.getElementById('login-section');
const mainSection   = document.getElementById('main-section');
const openMazaBtn   = document.getElementById('open-maza-btn');
const logoutBtn     = document.getElementById('logout-btn');
const refreshBtn    = document.getElementById('refresh-btn');
const postList      = document.getElementById('post-list');
const userEmailEl   = document.getElementById('user-email');
const statusDot     = document.getElementById('status-dot');
const statPending   = document.getElementById('stat-pending');
const statPublished = document.getElementById('stat-published');
const statDay       = document.getElementById('stat-day');
const btnInfraSetup = document.getElementById('btn-infra-setup');
const infraSection  = document.getElementById('infra-section');

// ─── 인증 상태 확인 ──────────────────────────────────────────────

async function checkAuth() {
  const data = await chrome.storage.local.get(['maza_token', 'maza_user_id', 'maza_email']);
  
  if (data.maza_token && data.maza_user_id) {
    showMain(data.maza_email || data.maza_user_id);
    loadPosts();
  } else {
    // 마자 스튜디오 탭에서 토큰 자동 추출 시도
    tryAutoLogin();
  }
}

// 마자 스튜디오 탭이 열려있으면 localStorage에서 토큰 자동 추출
async function tryAutoLogin() {
  try {
    // 1. 현재 활성 탭이 마자 스튜디오인지 먼저 확인
    let targetTab = null;
    const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (activeTabs.length > 0 && activeTabs[0].url && (activeTabs[0].url.includes('mazastudio.kr') || activeTabs[0].url.includes('localhost:3000') || activeTabs[0].url.includes('localhost:3001') || activeTabs[0].url.includes('localhost:5173') || activeTabs[0].url.includes('localhost:5174'))) {
      targetTab = activeTabs[0];
    } else {
      // 2. 아니면 열려있는 모든 탭 중 마자 스튜디오 탭 찾기
      const allTabs = await chrome.tabs.query({});
      targetTab = allTabs.find(t => t.url && (t.url.includes('mazastudio.kr') || t.url.includes('localhost:3000') || t.url.includes('localhost:3001') || t.url.includes('localhost:5173') || t.url.includes('localhost:5174')));
    }

    if (!targetTab) {
      showLogin();
      document.querySelector('.login-desc').innerHTML = '마자 스튜디오 탭을 찾을 수 없습니다.<br>웹사이트를 먼저 열어주세요.';
      return;
    }

    // 탭의 localStorage에서 Supabase 세션 읽기
    const result = await chrome.scripting.executeScript({
      target: { tabId: targetTab.id },
      func: () => {
        // Supabase는 localStorage에 세션을 저장
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && key.includes('-auth-token')) {
            const val = JSON.parse(localStorage.getItem(key) || '{}');
            return {
              token: val?.access_token,
              userId: val?.user?.id,
              email: val?.user?.email
            };
          }
        }
        return null;
      }
    });

    const session = result?.[0]?.result;
    if (session?.token && session?.userId) {
      await chrome.storage.local.set({
        maza_token: session.token,
        maza_user_id: session.userId,
        maza_email: session.email
      });
      chrome.runtime.sendMessage({ type: 'SET_AUTH', token: session.token, userId: session.userId });
      showMain(session.email);
      loadPosts();
    } else {
      showLogin();
      document.querySelector('.login-desc').textContent = '세션을 찾을 수 없습니다. (token: ' + !!session?.token + ')';
    }
  } catch (e) {
    console.warn('[Popup] Auto-login failed:', e);
    showLogin();
    document.querySelector('.login-desc').textContent = '로그인 연동 오류: ' + e.message;
  }
}

// ─── UI 상태 전환 ─────────────────────────────────────────────────

function showLogin() {
  loginSection.style.display = 'block';
  mainSection.style.display = 'none';
  statusDot.className = 'status-dot offline';
}

function showMain(email) {
  loginSection.style.display = 'none';
  mainSection.style.display = 'block';
  userEmailEl.textContent = email || '로그인됨';
  statusDot.className = 'status-dot';
  checkPageContext(); // 페이지 상황에 따라 RPA 버튼 노출 여부 결정
}

async function checkPageContext() {
  if (!infraSection) return;
  
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && tab.url.includes('/manage/design/skin/edit')) {
      infraSection.style.display = 'block';
    } else {
      infraSection.style.display = 'none';
    }
  } catch (e) {
    infraSection.style.display = 'none';
  }
}

// ─── 포스트 목록 로드 ────────────────────────────────────────────

async function loadPosts() {
  chrome.runtime.sendMessage({ type: 'REFRESH_POSTS' }, (res) => {
    const posts = res?.posts || [];
    renderPosts(posts);
    statPending.textContent = posts.length;
  });

  // 추가 통계 로드
  loadStats();
}

async function loadStats() {
  const data = await chrome.storage.local.get(['maza_token', 'maza_user_id']);
  if (!data.maza_token) return;

  try {
    const res = await fetch(`${MAZA_BACKEND}/api/extension/stats?user_id=${data.maza_user_id}`, {
      headers: { Authorization: `Bearer ${data.maza_token}` }
    });
    if (res.ok) {
      const stats = await res.json();
      statPublished.textContent = stats.published_count || 0;
      statDay.textContent = stats.challenge_day || 1;
    }
  } catch (e) {
    // 서버 미응답 시 무시
  }
}

// ─── 포스트 렌더링 ────────────────────────────────────────────────

function renderPosts(posts) {
  if (!posts || posts.length === 0) {
    postList.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">✨</div>
        <div class="empty-text">발행 대기 중인 콘텐츠가 없습니다.<br>마자 스튜디오에서 AI 글을 생성해주세요.</div>
        <button class="open-maza-btn" id="go-maza">마자 스튜디오 열기 →</button>
      </div>`;
    document.getElementById('go-maza')?.addEventListener('click', () => {
      chrome.tabs.create({ url: MAZA_URL });
    });
    return;
  }

  postList.innerHTML = posts.map(post => {
    const content = post.content || {};
    const title = content.title || '제목 없음';
    const keyword = content.keyword || content.topic || '';
    const date = new Date(post.publish_at).toLocaleDateString('ko-KR', { month: 'short', day: 'numeric' });
    const domain = post.sites?.domain || '';

    return `
      <div class="post-item" data-post-id="${post.id}">
        <div class="post-item-title">${escapeHtml(title)}</div>
        <div class="post-item-meta">
          <span class="post-tag">${escapeHtml(keyword)}</span>
          <span class="post-date">${date}</span>
        </div>
        <div class="post-actions">
          <button class="btn-inject" data-post-id="${post.id}" data-domain="${escapeHtml(domain)}">
            ⚡ 주입
          </button>
          <button class="btn-open" data-domain="${escapeHtml(domain)}">
            📝 에디터
          </button>
          <button class="btn-done" data-post-id="${post.id}" data-domain="${escapeHtml(domain)}">
            ✅ 완료
          </button>
        </div>
      </div>`;
  }).join('');

  // 주입 버튼 이벤트
  postList.querySelectorAll('.btn-inject').forEach(btn => {
    btn.addEventListener('click', async () => {
      const postId = btn.dataset.postId;
      const domain = btn.dataset.domain;
      
      // 현재 티스토리 탭에 주입
      const post = posts.find(p => p.id === postId);
      if (!post) return;

      // 티스토리 에디터 탭 찾기
      const tistoryTabs = await chrome.tabs.query({ url: '*://*.tistory.com/manage/*' });
      
      if (tistoryTabs.length > 0) {
        // 이미 열려있으면 주입
        chrome.tabs.sendMessage(tistoryTabs[0].id, {
          type: 'INJECT_CONTENT',
          post
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.error('[Popup] Message failed:', chrome.runtime.lastError);
            alert('티스토리 페이지가 준비되지 않았습니다. 페이지를 새로고침한 후 다시 시도해주세요.');
          }
        });
        chrome.tabs.update(tistoryTabs[0].id, { active: true });
      } else {
        // 새 탭으로 에디터 열기 (주입 데이터를 storage에 임시 저장)
        await chrome.storage.local.set({ pending_inject: post });
        const blogDomain = domain || (post.content?.domain || '');
        const blogName = blogDomain.replace('.tistory.com', '');
        chrome.tabs.create({
          url: blogName 
            ? `https://${blogName}.tistory.com/manage/newpost`
            : 'https://www.tistory.com'
        });
      }

      window.close();
    });
  });

  // 에디터 열기 버튼
  postList.querySelectorAll('.btn-open').forEach(btn => {
    btn.addEventListener('click', () => {
      const domain = btn.dataset.domain || '';
      const blogName = domain.replace('.tistory.com', '').trim();
      const url = blogName
        ? `https://${blogName}.tistory.com/manage/newpost`
        : 'https://www.tistory.com/manage/newpost';
      chrome.tabs.create({ url });
      window.close();
    });
  });

  // 강제 완료 처리 버튼 (자동 감지 실패 대비)
  postList.querySelectorAll('.btn-done').forEach(btn => {
    btn.addEventListener('click', async () => {
      const postId = btn.dataset.postId;
      const domain = btn.dataset.domain;
      const post = posts.find(p => p.id === postId);
      if (!post) return;

      const confirmMsg = "이미 티스토리에서 발행을 완료하셨나요?\n\n(발행된 블로그 메인 주소로 자동 보고됩니다.)";
      if (!confirm(confirmMsg)) return;

      btn.textContent = "처리 중...";
      btn.disabled = true;

      // 해당 도메인 메인 URL을 발행 URL로 임시 전송 (차후 사용자가 수정 가능하도록 로직 구현 요망)
      const publishedUrl = domain ? `https://${domain}` : 'https://tistory.com';

      const data = await chrome.storage.local.get(['maza_token', 'maza_user_id']);
      try {
        const res = await fetch(`${MAZA_BACKEND}/api/extension/mark-published`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${data.maza_token}`
          },
          body: JSON.stringify({
            post_id: postId,
            user_id: data.maza_user_id,
            published_url: publishedUrl
          })
        });

        if (res.ok) {
          loadPosts();
        } else {
          alert('완료 처리에 실패했습니다.');
          btn.textContent = "✅ 완료";
          btn.disabled = false;
        }
      } catch (e) {
        alert('서버 오류가 발생했습니다.');
      btn.textContent = "✅ 완료";
        btn.disabled = false;
      }
    });
  });
}

// ─── 인프라 자동 세팅 (RPA) ──────────────────────────────────────────

if (btnInfraSetup) {
  btnInfraSetup.addEventListener('click', async () => {
    const data = await chrome.storage.local.get(['maza_token', 'maza_user_id']);
    if (!data.maza_token) {
      alert("먼저 마자 스튜디오에 로그인해주세요.");
      return;
    }

    try {
      if (!data.maza_user_id) {
        throw new Error("사용자 ID를 찾을 수 없습니다. 마자 스튜디오 앱에서 다시 로그인해주세요.");
      }

      btnInfraSetup.textContent = "⏳ 데이터 조회 중...";
      btnInfraSetup.disabled = true;

      // 1. 백엔드에서 사이트 메타데이터(GA4, SC 코드) 가져오기
      const apiUrl = `${MAZA_BACKEND}/api/sites?user_id=${data.maza_user_id}`;
      console.log(`[Popup] Fetching sites from: ${apiUrl}`);

      const res = await fetch(apiUrl, {
        headers: { Authorization: `Bearer ${data.maza_token}` }
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(`서버 응답 오류: ${errorData.error || res.statusText}`);
      }

      const siteData = await res.json();
      console.log(`[Popup] Site data received:`, siteData);
      const site = siteData?.sites?.[0]; // 첫 번째 사이트 기준

      if (!site) {
        btnInfraSetup.textContent = "⚡ 티스토리 스킨에 코드 자동 주입";
        btnInfraSetup.disabled = false;
        throw new Error("등록된 사이트 정보를 찾을 수 없습니다. 마자 스튜디오 SetupHub에서 '1-CLICK AUTO SETUP'을 먼저 실행해주세요.");
      }

      // 2. 현재 탭이 해당 사이트의 티스토리 스킨 편집 페이지인지 확인
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const siteDomain = site.domain.replace('https://', '').replace('http://', '').split('/')[0];
      const targetUrl = `https://${siteDomain}/manage/design/skin/edit`;
      
      console.log(`[Popup] Current Tab URL: ${tab?.url}`);
      console.log(`[Popup] Target URL: ${targetUrl}`);

      if (!tab || !tab.url || !tab.url.includes(siteDomain) || !tab.url.includes('/manage/design/skin/edit')) {
        if (confirm(`티스토리 스킨 편집 페이지(${siteDomain})에서만 작동합니다.\n해당 페이지로 이동할까요?`)) {
          chrome.tabs.create({ url: targetUrl });
        }
        btnInfraSetup.textContent = "⚡ 티스토리 스킨에 코드 자동 주입";
        btnInfraSetup.disabled = false;
        return;
      }


      const ga_measurement_id = site.ga_measurement_id;
      const sc_verification = site.sc_verification;
      
      // 3. 백그라운드 스크립트에 주입 요청 (서버에서 가져온 site.domain 사용)
      const blogDomain = site.domain || (tab.url.includes('tistory.com') ? tab.url.split('/')[2] : 'www');
      const blogName = blogDomain.split('.')[0];
      
      chrome.runtime.sendMessage({
        type: 'SETUP_INFRA',
        payload: {
          domain: blogName,
          sc_verification: sc_verification,
          ga_measurement_id: ga_measurement_id
        }
      }, (response) => {
        if (response && response.status === "STARTED") {
          btnInfraSetup.textContent = "✅ 주입 요청됨";
          setTimeout(() => {
            btnInfraSetup.textContent = "⚡ 티스토리 스킨에 코드 자동 주입";
            btnInfraSetup.disabled = false;
            window.close(); // 진행을 위해 팝업 닫기
          }, 2000);
        } else {
          throw new Error("백그라운드 통신 실패");
        }
      });

    } catch (err) {
      console.error("[Popup] Infra Setup Error:", err);
      alert(err.message);
      btnInfraSetup.textContent = "❌ 실패 (다시 시도)";
      btnInfraSetup.disabled = false;
    }
  });
}

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─── 이벤트 바인딩 ───────────────────────────────────────────────

openMazaBtn?.addEventListener('click', () => {
  chrome.tabs.create({ url: MAZA_URL });
});

logoutBtn?.addEventListener('click', async () => {
  await chrome.storage.local.remove(['maza_token', 'maza_user_id', 'maza_email', 'pending_posts']);
  showLogin();
});

refreshBtn?.addEventListener('click', () => {
  refreshBtn.textContent = '새로고침 중...';
  loadPosts();
  setTimeout(() => { refreshBtn.textContent = '새로고침'; }, 1500);
});

// ─── 초기화 ──────────────────────────────────────────────────────
checkAuth();
