/**
 * =============================================
 * MAZA Studio - Tistory Content Script
 * 티스토리 에디터에 AI 콘텐츠를 자동 주입
 * =============================================
 */

let injectedPostId = null;

// ─── 티스토리 에디터 감지 ────────────────────────────────────────

function waitForEditor(callback, maxWait = 10000) {
  const start = Date.now();
  
  const check = () => {
    // 티스토리 새 에디터 (iframe 기반)
    const iframe = document.querySelector('iframe#editor-tistory_ifr') ||
                   document.querySelector('iframe.editor-iframe') ||
                   document.querySelector('iframe[id*="editor"]');
    
    // 제목 입력란 (다양한 선택자 시도 - 최신/구형/대시보드형 통합)
    const titleInput = document.querySelector('input[placeholder="제목을 입력하세요."]') ||
                       document.querySelector('.title-input input') ||
                       document.querySelector('input.tf_title') ||
                       document.querySelector('#post-title-dashboard') ||
                       document.querySelector('.wrap_title textarea') ||
                       document.querySelector('#title');

    if (iframe || titleInput) {
      callback({ iframe, titleInput });
    } else if (Date.now() - start < maxWait) {
      setTimeout(check, 500);
    }
  };
  
  check();
}

// ─── MAZA 플로팅 버튼 삽입 ───────────────────────────────────────

function injectMazaButton() {
  if (document.getElementById('maza-inject-btn')) return;

  const btn = document.createElement('div');
  btn.id = 'maza-inject-btn';
  btn.innerHTML = `
    <div class="maza-fab">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" fill="#fff" stroke="#fff" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <span>MAZA 콘텐츠 불러오기</span>
    </div>
    <div class="maza-panel" id="maza-panel" style="display:none">
      <div class="maza-panel-header">
        <span>📝 발행 대기 중인 콘텐츠</span>
        <button class="maza-close" id="maza-close">✕</button>
      </div>
      <div class="maza-panel-body" id="maza-post-list">
        <div class="maza-loading">불러오는 중...</div>
      </div>
    </div>
  `;
  document.body.appendChild(btn);

  // 버튼 클릭 → 패널 토글
  btn.querySelector('.maza-fab').addEventListener('click', () => {
    const panel = document.getElementById('maza-panel');
    const isVisible = panel.style.display !== 'none';
    panel.style.display = isVisible ? 'none' : 'block';
    if (!isVisible) loadPostList();
  });

  // 닫기
  btn.querySelector('#maza-close').addEventListener('click', (e) => {
    e.stopPropagation();
    document.getElementById('maza-panel').style.display = 'none';
  });
}

// ─── 대기 중 포스트 목록 로드 ────────────────────────────────────

function loadPostList() {
  chrome.runtime.sendMessage({ type: 'GET_PENDING_POSTS' }, (res) => {
    const list = document.getElementById('maza-post-list');
    const posts = res?.posts || [];

    if (posts.length === 0) {
      list.innerHTML = `
        <div class="maza-empty">
          <span>대기 중인 콘텐츠가 없습니다.</span>
          <a href="https://mazastudio.kr/writer" target="_blank" class="maza-link">마자 스튜디오에서 생성하기 →</a>
        </div>`;
      return;
    }

    list.innerHTML = posts.map(post => `
      <div class="maza-post-item" data-post-id="${post.id}">
        <div class="maza-post-header">
          <div class="maza-post-title">${post.content?.title || '제목 없음'}</div>
          <button class="maza-post-delete-btn" data-post-id="${post.id}" title="목록에서 삭제">✕</button>
        </div>
        <div class="maza-post-meta">
          <span class="maza-tag">${post.content?.keyword || ''}</span>
          <span class="maza-date">${new Date(post.publish_at).toLocaleDateString('ko-KR')}</span>
        </div>
        <button class="maza-inject-post-btn" data-post-id="${post.id}">이 글 에디터에 넣기 →</button>
      </div>
    `).join('');

    // 삭제 버튼 리스너
    list.querySelectorAll('.maza-post-delete-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const postId = btn.dataset.postId;
        if (confirm('이 포스팅을 목록에서 삭제하시겠습니까?')) {
          chrome.runtime.sendMessage({ type: 'DELETE_POST', postId }, (res) => {
            if (res?.success) {
              btn.closest('.maza-post-item').remove();
              showToast('포스팅이 목록에서 삭제되었습니다.');
            }
          });
        }
      });
    });

    list.querySelectorAll('.maza-inject-post-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const postId = btn.dataset.postId;
        const post = posts.find(p => p.id === postId);
        if (post) injectPostIntoEditor(post);
      });
    });
  });
}

// ─── 에디터에 콘텐츠 주입 ────────────────────────────────────────

function injectPostIntoEditor(post) {
  const content = post.content;
  const title = content.title || '';
  const rawHtml = content.html || buildHtmlFromBlocks(content);
  const hashtags = content.hashtags || content.tags || [];
  const category = content.category || '';

  injectedPostId = post.id;

  // 1. 제목 주입
  const titleInput = document.querySelector('input[placeholder="제목을 입력하세요."]') ||
                     document.querySelector('.title-input input') ||
                     document.querySelector('input.tf_title') ||
                     document.querySelector('#title');
  
  if (titleInput) {
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set ||
                                   Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
    if (nativeInputValueSetter) {
      nativeInputValueSetter.call(titleInput, title);
    } else {
      titleInput.value = title;
    }
    titleInput.dispatchEvent(new Event('input', { bubbles: true }));
    titleInput.dispatchEvent(new Event('change', { bubbles: true }));
    console.log('[MAZA] Title injected:', title);
  }

  // 본문에서 h1 태그 제거 (제목 중복 방지)
  const cleanHtml = rawHtml.replace(/<h1[^>]*>.*?<\/h1>/i, '');

  // 2. 본문 주입 (새 에디터 iframe 방식)
  const iframe = document.querySelector('iframe#editor-tistory_ifr') ||
                 document.querySelector('iframe.editor-iframe') ||
                 document.querySelector('iframe[id*="editor"]');
  
  if (iframe) {
    try {
      const doc = iframe.contentDocument || iframe.contentWindow.document;
      const body = doc.body;
      if (body) {
        body.innerHTML = cleanHtml;
        body.dispatchEvent(new Event('input', { bubbles: true }));
        console.log('[MAZA] Body content injected via iframe.');
      }
    } catch (e) {
      console.warn('[MAZA] iframe injection failed, trying clipboard fallback:', e);
      injectViaClipboard(cleanHtml);
    }
  } else {
    injectViaClipboard(cleanHtml);
  }

  // 3. 카테고리 선택 (BUG-03 FIX)
  if (category) {
    setTimeout(() => {
      const catSelect = document.querySelector('select[name="category"]') ||
                        document.querySelector('.category-selector select') ||
                        document.querySelector('#category');
      if (catSelect) {
        const options = Array.from(catSelect.options);
        const target = options.find(o => o.text.includes(category) || o.value === category);
        if (target) {
          catSelect.value = target.value;
          catSelect.dispatchEvent(new Event('change', { bubbles: true }));
          console.log('[MAZA] Category selected:', category);
        }
      }
    }, 500);
  }

  // 4. 해시태그 주입 (BUG-04 FIX)
  if (hashtags.length > 0) {
    setTimeout(() => {
      // 티스토리 태그 입력란 탐색 (다양한 버전 대응)
      const tagInput = document.querySelector('input.tt-input') ||
                       document.querySelector('#tagBx input') ||
                       document.querySelector('.tag-input-area input') ||
                       document.querySelector('input[placeholder*="태그"]') ||
                       document.querySelector('input[placeholder*="tag"]');
      
      if (tagInput) {
        hashtags.forEach((tag, idx) => {
          setTimeout(() => {
            const cleanTag = String(tag).replace('#', '').trim();
            if (!cleanTag) return;
            tagInput.focus();
            const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
            if (nativeSetter) nativeSetter.call(tagInput, cleanTag);
            else tagInput.value = cleanTag;
            tagInput.dispatchEvent(new Event('input', { bubbles: true }));
            tagInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
            tagInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, bubbles: true }));
            console.log('[MAZA] Tag injected:', cleanTag);
          }, idx * 300); // 각 태그 사이 300ms 간격
        });
      } else {
        console.warn('[MAZA] Tag input field not found. Tags:', hashtags);
      }
    }, 800);
  }

  // 5. 패널 닫고 성공 토스트
  document.getElementById('maza-panel').style.display = 'none';
  const tagCount = hashtags.length > 0 ? ` (태그 ${hashtags.length}개 포함)` : '';
  showToast(`"${title}" 콘텐츠가 에디터에 삽입되었습니다${tagCount}! 검토 후 발행해주세요.`);

  // 6. 발행 감지 리스너
  listenForPublish();
}

function buildHtmlFromBlocks(content) {
  let html = '';
  if (content.intro) html += `<p>${content.intro}</p>`;
  if (content.content1) html += `<p>${content.content1}</p>`;
  if (content.insightBox) html += `<blockquote><strong>💡 전문가 팁</strong><br>${content.insightBox}</blockquote>`;
  if (content.content2) html += `<p>${content.content2}</p>`;
  if (content.detailedFaqs?.length) {
    html += '<h3>자주 묻는 질문</h3>';
    content.detailedFaqs.forEach(faq => {
      html += `<p><strong>Q: ${faq.q}</strong></p><p>A: ${faq.a}</p>`;
    });
  }
  if (content.outro) html += `<p>${content.outro}</p>`;
  return html || '<p>콘텐츠를 불러오는 중 오류가 발생했습니다.</p>';
}

function injectViaClipboard(html) {
  // 클립보드 폴백
  navigator.clipboard.writeText(html).then(() => {
    showToast('HTML이 클립보드에 복사되었습니다. 에디터에 붙여넣기(Cmd+V) 해주세요.');
  }).catch(() => {
    showToast('에디터에 직접 복붙해주세요. 팝업에서 HTML을 확인할 수 있습니다.');
  });
}

// ─── 발행 완료 감지 ──────────────────────────────────────────────

function listenForPublish() {
  if (!injectedPostId) return;

  // [FIX] browser:contains() 는 표준 querySelector 미지원 — 네이티브 JS로 대체
  const allBtns = Array.from(document.querySelectorAll('button, input[type="submit"]'));
  const publishBtns = allBtns.filter(el =>
    el.dataset?.action === 'publish' ||
    el.classList.contains('publish-btn') ||
    el.classList.contains('btn-publish') ||
    (el.textContent && (el.textContent.trim().includes('발행') || el.textContent.trim().includes('publish')))
  );

  // URL 변경 감지 (발행 완료 후 URL이 바뀜)
  let lastUrl = location.href;
  const urlObserver = setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      
      // 발행 완료 URL 패턴: /manage/가 아니면서, 숫자(/123) 또는 문자열(/entry/...)인 경우
      const isPostUrl = !location.href.includes('/manage/') && 
                        (location.href.match(/tistory\.com\/(\d+)$/) || location.href.match(/tistory\.com\/entry\//));
      
      if (isPostUrl) {
        const publishedUrl = location.href;
        chrome.runtime.sendMessage({
          type: 'MARK_PUBLISHED',
          postId: injectedPostId,
          publishedUrl
        });
        clearInterval(urlObserver);
        showToast(`✅ 발행 완료! URL이 마자 스튜디오에 자동 등록되었습니다.`, 'success');
        injectedPostId = null;
        
        // 버튼과 패널 화면에서 제거
        const btn = document.getElementById('maza-inject-btn');
        if (btn) btn.style.display = 'none';
      }
    }
  }, 1000);

  // 30분 후 자동 정리
  setTimeout(() => clearInterval(urlObserver), 30 * 60 * 1000);
}

// ─── 토스트 메시지 ───────────────────────────────────────────────

function showToast(message, type = 'info') {
  const existing = document.getElementById('maza-toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.id = 'maza-toast';
  toast.className = `maza-toast maza-toast-${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.classList.add('maza-toast-show'), 10);
  setTimeout(() => {
    toast.classList.remove('maza-toast-show');
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// ─── 메시지 수신 (백그라운드로부터) ─────────────────────────────

chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'INJECT_CONTENT') {
    injectPostIntoEditor(message.post);
  }
});

// ─── 초기화 ──────────────────────────────────────────────────────

waitForEditor(() => {
  injectMazaButton();
  console.log('[MAZA] Tistory editor detected. Floating button injected.');

  // 자동발행(Zero-Click) 체크
  chrome.storage.local.get(['direct_inject_post'], (data) => {
    if (data.direct_inject_post) {
      console.log('[MAZA] Direct inject post found. Auto-injecting...');
      const payload = data.direct_inject_post;
      
      const post = {
        id: payload.id,
        content: {
          title: payload.title,
          html: payload.html
        }
      };
      
      // 약간의 지연 후 주입 (에디터 완전 로드 대기)
      setTimeout(() => {
        injectPostIntoEditor(post);
        chrome.storage.local.remove(['direct_inject_post']);
      }, 500);
    }
  });
});
