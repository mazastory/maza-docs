// @ts-nocheck
/**
 * Maza Bridge v4 — shared/logger.js
 * Structured Logger for Observability
 */

const LOG_LEVELS = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3
};

const CURRENT_LEVEL = LOG_LEVELS.INFO; // Could be configurable

class StructuredLogger {
  constructor(module) {
    this.module = module;
  }

  log(level, tag, message, meta = {}) {
    if (level < CURRENT_LEVEL) return;
    
    const timestamp = new Date().toISOString();
    const formattedMeta = Object.keys(meta).length ? JSON.stringify(meta) : '';
    
    const prefix = `[${timestamp}] [${this.module}] [${tag}]`;
    
    switch (level) {
      case LOG_LEVELS.DEBUG:
        console.debug(`${prefix} ${message}`, formattedMeta);
        break;
      case LOG_LEVELS.INFO:
        console.info(`${prefix} ℹ️ ${message}`, formattedMeta);
        break;
      case LOG_LEVELS.WARN:
        console.warn(`${prefix} ⚠️ ${message}`, formattedMeta);
        break;
      case LOG_LEVELS.ERROR:
        console.error(`${prefix} ❌ ${message}`, formattedMeta);
        // Optional: Send to remote telemetry
        this.reportTelemetry(tag, message, meta);
        break;
    }
  }

  debug(tag, message, meta) { this.log(LOG_LEVELS.DEBUG, tag, message, meta); }
  info(tag, message, meta) { this.log(LOG_LEVELS.INFO, tag, message, meta); }
  warn(tag, message, meta) { this.log(LOG_LEVELS.WARN, tag, message, meta); }
  error(tag, message, meta) { this.log(LOG_LEVELS.ERROR, tag, message, meta); }

  reportTelemetry(tag, message, meta) {
    if (!chrome.runtime?.id) return;
    chrome.runtime.sendMessage({
      type: 'SEND_TO_SERVER',
      payload: {
        type: 'TELEMETRY_REPORT',
        data: { module: this.module, tag, message, meta, timestamp: Date.now() }
      }
    }).catch(() => {});
  }
}

export const createLogger = (moduleName) => new StructuredLogger(moduleName);
