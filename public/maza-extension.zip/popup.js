// @ts-nocheck
import { CONFIG } from './shared/config.js';
const wsStatusEl = document.getElementById('ws-status');
const postListEl = document.getElementById('post-list');
const openBtn = document.getElementById('open-studio');
// 1. 익스텐션 상태 확인
chrome.runtime.sendMessage({ type: 'EXTENSION_STATUS' }, (res) => {
    if (chrome.runtime.lastError || !res?.alive) {
        wsStatusEl.innerHTML = '<span class="dot dot-red"></span>연결 끊김';
    }
    else {
        wsStatusEl.innerHTML = '<span class="dot dot-green"></span>연결됨';
    }
});
// 2. 발행 대기 포스트 목록 가져오기
async function fetchPendingPosts() {
    try {
        const storage = await chrome.storage.local.get(['mazaToken']);
        const token = storage.mazaToken;
        if (!token) {
            postListEl.innerHTML = '<div class="empty-state">Maza Studio에서 로그인해 주세요.</div>';
            return;
        }
        const response = await fetch(`${CONFIG.API_BASE_URL}/extension/pending-posts`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (!response.ok) {
            // [P1] HTML 응답 또는 빈 응답에 대한 안전한 에러 처리
            let errorMessage = `서버 오류 (${response.status})`;
            try {
                const text = await response.text();
                const json = JSON.parse(text);
                errorMessage = json.error || errorMessage;
            }
            catch {
                // JSON 파싱 실패 시 (HTML 응답 등) 기본 메시지 사용
            }
            if (response.status === 401) {
                errorMessage = '인증 만료: Maza Studio를 새로고침해 주세요.';
            }
            throw new Error(errorMessage);
        }
        // [P1] 응답이 JSON인지 확인 후 파싱
        let data;
        try {
            const text = await response.text();
            data = JSON.parse(text);
        }
        catch {
            throw new Error('서버에서 잘못된 응답이 왔습니다. (JSON 파싱 실패)');
        }
        renderPosts(data.posts || []);
    }
    catch (err) {
        console.error('[Popup] Fetch failed:', err);
        postListEl.innerHTML = '';
        const errorDiv = document.createElement('div');
        errorDiv.className = 'empty-state';
        errorDiv.textContent = err.message || '목록을 가져올 수 없습니다.';
        postListEl.appendChild(errorDiv);
    }
}
function renderPosts(posts) {
    if (posts.length === 0) {
        postListEl.innerHTML = '<div class="empty-state">발행 대기 중인 글이 없습니다.</div>';
        return;
    }
    postListEl.innerHTML = '';
    posts.forEach(post => {
        const div = document.createElement('div');
        div.className = 'post-item';
        const info = document.createElement('div');
        info.className = 'post-info';
        const title = document.createElement('div');
        title.className = 'post-title';
        title.textContent = post.content?.title || '(제목 없음)';
        const meta = document.createElement('div');
        meta.className = 'post-meta';
        meta.textContent = post.content?.domain || 'Tistory';
        info.appendChild(title);
        info.appendChild(meta);
        const btn = document.createElement('button');
        btn.className = 'publish-btn';
        btn.dataset.id = post.id;
        btn.textContent = '작성 시작';
        div.appendChild(info);
        div.appendChild(btn);
        btn.addEventListener('click', () => {
            btn.disabled = true;
            btn.textContent = '진행 중...';
            chrome.runtime.sendMessage({
                type: 'MANUAL_PUBLISH',
                post: post
            });
            setTimeout(() => {
                window.close();
            }, 500);
        });
        postListEl.appendChild(div);
    });
}
// 초기 로드
fetchPendingPosts();
// 새로고침 버튼
document.getElementById('refresh-list').addEventListener('click', () => {
    postListEl.innerHTML = '<div class="loading-spinner"></div>';
    fetchPendingPosts();
});
// Studio 열기 (중복 탭 방지)
openBtn.addEventListener('click', async () => {
    const allTabs = await chrome.tabs.query({});
    const studioTab = allTabs.find(t => t.url && t.url.startsWith(CONFIG.STUDIO_URL));
    if (studioTab) {
        chrome.tabs.update(studioTab.id, { active: true });
        chrome.windows.update(studioTab.windowId, { focused: true });
    }
    else {
        chrome.tabs.create({ url: CONFIG.STUDIO_URL });
    }
    window.close();
});
//# sourceMappingURL=popup.js.map