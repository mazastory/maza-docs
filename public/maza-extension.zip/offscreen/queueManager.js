/**
 * Maza Bridge v4 — offscreen/queueManager.js
 * Persistent Job Queue for Crash Recovery and Deterministic Execution
 */
import { runtime } from '../shared/runtime.js';
export class QueueManager {
    queue;
    activeJob;
    isProcessing;
    constructor() {
        this.queue = [];
        this.activeJob = null;
        this.isProcessing = false;
    }
    async init() {
        // 1. Ensure Runtime & APIs are fully ready
        await runtime.ready();
        // 2. Load persisted queue from background via RPC
        return new Promise((resolve) => {
            chrome.runtime.sendMessage({
                type: 'RPC_CALL',
                method: 'STORAGE_GET',
                params: { keys: ['MAZA_PERSISTENT_QUEUE'] }
            }, (response) => {
                if (chrome.runtime.lastError) {
                    console.warn('[QueueManager] RPC Error:', chrome.runtime.lastError);
                    resolve();
                    return;
                }
                const result = response?.result || {};
                if (result.MAZA_PERSISTENT_QUEUE) {
                    this.queue = result.MAZA_PERSISTENT_QUEUE;
                    console.log(`[QueueManager] 🔄 Recovered ${this.queue.length} jobs from storage.`);
                }
                resolve();
            });
        });
    }
    async persist() {
        return new Promise((resolve) => {
            chrome.runtime.sendMessage({
                type: 'RPC_CALL',
                method: 'STORAGE_SET',
                params: { data: { MAZA_PERSISTENT_QUEUE: this.queue } }
            }, () => {
                if (chrome.runtime.lastError) {
                    console.warn('[QueueManager] RPC Error during persist:', chrome.runtime.lastError);
                }
                resolve();
            });
        });
    }
    async addJob(job) {
        const newJob = {
            id: job.id || `job_${Date.now()}`,
            payload: job.payload || { id: '', url: '', title: '', html: '' },
            status: 'pending',
            retryCount: 0,
            priority: job.priority ?? 0,
            maxRetries: job.maxRetries || 3,
            createdAt: Date.now()
        };
        if (this.queue.some(q => q.id === newJob.id)) {
            console.log(`[QueueManager] Job ${newJob.id} already in queue. Skipping.`);
            return false;
        }
        this.queue.push(newJob);
        await this.persist();
        console.log(`[QueueManager] 📥 Added job ${newJob.id} (Prio: ${newJob.priority}). Total: ${this.queue.length}`);
        return true;
    }
    /**
     * Atomic Job Acquisition
     * Ensures only one worker (even across contexts) can pick up the job.
     */
    async acquireJob() {
        // 1. Recover stale jobs first
        await this.recoverStaleJobs();
        // 2. Find next job by Priority DESC, then CreatedAt ASC
        const sortedQueue = [...this.queue]
            .filter(j => j.status === 'pending')
            .sort((a, b) => {
            if (b.priority !== a.priority)
                return b.priority - a.priority;
            return a.createdAt - b.createdAt;
        });
        const next = sortedQueue[0];
        if (!next)
            return null;
        // 3. Atomically Mark as running (In JS memory this is atomic, but we sync with storage)
        next.status = 'running';
        next.startedAt = Date.now();
        next.workerId = 'offscreen_core_1'; // Standardized ID
        await this.persist();
        return next;
    }
    /**
     * Recover jobs stuck in 'running' state for > 15 minutes (Zombie recovery)
     */
    async recoverStaleJobs() {
        const STALE_THRESHOLD = 15 * 60 * 1000;
        const now = Date.now();
        let recoveredCount = 0;
        this.queue.forEach(j => {
            if (j.status === 'running' && j.startedAt && (now - j.startedAt > STALE_THRESHOLD)) {
                console.warn(`[QueueManager] 🧟 Recovering stale job ${j.id}. Resetting to pending.`);
                j.status = 'pending';
                recoveredCount++;
            }
        });
        if (recoveredCount > 0)
            await this.persist();
    }
    async markJobStatus(jobId, status, error = null) {
        const job = this.queue.find(j => j.id === jobId);
        if (!job)
            return;
        job.status = status;
        job.updatedAt = Date.now();
        if (error) {
            job.lastError = typeof error === 'object' ? error.message : error;
        }
        if (status === 'completed' || status === 'failed_permanently') {
            this.queue = this.queue.filter(j => j.id !== jobId);
        }
        await this.persist();
    }
    async failJobAndRetry(jobId, error) {
        const job = this.queue.find(j => j.id === jobId);
        if (!job)
            return false;
        job.retryCount += 1;
        console.warn(`[QueueManager] Job ${jobId} failed. Retry: ${job.retryCount}/3. Error: ${error}`);
        if (job.retryCount >= (job.maxRetries || 3)) {
            await this.markJobStatus(jobId, 'failed_permanently', error);
            return false;
        }
        else {
            // Exponential backoff happens in Orchestrator, but we put it to pending here
            await this.markJobStatus(jobId, 'pending', error);
            return true;
        }
    }
    getActiveJob() {
        return this.activeJob;
    }
    setActiveJob(jobId) {
        this.activeJob = jobId;
    }
}
export const queueManager = new QueueManager();
//# sourceMappingURL=queueManager.js.map