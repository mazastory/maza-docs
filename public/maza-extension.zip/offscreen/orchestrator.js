/**
 * Maza Bridge v4 — offscreen/orchestrator.js
 * Master orchestrator connecting Queue, State Machine, and Background RPC
 */
import { queueManager } from './queueManager.js';
import { JobStateMachine, JOB_STATES } from './stateMachine.js';
import { replayLogger } from '../shared/replayLogger.js';
export class Orchestrator {
    activeFsm;
    isProcessing;
    constructor() {
        this.activeFsm = null;
        this.isProcessing = false;
    }
    async start() {
        await queueManager.init();
        console.log('[Orchestrator] 🚀 Started. Checking for pending jobs...');
        this.processNextJob(); // Don't await, let it run in background
    }
    async enqueuePublishJob(jobId, data, isHighPriority = false) {
        const added = await queueManager.addJob({
            id: jobId,
            status: 'pending',
            payload: data,
            priority: isHighPriority ? 100 : 0
        });
        if (added) {
            this.processNextJob();
        }
    }
    async enqueueInfraJob(jobId, data) {
        // Infrastructure setup is always high priority
        const added = await queueManager.addJob({
            id: jobId,
            type: 'INJECT_INFRA',
            status: 'pending',
            priority: 200,
            payload: { ...data, steps: ['CREATE_TAB', 'WAIT_FOR_SKIN_EDIT', 'INJECT_INFRA_DOM'] }
        });
        if (added) {
            this.processNextJob();
        }
    }
    async processNextJob() {
        if (this.isProcessing)
            return;
        const job = await queueManager.acquireJob();
        if (!job)
            return;
        // [Phase 7] Exponential Backoff Logic
        if (job.retryCount > 0) {
            const backoffDelay = Math.pow(2, job.retryCount) * 2000;
            console.log(`[Orchestrator] ⏳ Backoff for job ${job.id}: ${backoffDelay}ms...`);
            await new Promise(r => setTimeout(r, backoffDelay));
        }
        this.isProcessing = true;
        queueManager.setActiveJob(job.id);
        this.activeFsm = new JobStateMachine(job.id, JOB_STATES.IDLE);
        replayLogger.startSession(job.id, job.payload);
        const unsubscribe = this.activeFsm.subscribe((newState, oldState, meta) => {
            replayLogger.logTransition(oldState, newState, meta);
            const progress = this.activeFsm.calculateProgress();
            this.notifyServer(job.id, newState, progress);
        });
        try {
            if (job.type === 'INJECT_INFRA') {
                await this.executeInfraWorkflow(job);
            }
            else {
                await this.executeWorkflow(job);
            }
            await queueManager.markJobStatus(job.id, 'completed');
            console.log(`[Orchestrator] ✅ Job ${job.id} completed successfully.`);
        }
        catch (err) {
            console.error(`[Orchestrator] ❌ Job ${job.id} failed:`, err);
            const lastTabId = job.payload.tabId || this.activeFsm?.history[this.activeFsm.history.length - 1]?.meta?.tabId;
            let snapshot = null;
            if (lastTabId) {
                try {
                    const res = await this.rpcCall('TAKE_SNAPSHOT', { tabId: lastTabId });
                    if (res && res.html)
                        snapshot = res.html;
                }
                catch (e) { }
            }
            replayLogger.logError(err, snapshot);
            const willRetry = await queueManager.failJobAndRetry(job.id, err.message);
            if (willRetry) {
                await this.planAndExecuteRecovery(job, err, snapshot, lastTabId);
            }
            else {
                console.log(`[Orchestrator] 🚫 Job ${job.id} failed permanently.`);
                this.notifyServer(job.id, JOB_STATES.ERROR, 100, err.message);
            }
        }
        finally {
            const sessionData = await replayLogger.getSessionData();
            this.notifyServer(job.id, this.activeFsm?.currentState || JOB_STATES.DONE, 100, null, sessionData);
            await replayLogger.saveSession();
            unsubscribe();
            this.activeFsm = null;
            this.isProcessing = false;
            queueManager.setActiveJob(null);
            setTimeout(() => this.processNextJob(), 2000);
        }
    }
    async executeInfraWorkflow(job) {
        const fsm = this.activeFsm;
        const { payload } = job;
        let currentTabId = null;
        fsm.transition(JOB_STATES.NAVIGATING);
        const tabRes = await this.rpcCall('OPEN_EDITOR_TAB', { url: payload.url });
        currentTabId = tabRes.tabId;
        fsm.transition(JOB_STATES.WAITING_EDITOR, { tabId: currentTabId });
        // Specific wait for Tistory skin edit page
        await this.rpcCall('WAIT_EDITOR_READY', { tabId: currentTabId, timeout: 120000 });
        fsm.transition(JOB_STATES.EXECUTING, { tabId: currentTabId });
        await this.rpcCall('INJECT_CONTENT', { tabId: currentTabId, data: payload });
        fsm.transition(JOB_STATES.DONE, { tabId: currentTabId });
    }
    /**
     * [Phase 7] Recovery Planner
     * Analyzes error type and chooses between HEALING, VISUAL_FALLBACK, or RE-NAVIGATE
     */
    async planAndExecuteRecovery(job, error, snapshot, tabId) {
        const errorMsg = error.message || String(error);
        // Strategy 1: AI Healing (Selector missing or changed)
        if (errorMsg.includes('not found') || errorMsg.includes('Selector missing') || errorMsg.includes('Timeout')) {
            if (snapshot && this.activeFsm) {
                this.activeFsm.transition(JOB_STATES.HEALING, { tabId });
                try {
                    console.log(`[Orchestrator] 🩺 Recovery Strategy: AI HEALING`);
                    const healRes = await fetch(`http://localhost:3000/api/extension/heal`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ jobId: job.id, error: errorMsg, html: snapshot })
                    });
                    if (healRes.ok) {
                        const suggestion = await healRes.json();
                        job.payload.selectors = { ...job.payload.selectors, ...suggestion.selectors };
                        return; // Retry will pick up new selectors
                    }
                }
                catch (e) { }
            }
        }
        // Strategy 2: Visual Fallback (Selector healing failed, try clicking)
        if (job.retryCount >= 2 && snapshot && tabId) {
            this.activeFsm.transition(JOB_STATES.VISUAL_FALLBACK, { tabId });
            try {
                console.log(`[Orchestrator] 👁️ Recovery Strategy: VISUAL FALLBACK`);
                const screenshotRes = await this.rpcCall('TAKE_SCREENSHOT', { tabId });
                if (screenshotRes.ok) {
                    const visualRes = await fetch(`http://localhost:3000/api/extension/visual-click`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ screenshot: screenshotRes.dataUrl.split(',')[1], target: 'Publish Button' })
                    });
                    if (visualRes.ok) {
                        const { x, y } = await visualRes.json();
                        await this.rpcCall('CLICK_COORDINATES', { tabId, x, y });
                        return;
                    }
                }
            }
            catch (e) { }
        }
        // Strategy 3: Hard Refresh / Re-Navigate (Network or frozen editor)
        if (errorMsg.includes('Network') || errorMsg.includes('Timeout')) {
            console.log(`[Orchestrator] 🔄 Recovery Strategy: RE-NAVIGATION`);
            // Next retry will naturally start from CREATE_TAB/NAVIGATE if we clean status
        }
    }
    async executeWorkflow(job) {
        const fsm = this.activeFsm;
        const { payload } = job;
        // Define steps (in the future, payload.steps will dictate this)
        const steps = payload.steps || ['CREATE_TAB', 'WAIT_READY', 'INJECT_CONTENT', 'VERIFY'];
        let currentTabId = null;
        for (const step of steps) {
            replayLogger.logAction(step, { timestamp: Date.now() });
            switch (step) {
                case 'CREATE_TAB':
                    fsm.transition(JOB_STATES.NAVIGATING);
                    const tabResponse = await this.rpcCall('OPEN_EDITOR_TAB', { url: payload.url });
                    if (!tabResponse.ok)
                        throw new Error(`Tab creation failed: ${tabResponse.error}`);
                    currentTabId = tabResponse.tabId;
                    break;
                case 'WAIT_READY':
                    fsm.transition(JOB_STATES.WAITING_EDITOR, { tabId: currentTabId });
                    const waitResponse = await this.rpcCall('WAIT_EDITOR_READY', { tabId: currentTabId, autoClick: payload.autoClickWrite, timeout: 60000 });
                    if (!waitResponse.ok)
                        throw new Error(`Editor wait failed: ${waitResponse.error}`);
                    break;
                case 'INJECT_CONTENT':
                    fsm.transition(JOB_STATES.EXECUTING, { tabId: currentTabId });
                    const injectResponse = await this.rpcCall('INJECT_CONTENT', { tabId: currentTabId, data: payload });
                    if (!injectResponse.ok)
                        throw new Error(`Content injection failed: ${injectResponse.error}`);
                    break;
                case 'VERIFY':
                    fsm.transition(JOB_STATES.VERIFYING, { tabId: currentTabId });
                    await new Promise(r => setTimeout(r, 1500));
                    const verifyResponse = await this.rpcCall('VERIFY_CONTENT', { tabId: currentTabId });
                    if (!verifyResponse.ok || !verifyResponse.isValid) {
                        throw new Error('Content verification failed after injection');
                    }
                    break;
            }
        }
        fsm.transition(JOB_STATES.DONE, { tabId: currentTabId });
    }
    /**
     * Remote Procedure Call (RPC) to background.js
     * Since offscreen document cannot use chrome.tabs, we delegate it.
     */
    async rpcCall(method, params = {}) {
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ type: 'RPC_CALL', method, params }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                }
                else if (!response) {
                    reject(new Error(`No response from background for RPC: ${method}`));
                }
                else {
                    resolve(response);
                }
            });
        });
    }
    /**
     * Send progress to WebSocket (via offscreen's own connection)
     */
    notifyServer(jobId, state, progress, error = null, replayData = null) {
        const task = this.activeFsm?.history[this.activeFsm.history.length - 1]?.meta?.currentTask || state;
        const log = this.activeFsm?.history.map(h => ({
            time: h.timestamp,
            message: h.meta?.currentTask || h.state,
            type: h.state === JOB_STATES.ERROR ? 'error' : (h.state === JOB_STATES.HEALING ? 'healing' : 'info')
        }));
        const event = new CustomEvent('MAZA_ORCHESTRATOR_UPDATE', {
            detail: {
                jobId,
                state,
                progress,
                error,
                task,
                log,
                replayData
            }
        });
        window.dispatchEvent(event);
    }
}
export const orchestrator = new Orchestrator();
//# sourceMappingURL=orchestrator.js.map