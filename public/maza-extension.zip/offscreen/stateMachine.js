/**
 * Maza Bridge v4 — offscreen/stateMachine.js
 * FSM (Finite State Machine) for Job Execution
 */
export const JOB_STATES = {
    IDLE: 'IDLE',
    NAVIGATING: 'NAVIGATING',
    WAITING_EDITOR: 'WAITING_EDITOR',
    EXECUTING: 'EXECUTING',
    VERIFYING: 'VERIFYING',
    PUBLISHING: 'PUBLISHING',
    HEALING: 'HEALING',
    VISUAL_FALLBACK: 'VISUAL_FALLBACK',
    DONE: 'DONE',
    ERROR: 'ERROR'
};
export class JobStateMachine {
    jobId;
    currentState;
    history;
    listeners;
    constructor(jobId, initialState = JOB_STATES.IDLE) {
        this.jobId = jobId;
        this.currentState = initialState;
        this.history = [{ state: initialState, timestamp: Date.now() }];
        this.listeners = [];
    }
    canTransitionTo(newState) {
        // Basic rules to prevent backward or impossible transitions
        const validTransitions = {
            [JOB_STATES.IDLE]: [JOB_STATES.NAVIGATING, JOB_STATES.ERROR],
            [JOB_STATES.NAVIGATING]: [JOB_STATES.WAITING_EDITOR, JOB_STATES.ERROR, JOB_STATES.HEALING],
            [JOB_STATES.WAITING_EDITOR]: [JOB_STATES.EXECUTING, JOB_STATES.ERROR, JOB_STATES.HEALING],
            [JOB_STATES.EXECUTING]: [JOB_STATES.VERIFYING, JOB_STATES.ERROR, JOB_STATES.HEALING],
            [JOB_STATES.VERIFYING]: [JOB_STATES.PUBLISHING, JOB_STATES.ERROR, JOB_STATES.DONE, JOB_STATES.HEALING],
            [JOB_STATES.PUBLISHING]: [JOB_STATES.DONE, JOB_STATES.ERROR, JOB_STATES.HEALING],
            [JOB_STATES.HEALING]: [JOB_STATES.NAVIGATING, JOB_STATES.WAITING_EDITOR, JOB_STATES.EXECUTING, JOB_STATES.VISUAL_FALLBACK, JOB_STATES.ERROR],
            [JOB_STATES.VISUAL_FALLBACK]: [JOB_STATES.DONE, JOB_STATES.ERROR],
            [JOB_STATES.DONE]: [],
            [JOB_STATES.ERROR]: [JOB_STATES.NAVIGATING] // Allow retry from error
        };
        return validTransitions[this.currentState]?.includes(newState);
    }
    transition(newState, meta = {}) {
        if (!this.canTransitionTo(newState)) {
            console.warn(`[FSM] Invalid transition attempt: ${this.currentState} -> ${newState}`);
            return false;
        }
        const previousState = this.currentState;
        this.currentState = newState;
        this.history.push({ state: newState, timestamp: Date.now(), meta });
        console.log(`[FSM:${this.jobId}] ${previousState} ➡️ ${newState}`);
        this.notifyListeners(newState, previousState, meta);
        return true;
    }
    getState() {
        return this.currentState;
    }
    subscribe(callback) {
        this.listeners.push(callback);
        return () => {
            this.listeners = this.listeners.filter(cb => cb !== callback);
        };
    }
    notifyListeners(newState, oldState, meta) {
        this.listeners.forEach(cb => cb(newState, oldState, meta));
    }
    calculateProgress() {
        const weights = {
            [JOB_STATES.IDLE]: 0,
            [JOB_STATES.NAVIGATING]: 10,
            [JOB_STATES.WAITING_EDITOR]: 30,
            [JOB_STATES.EXECUTING]: 60,
            [JOB_STATES.VERIFYING]: 80,
            [JOB_STATES.PUBLISHING]: 90,
            [JOB_STATES.HEALING]: 50,
            [JOB_STATES.VISUAL_FALLBACK]: 95,
            [JOB_STATES.DONE]: 100,
            [JOB_STATES.ERROR]: 100
        };
        return weights[this.currentState] || 0;
    }
}
//# sourceMappingURL=stateMachine.js.map