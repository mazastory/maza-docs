// @ts-nocheck
/**
 * Maza Bridge v3 — content/detectors.js
 * 현재 페이지 상태 감지 유틸리티
 */

'use strict';

window.MAZA_DETECT = {
  /**
   * 현재 페이지가 발행 완료 페이지인지 확인
   * (예: tistory.com/123 으로 리다이렉트된 경우)
   */
  isPublishedPage() {
    const url = window.location.href;
    return /tistory\.com\/\d+$/.test(url) ||
           /\.blogspot\.com\/\d{4}\//.test(url) ||
           /\/\?p=\d+/.test(url); // WordPress
  },

  /**
   * 에디터가 준비됐는지 확인
   */
  isEditorReady() {
    const host = window.location.hostname;
    if (host.includes('tistory.com')) {
      return !!(
        document.querySelector('input.tf_g') ||
        document.querySelector('#editor-content[contenteditable]') ||
        document.querySelector('#editor-content-iframe')
      );
    }
    return !!(document.querySelector('[contenteditable="true"]'));
  },

  /**
   * 현재 URL + 제목 스냅샷
   */
  snapshot() {
    return {
      url:      window.location.href,
      title:    document.title,
      platform: window.MAZA_DOM?.run ? 'ready' : 'not-ready',
    };
  },
};
