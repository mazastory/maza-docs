// @ts-nocheck
/**
 * Maza Bridge v4 — shared/utils.js
 * 공통 유틸리티 함수
 */

/**
 * 안전한 알림 발송
 */
export function safeNotify(id, options) {
  if (chrome.runtime?.id && chrome.notifications) {
    chrome.notifications.create(id, options);
  }
}

/**
 * 안전한 탭 작업 wrapper
 */
export async function safeTabAction(callback) {
  if (!chrome.runtime?.id) return null;
  try {
    return await callback();
  } catch (err) {
    console.warn('[Maza Bridge Utils] Tab action failed:', err.message);
    return null;
  }
}

/**
 * 지연 함수 (Promise)
 */
export const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
