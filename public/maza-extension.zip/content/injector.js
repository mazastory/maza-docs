"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // extension/core/runtime/broker.ts
  var MessageBroker;
  var init_broker = __esm({
    "extension/core/runtime/broker.ts"() {
      "use strict";
      MessageBroker = class _MessageBroker {
        static instance = null;
        channel;
        resolvers = /* @__PURE__ */ new Map();
        apiSuccessIntercepted = false;
        initialized = false;
        constructor() {
          this.channel = new BroadcastChannel("maza-runtime");
        }
        static getInstance() {
          if (!this.instance) {
            this.instance = new _MessageBroker();
          }
          return this.instance;
        }
        registerResolver(requestId, resolve) {
          this.resolvers.set(requestId, resolve);
        }
        deregisterResolver(requestId) {
          this.resolvers.delete(requestId);
        }
        isApiSuccessIntercepted() {
          return this.apiSuccessIntercepted;
        }
        resetApiIntercept() {
          this.apiSuccessIntercepted = false;
        }
        getChannel() {
          return this.channel;
        }
        start() {
          if (this.initialized) return;
          this.initialized = true;
          this.channel.onmessage = (event) => {
            const { type, requestId, ok, value } = event.data || {};
            if (type === "MAZA_PUBLISH_API_SUCCESS") {
              console.log("[MAZA Broker] Caught intercepted fetch/XHR API publish success token.");
              this.apiSuccessIntercepted = true;
              return;
            }
            if (requestId) {
              const resolver = this.resolvers.get(requestId);
              if (resolver) {
                resolver({ type, ok, value });
              }
            }
          };
        }
        // 브릿지 해제 및 포트 클린업
        cleanup() {
          try {
            this.channel.close();
          } catch (e) {
            console.debug("[MAZA OS] Expected exception caught:", e);
          }
          this.resolvers.clear();
          this.initialized = false;
          _MessageBroker.instance = null;
          console.log("[MAZA Broker] BroadcastChannel successfully closed & unmounted.");
        }
      };
    }
  });

  // extension/platforms/tistory/selectors.ts
  var EDITOR_SELECTORS, EDITOR_FALLBACK_SELECTORS, CODE_EDITOR_SELECTORS, MONACO_EDITOR_SELECTORS, HTML_EDITOR_TOGGLE_SELECTORS, TITLE_SELECTORS, WRITE_BUTTON_SELECTORS, MODE_MENU_SELECTORS, MODE_CANDIDATES_SELECTORS, DEFAULT_MODE_SELECTORS, CATEGORY_BUTTON_SELECTORS, CATEGORY_DROPDOWN_SELECTORS, CATEGORY_OPTION_SELECTORS, PUBLISH_BTN_SELECTORS, CONFIRM_BTN_SELECTORS, PUBLISH_OPTION_SELECTORS, PUBLISH_LAYER_SELECTORS, SELECTORS;
  var init_selectors = __esm({
    "extension/platforms/tistory/selectors.ts"() {
      "use strict";
      EDITOR_SELECTORS = [
        '[data-ke-editor="true"]',
        ".ke-content[contenteditable]",
        '[data-editor="ke"]',
        ".ProseMirror[contenteditable]",
        '[contenteditable][role="textbox"]',
        '[contenteditable="plaintext-only"][role="textbox"]',
        '[role="textbox"][contenteditable]',
        '[role="textbox"][contenteditable="plaintext-only"]',
        '#editor-root [contenteditable="true"]',
        ".content_editable[contenteditable]",
        ".content_editable",
        '.editor_area [contenteditable="true"]',
        ".editor_area [contenteditable]",
        '.tt-editor [contenteditable="true"]',
        ".se2_input[contenteditable]",
        ".se2_inputarea[contenteditable]",
        ".se-component[contenteditable]",
        ".se-component-content[contenteditable]",
        ".se-main [contenteditable]",
        ".fr-element[contenteditable]",
        ".fr-view",
        ".editor-body[contenteditable]",
        '[id^="tx_canvas"][contenteditable]',
        "iframe.ke-iframe",
        "#editor-tistory_ifr",
        "iframe.editor-tistory",
        'iframe[title="\uC5D0\uB514\uD130"]',
        '[contenteditable="true"]',
        "textarea#tx_canvas_source",
        "textarea.tf_source",
        "#tx_canvas_source",
        "div[contenteditable]",
        "textarea"
      ];
      EDITOR_FALLBACK_SELECTORS = [
        '[data-editor="ke"]',
        ".content_editable[contenteditable]",
        ".content_editable",
        '.editor_area [contenteditable="true"]',
        ".editor_area [contenteditable]",
        ".editor-body[contenteditable]",
        ".tx-content-body",
        ".tx-editor",
        ".tx-content",
        '[id^="tx_canvas"][contenteditable]',
        "iframe.ke-iframe",
        '[contenteditable="true"]',
        "textarea#tx_canvas_source",
        "textarea.tf_source",
        "#tx_canvas_source",
        "div[contenteditable]",
        "textarea"
      ];
      CODE_EDITOR_SELECTORS = [
        ".CodeMirror",
        ".cm-editor",
        "textarea#tx_canvas_source",
        "textarea.tf_source",
        "#htmlEditor"
      ];
      MONACO_EDITOR_SELECTORS = [".monaco-editor"];
      HTML_EDITOR_TOGGLE_SELECTORS = [
        '[href*="source/html"]',
        '[data-tab="html"]',
        '[data-action*="source/html"]',
        '[data-id*="html"]',
        '[data-tooltip*="HTML"]',
        '[data-tooltip*="html"]',
        '[aria-label*="HTML"]',
        '[aria-label*="html"]',
        '[title*="HTML"]',
        '[title*="html"]'
      ];
      TITLE_SELECTORS = [
        "#post-title-field",
        "input.tf_title",
        "textarea.tf_tit",
        ".tf_tit",
        '[placeholder*="\uC81C\uBAA9"]',
        ".ph_tit",
        'input[name="title"]',
        ".editor-title-input"
      ];
      WRITE_BUTTON_SELECTORS = [
        'a[href*="/manage/newpost"]',
        'a[href*="/manage/post/write"]',
        'a[href*="/manage/page/write"]',
        'a[href*="/manage/pages/write"]',
        'button[href*="/manage/newpost"]',
        'button[href*="/manage/post/write"]',
        'button[href*="/manage/page/write"]',
        'button[href*="/manage/pages/write"]',
        ".btn_tistory.btn_write",
        "button.btn_tistory.btn_write",
        ".btn_write",
        'button[class*="btn_write"]',
        '[class*="btn_write"]',
        '[aria-label*="\uAE00\uC4F0\uAE30"]'
      ];
      MODE_MENU_SELECTORS = [
        "#editor-mode-select",
        ".btn_mode",
        '[class*="mode_select"]',
        '[class*="modeSelect"]',
        '[class*="editor-mode"]',
        'button[class*="mode"]',
        '[aria-label*="\uBAA8\uB4DC"]'
      ];
      MODE_CANDIDATES_SELECTORS = ["button", "li", "span", "div", "a", '[role="menuitem"]', '[role="option"]'];
      DEFAULT_MODE_SELECTORS = [
        'li[data-mode="default"]',
        'button[data-mode="default"]',
        'div[data-mode="default"]',
        '[data-mode="default"]',
        '[data-code="default"]',
        'li[data-mode="prose"]',
        '[data-mode="prose"]',
        '[data-code="wysiwyg"]',
        'button[data-code="wysiwyg"]',
        '[data-mode="visual"]'
      ];
      CATEGORY_BUTTON_SELECTORS = [
        ".category-selector",
        ".btn_category",
        '[aria-label*="\uCE74\uD14C\uACE0\uB9AC"]',
        'button[class*="category"]'
      ];
      CATEGORY_DROPDOWN_SELECTORS = [".list_category", ".category-list", ".category-item", ".item_category"];
      CATEGORY_OPTION_SELECTORS = [
        ".list_category li button",
        ".list_item li a",
        '[role="option"]',
        ".item_category",
        ".category-list button",
        ".category-item button"
      ];
      PUBLISH_BTN_SELECTORS = [
        "#publish-layer-open",
        "button.btn_publish",
        "button.btn_done",
        ".btn_done",
        ".btn_publish",
        'button[data-action="publish"]',
        'button[type="submit"]:not([type="hidden"])',
        '[class*="btn_submit"]',
        '[class*="btn_confirm"]',
        '[class*="btn_ok"]',
        'button[aria-label*="\uBC1C\uD589"]',
        'button[aria-label*="\uAC8C\uC2DC"]',
        'button[aria-label*="\uC644\uB8CC"]'
      ];
      CONFIRM_BTN_SELECTORS = [
        "#publish-btn",
        "button.btn_confirm",
        "button.btn_done",
        ".btn_confirm",
        ".btn_done",
        'button[type="submit"]',
        '[class*="btn_confirm_submit"]',
        "button.btn-publish",
        "button.publish-btn",
        '[class*="btn_publish"][class*="confirm"]',
        '[class*="submit"][class*="publish"]'
      ];
      PUBLISH_OPTION_SELECTORS = {
        public: ["label", "span", "button", ".text"],
        now: ["label", "span", "button", ".text"]
      };
      PUBLISH_LAYER_SELECTORS = [
        ".layer_post",
        ".layer_publish",
        '[class*="layer_post"]',
        '[class*="layer_publish"]',
        '[role="dialog"][class*="publish"]',
        ".layer-publish-page",
        '[class*="publish_page"]',
        '[class*="page_publish"]',
        'form[class*="publish"]',
        ".publish-form",
        '[class*="publishForm"]'
      ];
      SELECTORS = {
        editor: EDITOR_SELECTORS,
        editorFallback: EDITOR_FALLBACK_SELECTORS,
        codeEditor: CODE_EDITOR_SELECTORS,
        monacoEditor: MONACO_EDITOR_SELECTORS,
        htmlEditorToggle: HTML_EDITOR_TOGGLE_SELECTORS,
        title: TITLE_SELECTORS,
        publishBtn: PUBLISH_BTN_SELECTORS,
        confirmBtn: CONFIRM_BTN_SELECTORS,
        writeBtn: WRITE_BUTTON_SELECTORS,
        modeMenu: MODE_MENU_SELECTORS,
        modeCandidates: MODE_CANDIDATES_SELECTORS,
        publishOption: PUBLISH_OPTION_SELECTORS,
        defaultMode: DEFAULT_MODE_SELECTORS,
        tag: [
          "#post-tag-field",
          ".tf_tag",
          '[placeholder*="\uD0DC\uADF8"]',
          ".ph_tag",
          ".tag_input",
          'input[name="tag"]'
        ],
        tagInput: [
          "input#tagText",
          ".tag_input input",
          'input[name="tag"]',
          'input[name="tags"]',
          ".tags-input input",
          "input.tf_tag",
          "input.tag-input",
          'input[type="text"][placeholder*="\uD0DC\uADF8"]',
          'input[type="text"][placeholder*="tag"]'
        ],
        visibility: {
          public: [
            'button[aria-label*="\uACF5\uAC1C"]',
            'button[aria-label*="Public"]',
            ".visibility-select",
            ".btn_visibility"
          ],
          private: [
            'button[aria-label*="\uBE44\uACF5\uAC1C"]',
            'button[aria-label*="Private"]',
            ".visibility-select",
            ".btn_visibility"
          ]
        },
        publishTime: {
          now: [
            'button[aria-label*="\uC989\uC2DC"]',
            'button[aria-label*="Now"]',
            ".btn_now",
            'button[class*="publish_now"]'
          ],
          schedule: ['button[aria-label*="\uC608\uC57D"]', ".btn_schedule", 'button[class*="schedule"]']
        },
        category: {
          button: CATEGORY_BUTTON_SELECTORS,
          dropdown: CATEGORY_DROPDOWN_SELECTORS,
          option: CATEGORY_OPTION_SELECTORS
        },
        thumbnail: {
          button: [
            ".btn_thumbnail",
            ".thumbnail-button",
            ".btn_thumb",
            ".thumb-button",
            ".thumbnail-action",
            ".thumbnailArea",
            ".thumbnail-area",
            ".thumbnailAction",
            ".image-thumbnail",
            ".image-thumb",
            ".btn_image",
            ".btn_photo",
            '[aria-label*="\uC378\uB124\uC77C"]',
            '[aria-label*="\uB300\uD45C\uC774\uBBF8\uC9C0"]',
            '[aria-label*="\uB300\uD45C \uC774\uBBF8\uC9C0"]',
            '[aria-label*="\uB300\uD45C \uC0AC\uC9C4"]',
            '[aria-label*="\uC774\uBBF8\uC9C0"]',
            '[aria-label*="\uC0AC\uC9C4"]',
            '[aria-label*="\uCCA8\uBD80"]',
            '[title*="\uC378\uB124\uC77C"]',
            '[title*="\uB300\uD45C\uC774\uBBF8\uC9C0"]',
            '[title*="\uB300\uD45C \uC774\uBBF8\uC9C0"]',
            '[title*="\uB300\uD45C \uC0AC\uC9C4"]',
            '[title*="\uC774\uBBF8\uC9C0"]',
            '[title*="\uC0AC\uC9C4"]',
            'button[data-action*="thumbnail" i]',
            'button[data-testid*="thumbnail" i]',
            'button[class*="thumbnail" i]',
            'button[class*="cover" i]',
            'button[class*="image" i]',
            'button[class*="photo" i]',
            'label[for*="thumbnail" i]',
            'label[class*="thumbnail" i]',
            ".thumbnail",
            ".thumb",
            ".cover",
            ".photo",
            ".image"
          ],
          modal: [".thumbnail-modal", '[class*="thumbnail_modal"]', '[class*="thumbnailModal"]'],
          preview: [".thumbnail_preview img", '[class*="preview"] img', ".thumb img", ".Thumb img"]
        },
        publishLayer: PUBLISH_LAYER_SELECTORS,
        cancelDraftBtn: [".btn_layer.btn_cancel", ".layer_post .btn_cancel", "button.btn_cancel", ".cancel-button"],
        csrfToken: ['meta[name="csrf-token"]', 'meta[name="_csrf"]'],
        uploadForm: [
          'form[action*="upload" i]',
          'form[action*="attach" i]',
          'form[action*="photo" i]',
          'form[action*="image" i]'
        ],
        uploadInput: ['input[type="file"]'],
        pageMeta: {
          ogUrl: ['meta[property="og:url"]'],
          canonical: ['link[rel="canonical"]'],
          ogTitle: ['meta[property="og:title"]']
        }
      };
    }
  });

  // extension/utils/dom.ts
  function findAnywhere(selector, root = document) {
    if (Array.isArray(selector)) {
      for (const s of selector) {
        const found = findAnywhere(s, root);
        if (found) return found;
      }
      return null;
    }
    const el = root.querySelector(selector);
    if (el) return el;
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          const found = findAnywhere(selector, doc);
          if (found) return found;
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        const found = findAnywhere(selector, node.shadowRoot);
        if (found) return found;
      }
    }
    return null;
  }
  function findAnywhereAll(selector, root = document) {
    const elements = [];
    const seen = /* @__PURE__ */ new Set();
    const pushUnique = (items) => {
      for (const item of items) {
        if (!seen.has(item)) {
          seen.add(item);
          elements.push(item);
        }
      }
    };
    if (Array.isArray(selector)) {
      for (const s of selector) {
        pushUnique(findAnywhereAll(s, root));
      }
      return elements;
    }
    pushUnique(Array.from(root.querySelectorAll(selector)));
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          pushUnique(findAnywhereAll(selector, doc));
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        pushUnique(findAnywhereAll(selector, node.shadowRoot));
      }
    }
    return elements;
  }
  function findFirst(selectors, root = document) {
    if (!selectors) return null;
    if (Array.isArray(selectors)) {
      for (const selector of selectors) {
        const el = findAnywhere(selector, root);
        if (el) return el;
      }
      return null;
    }
    return findAnywhere(selectors, root);
  }
  function findByTextAnywhere(text, root = document) {
    const interactive = root.querySelectorAll('button, a, [role="button"], input[type="button"], input[type="submit"]');
    for (const el of Array.from(interactive)) {
      if (el.textContent?.trim() === text || el.textContent?.includes(text)) {
        return el;
      }
    }
    const all = root.querySelectorAll("span, p, div, label");
    let bestMatch = null;
    let minLength = Infinity;
    for (const el of Array.from(all)) {
      const elText = el.textContent || "";
      if (elText.includes(text)) {
        if (elText.length < minLength) {
          minLength = elText.length;
          bestMatch = el;
        }
      }
    }
    if (bestMatch) return bestMatch;
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        const found = findByTextAnywhere(text, node.shadowRoot);
        if (found) return found;
      }
    }
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          const found = findByTextAnywhere(text, doc);
          if (found) return found;
        }
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
    }
    return null;
  }
  async function clickAnywhere(target) {
    const el = typeof target === "string" ? findAnywhere(target) : target;
    if (el) {
      el.click();
      try {
        el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
        el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      return true;
    }
    return false;
  }
  function notifyProgress(step, detail) {
    chrome.runtime.sendMessage({
      type: "MAZA_INFRA_PROGRESS",
      step,
      detail,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }).catch(() => {
    });
  }
  async function waitForElement(selector, timeout = 1e4, signal) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (signal?.aborted) return null;
      const el = Array.isArray(selector) ? findFirst(selector) : findAnywhere(selector);
      if (el) return el;
      await new Promise((r) => setTimeout(r, 500));
    }
    return null;
  }
  async function waitUntil(predicate, timeoutMs = 8e3, pollInterval = 250, signal) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      if (signal?.aborted) return false;
      try {
        if (predicate()) return true;
      } catch (e) {
        if (e && e.message === "DAILY_LIMIT_EXCEEDED") throw e;
        console.debug("[MAZA OS] Expected exception in waitUntil predicate", e);
      }
      await new Promise((r) => setTimeout(r, pollInterval));
    }
    return false;
  }
  var init_dom = __esm({
    "extension/utils/dom.ts"() {
      "use strict";
    }
  });

  // extension/core/logger.ts
  function startTimer(label) {
    timers.set(label, Date.now());
  }
  function endTimer(label, module, message) {
    const start = timers.get(label);
    if (start) {
      const duration = Date.now() - start;
      if (module && message) {
        logger.debug(module, `${message} (${duration}ms)`);
      }
      timers.delete(label);
    }
  }
  var Logger, logger, log, info, warn, error, debug, timers;
  var init_logger = __esm({
    "extension/core/logger.ts"() {
      "use strict";
      Logger = class {
        logs = [];
        maxLogs = 500;
        // 메모리 제한
        isDev = true;
        // 개발 환경인 경우 콘솔 출력
        info(module, message, data) {
          this.log("info", module, message, data);
        }
        warn(module, message, data) {
          this.log("warn", module, message, data);
        }
        error(module, message, data) {
          this.log("error", module, message, data);
        }
        debug(module, message, data) {
          this.log("debug", module, message, data);
        }
        log(level, module, message, data) {
          const timestamp = (/* @__PURE__ */ new Date()).toISOString().split("T")[1].split("Z")[0];
          const formattedMsg = `[${timestamp}] [${module}] ${message}`;
          const entry = {
            timestamp: Date.now(),
            level,
            module,
            message,
            data
          };
          this.logs.push(entry);
          if (this.logs.length > this.maxLogs) {
            this.logs = this.logs.slice(-this.maxLogs);
          }
          const prefix = `[${module}]`;
          const styles = {
            "info": "color: #0ea5e9; font-weight: bold;",
            "warn": "color: #f59e0b; font-weight: bold;",
            "error": "color: #ef4444; font-weight: bold;",
            "debug": "color: #888; font-style: italic;"
          };
          if (this.isDev) {
            console.log(`%c${prefix} ${message}`, styles[level], data ?? "");
          }
          if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
            try {
              chrome.runtime.sendMessage(
                {
                  type: "TASK_LOG",
                  level,
                  scope: module,
                  message: formattedMsg,
                  data
                },
                () => {
                  void chrome.runtime.lastError;
                }
              );
            } catch (e) {
            }
          }
        }
        getLogs(filter) {
          return this.logs.filter((entry) => {
            if (filter?.module && entry.module !== filter.module) return false;
            if (filter?.level && entry.level !== filter.level) return false;
            return true;
          });
        }
        clearLogs() {
          this.logs = [];
        }
        exportLogs() {
          return JSON.stringify(this.logs, null, 2);
        }
      };
      logger = new Logger();
      log = Object.assign(
        ((module, msg, data) => logger.info(module, msg, data)),
        {
          info: (module, msg, data) => logger.info(module, msg, data),
          warn: (module, msg, data) => logger.warn(module, msg, data),
          error: (module, msg, data) => logger.error(module, msg, data),
          debug: (module, msg, data) => logger.debug(module, msg, data)
        }
      );
      info = (module, msg, data) => logger.info(module, msg, data);
      warn = (module, msg, data) => logger.warn(module, msg, data);
      error = (module, msg, data) => logger.error(module, msg, data);
      debug = (module, msg, data) => logger.debug(module, msg, data);
      timers = /* @__PURE__ */ new Map();
    }
  });

  // extension/platforms/tistory/thumbnailConfig.ts
  var init_thumbnailConfig = __esm({
    "extension/platforms/tistory/thumbnailConfig.ts"() {
      "use strict";
    }
  });

  // extension/platforms/tistory/publishDom.ts
  async function waitUntil2(predicate, timeoutMs = 8e3, pollInterval = 250, signal) {
    const start = Date.now();
    const useAnimationFrame = pollInterval <= 32 && typeof window !== "undefined" && typeof window.requestAnimationFrame === "function";
    while (Date.now() - start < timeoutMs) {
      if (signal?.aborted) return false;
      try {
        if (predicate()) return true;
      } catch (e) {
        log.debug("PublishDom", "Expected exception caught in waitUntil predicate", e);
      }
      if (useAnimationFrame) {
        await new Promise((resolve) => window.requestAnimationFrame(() => resolve()));
      } else {
        await new Promise((r) => setTimeout(r, pollInterval));
      }
    }
    return false;
  }
  function isVisible(element) {
    if (!element) return false;
    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none" && style.opacity !== "0";
  }
  function findModeOption(texts, dataModes = []) {
    const candidates = findAnywhereAll(SELECTORS.modeCandidates);
    return candidates.find((el) => {
      if (!isVisible(el)) return false;
      const text = (el.textContent || "").trim();
      const currentMode = (el.getAttribute("data-mode") || el.getAttribute("data-code") || "").toLowerCase();
      if (dataModes.length && dataModes.some((mode) => mode.toLowerCase() === currentMode)) {
        return true;
      }
      return texts.some((t) => text === t || text.replace(/\s+/g, "") === t.replace(/\s+/g, "") || text.includes(t));
    }) || null;
  }
  function isEditorModeDropdownOpen() {
    const menuButton = findAnywhere(SELECTORS.modeMenu);
    if (menuButton && menuButton.getAttribute("aria-expanded") === "true") {
      return true;
    }
    const candidateButtons = findAnywhereAll(SELECTORS.modeCandidates);
    const triggerBtn = candidateButtons.find((el) => {
      if (!isVisible(el)) return false;
      const text = (el.textContent || "").trim();
      return /기본모드|기본 모드|HTML모드|HTML 모드/.test(text) || /모드|mode/i.test(text) && text.length <= 20;
    });
    if (triggerBtn && triggerBtn.getAttribute("aria-expanded") === "true") {
      return true;
    }
    return false;
  }
  async function openEditorModeDropdown() {
    if (isEditorModeDropdownOpen()) {
      log.info("EditorManager", "Editor mode dropdown is already open.");
      return true;
    }
    const menuButton = findAnywhere(SELECTORS.modeMenu);
    if (menuButton && isVisible(menuButton)) {
      menuButton.click();
      await waitUntil2(() => isEditorModeDropdownOpen(), 1e3, 50);
      return true;
    }
    const candidateButtons = findAnywhereAll(SELECTORS.modeCandidates);
    const triggerBtn = candidateButtons.find((el) => {
      if (!isVisible(el)) return false;
      const text = (el.textContent || "").trim();
      return /기본모드|기본 모드|HTML모드|HTML 모드/.test(text) || /모드|mode/i.test(text) && text.length <= 20;
    });
    if (triggerBtn) {
      if (triggerBtn.getAttribute("aria-expanded") === "true") {
        return true;
      }
      triggerBtn.click();
      await waitUntil2(() => isEditorModeDropdownOpen(), 1e3, 50);
      return true;
    }
    const reactTriggered = await reactClick('#editor-mode-select, .btn_mode, [class*="mode_select"]', "\uAE30\uBCF8\uBAA8\uB4DC");
    if (reactTriggered) {
      await waitUntil2(() => isEditorModeDropdownOpen(), 1e3, 50);
      return true;
    }
    return false;
  }
  async function reactClick(selector, textContent) {
    return new Promise((resolve) => {
      const requestId = crypto.randomUUID();
      const broker = MessageBroker.getInstance();
      let settled = false;
      broker.registerResolver(requestId, (payload) => {
        settled = true;
        broker.deregisterResolver(requestId);
        resolve(payload?.ok === true);
      });
      broker.getChannel().postMessage({
        requestId,
        action: "REACT_CLICK",
        selector,
        textContent
      });
      void (async () => {
        const completed = await waitUntil2(() => settled, 1500, 50);
        if (!completed && !settled) {
          broker.deregisterResolver(requestId);
          resolve(false);
        }
      })();
    });
  }
  function setNativeValue(element, value) {
    const valueSetter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), "value")?.set;
    if (valueSetter) {
      valueSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      element.value = value;
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  async function reliableSetValue(input, value) {
    for (let i = 0; i < 3; i++) {
      setNativeValue(input, value);
      const matched = await waitUntil2(() => input.value === value, 500, 50);
      if (matched) {
        return true;
      }
    }
    return false;
  }
  var CleanupOrchestrator;
  var init_publishDom = __esm({
    "extension/platforms/tistory/publishDom.ts"() {
      "use strict";
      init_selectors();
      init_dom();
      init_broker();
      init_logger();
      init_thumbnailConfig();
      CleanupOrchestrator = class {
        observers = /* @__PURE__ */ new Set();
        timeouts = /* @__PURE__ */ new Set();
        listeners = /* @__PURE__ */ new Set();
        registerObserver(obs) {
          this.observers.add(obs);
        }
        registerTimeout(id) {
          this.timeouts.add(id);
        }
        registerListener(target, type, handler, options) {
          target.addEventListener(type, handler, options);
          this.listeners.add({ target, type, handler, options });
        }
        cleanup() {
          for (const obs of this.observers) {
            try {
              obs.disconnect();
            } catch (e) {
              log.debug("PublishDom", "Expected exception caught during observer.disconnect", e);
            }
          }
          this.observers.clear();
          for (const id of this.timeouts) {
            try {
              clearTimeout(id);
            } catch (e) {
              log.debug("PublishDom", "Expected exception caught during clearTimeout", e);
            }
          }
          this.timeouts.clear();
          for (const item of this.listeners) {
            try {
              item.target.removeEventListener(item.type, item.handler, item.options);
            } catch (e) {
              log.debug("PublishDom", "Expected exception caught during removeEventListener", e);
            }
          }
          this.listeners.clear();
          log.info("CleanupOrchestrator", "Autopilot memory nodes successfully reclaimed.");
        }
      };
    }
  });

  // extension/core/adapters/editor.ts
  function tokenize(str) {
    const normalized = str.normalize("NFC").replace(/[\u200B-\u200D\uFEFF]/g, "").replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'\n\r]/g, " ").toLowerCase();
    return new Set(normalized.split(/\s+/).filter((t) => t.length > 0));
  }
  function compareSimilarity(expectedHtml, actualText) {
    const parser = new DOMParser();
    const expectedDoc = parser.parseFromString(expectedHtml.replace(/></g, "> <"), "text/html");
    const expectedTokens = tokenize(expectedDoc.body.textContent || "");
    let cleanActualText = actualText;
    if (actualText.includes("<") && (actualText.includes(">") || actualText.includes("</"))) {
      try {
        const spacedHtml = actualText.replace(/></g, "> <");
        const actualDoc = parser.parseFromString(spacedHtml, "text/html");
        cleanActualText = actualDoc.body.textContent || actualText;
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
    }
    const actualTokens = tokenize(cleanActualText);
    if (expectedTokens.size === 0) return true;
    if (actualTokens.size === 0) return false;
    let intersectionSize = 0;
    for (const token of expectedTokens) {
      if (actualTokens.has(token)) intersectionSize++;
    }
    const unionSize = expectedTokens.size + actualTokens.size - intersectionSize;
    const similarity = intersectionSize / unionSize;
    const threshold = 0.3;
    console.log(`[MAZA Telemetry] Token size: ${expectedTokens.size}, Similarity: ${similarity.toFixed(3)} (Min: ${threshold})`);
    return similarity >= threshold;
  }
  var init_editor = __esm({
    "extension/core/adapters/editor.ts"() {
      "use strict";
    }
  });

  // extension/platforms/tistory/publishRuntime.ts
  var MazaFatalError, SelfHealingBridge;
  var init_publishRuntime = __esm({
    "extension/platforms/tistory/publishRuntime.ts"() {
      "use strict";
      init_broker();
      init_logger();
      MazaFatalError = class extends Error {
        isFatal = true;
        constructor(message) {
          super(message);
          this.name = "MazaFatalError";
        }
      };
      SelfHealingBridge = class {
        static async ensureHealthy(signal) {
          const isHealthy = await this.ping(signal);
          if (isHealthy) return true;
          try {
            await chrome.runtime.sendMessage({ type: "LOAD_MAIN_WORLD_SCRIPT" }).catch(() => {
            });
            await new Promise((r) => setTimeout(r, 600));
            return await this.ping(signal);
          } catch (e) {
            warn("Bridge", "Lazy initialization check failed", e);
          }
          return false;
        }
        static async ping(signal) {
          const requestId = crypto.randomUUID();
          return new Promise((resolve) => {
            let timeoutId = null;
            let settled = false;
            const broker = MessageBroker.getInstance();
            broker.registerResolver(requestId, (payload) => {
              if (settled) return;
              settled = true;
              if (timeoutId) clearTimeout(timeoutId);
              broker.deregisterResolver(requestId);
              resolve(payload?.type === "MAZA_PONG_RESULT");
            });
            if (signal?.aborted) {
              settled = true;
              broker.deregisterResolver(requestId);
              return resolve(false);
            }
            broker.getChannel().postMessage({
              requestId,
              action: "PING"
            });
            timeoutId = setTimeout(() => {
              if (settled) return;
              settled = true;
              broker.deregisterResolver(requestId);
              resolve(false);
            }, 800);
          });
        }
      };
    }
  });

  // extension/platforms/tistory/publishEditor.ts
  var publishEditor_exports = {};
  __export(publishEditor_exports, {
    CodeMirrorAdapter: () => CodeMirrorAdapter,
    EditorManager: () => EditorManager,
    MonacoAdapter: () => MonacoAdapter,
    ProseMirrorAdapter: () => ProseMirrorAdapter,
    injectTistoryBody: () => injectTistoryBody,
    waitForBodyEditor: () => waitForBodyEditor
  });
  function isEditorElementDetected(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (!el.isConnected || style.display === "none" || style.visibility === "hidden") return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
  function getVisibleEditorCandidate(selectors) {
    for (const sel of selectors) {
      const elems = findAnywhereAll(sel).filter((el) => {
        const id = el.id || "";
        const cls = (el.className || "").toString();
        const aria = el.getAttribute("aria-label") || "";
        const placeholder = el.getAttribute("placeholder") || "";
        const isTitleField = id.includes("title") || id.includes("tit") || cls.includes("title") || cls.includes("tf_tit") || cls.includes("post-title") || aria.includes("\uC81C\uBAA9") || placeholder.includes("\uC81C\uBAA9");
        if (isTitleField) return false;
        const style = window.getComputedStyle(el);
        if (style.display === "none" || style.visibility === "hidden") return false;
        return el.isConnected;
      });
      if (elems.length) {
        return elems.sort((a, b) => (b.offsetHeight || 0) - (a.offsetHeight || 0))[0];
      }
    }
    return null;
  }
  async function waitForBodyEditor(timeout = 3e4, signal) {
    const selectors = SELECTORS.editor.concat(SELECTORS.editorFallback);
    let editor = null;
    const found = await waitUntil2(() => {
      editor = getVisibleEditorCandidate(selectors);
      return !!editor;
    }, timeout, 200, signal);
    if (found && editor) {
      const detectedEditor = editor;
      info("EditorDetection", `Found editor via state-based wait. Type: ${detectedEditor.tagName}, Class: ${detectedEditor.className || ""}`);
      return editor;
    }
    warn("EditorDetection", "All selectors failed. Trying FALLBACK 1: largest contenteditable");
    const allEditable = findAnywhereAll('[contenteditable], [contenteditable="plaintext-only"]').filter((el) => {
      const style = window.getComputedStyle(el);
      if (style.display === "none" || style.visibility === "hidden") return false;
      const rect = el.getBoundingClientRect();
      return rect.width > 100 && rect.height > 50 && el.isConnected;
    });
    const candidateCounts = {
      contenteditables: findAnywhereAll('[contenteditable], [contenteditable="plaintext-only"]').length,
      textareas: findAnywhereAll("textarea").length,
      iframes: findAnywhereAll("iframe").length,
      bodyLength: document.body?.innerText?.length ?? 0
    };
    info("EditorDetection", "Fallback candidate counts", candidateCounts);
    if (allEditable.length > 0) {
      editor = allEditable.sort((a, b) => {
        const areaA = (a.offsetHeight || 0) * (a.offsetWidth || 0);
        const areaB = (b.offsetHeight || 0) * (b.offsetWidth || 0);
        return areaB - areaA;
      })[0];
      info("EditorDetection", "FALLBACK 1 SUCCESS: Found largest contenteditable", {
        type: editor?.tagName,
        class: editor?.className,
        size: `${editor?.offsetWidth}x${editor?.offsetHeight}`
      });
      return editor;
    }
    warn("EditorDetection", "FALLBACK 1 failed. Trying FALLBACK 2: textarea");
    const textareas = findAnywhereAll("textarea").filter((el) => {
      const style = window.getComputedStyle(el);
      if (style.display === "none" || style.visibility === "hidden") return false;
      return el.isConnected && (el.offsetHeight || 0) > 50;
    });
    if (textareas.length > 0) {
      editor = textareas[0];
      info("EditorDetection", "FALLBACK 2 SUCCESS: Found textarea", {
        id: editor?.id,
        class: editor?.className
      });
      return editor;
    }
    warn("EditorDetection", "FALLBACK 2 failed. Trying FALLBACK 3: iframe");
    const iframes = findAnywhereAll("iframe").filter((el) => {
      const style = window.getComputedStyle(el);
      if (style.display === "none" || style.visibility === "hidden") return false;
      return el.isConnected;
    });
    if (iframes.length > 0) {
      editor = iframes[0];
      info("EditorDetection", "FALLBACK 3 SUCCESS: Found iframe", {
        id: editor?.id,
        title: editor?.title
      });
      return editor;
    }
    error("EditorDetection", "Browser extension permissions issue");
    error("EditorDetection", "Body structure dump", document.body.innerHTML?.slice(0, 1e3));
    error("EditorDetection", "Page URL", window.location.href);
    error("EditorDetection", "Page Title", document.title);
    return null;
  }
  async function injectTistoryBody(html) {
    let lastError = null;
    const maxAttempts = 2;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      if (attempt > 1) {
        warn("EditorInjection", `Retrying injectTistoryBody, attempt ${attempt}/${maxAttempts}`);
      }
      const editor = await waitForBodyEditor(3e4);
      if (!editor) {
        lastError = new Error("waitForBodyEditor returned null");
        warn("EditorInjection", "Editor detection failed before injection", { attempt });
        continue;
      }
      info("EditorInjection", `Attempt ${attempt}: editor detected`, {
        tag: editor.tagName,
        class: editor.className,
        role: editor.getAttribute("role"),
        ariaLabel: editor.getAttribute("aria-label")
      });
      if (editor.tagName === "IFRAME") {
        try {
          const iframeDoc = editor.contentDocument;
          if (iframeDoc) {
            const body = iframeDoc.body;
            body.focus();
            iframeDoc.execCommand("selectAll", false);
            iframeDoc.execCommand("delete", false);
            const inserted = iframeDoc.execCommand("insertHTML", false, html);
            body.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertFromPaste" }));
            if (inserted) {
              await waitUntil2(() => compareSimilarity(html, body.innerHTML || body.textContent || ""), 2e3, 50);
              info("EditorInjection", "Body inserted (iframe mode)");
              return true;
            }
          }
        } catch (e) {
          lastError = e;
          warn("EditorInjection", "iframe inject failed", e);
        }
        continue;
      }
      if (editor.tagName === "TEXTAREA" || editor.tagName === "INPUT") {
        try {
          const success = await reliableSetValue(editor, html);
          if (success) {
            info("EditorInjection", "Body inserted (textarea/input fallback mode)");
            return true;
          }
          warn("EditorInjection", "reliableSetValue failed to set textarea/input value");
        } catch (e) {
          lastError = e;
          warn("EditorInjection", "textarea/input inject failed", e);
        }
        continue;
      }
      editor.focus();
      await waitUntil2(() => document.activeElement === editor, 1e3, 50);
      try {
        editor.innerHTML = "";
        editor.dispatchEvent(new InputEvent("input", { bubbles: true }));
        await waitUntil2(() => (editor.textContent || "").trim().length === 0, 1e3, 50);
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(editor);
        selection?.removeAllRanges();
        selection?.addRange(range);
        document.execCommand("delete", false);
        await waitUntil2(() => (editor.textContent || "").trim().length === 0, 1e3, 50);
        const inserted = document.execCommand("insertHTML", false, html);
        if (inserted) {
          editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertFromPaste" }));
          await waitUntil2(() => compareSimilarity(html, editor.innerHTML || editor.textContent || ""), 2e3, 50);
          info("EditorInjection", "Body inserted (execCommand insertHTML mode)");
          return true;
        }
      } catch (e) {
        lastError = e;
        warn("EditorInjection", "execCommand insertHTML failed, fallback to innerHTML", e);
      }
      try {
        editor.innerHTML = html;
        editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertFromPaste" }));
        editor.dispatchEvent(new Event("change", { bubbles: true }));
        const reactKey = Object.keys(editor).find((k) => k.startsWith("__reactFiber") || k.startsWith("__reactInternals"));
        if (reactKey) {
          info("EditorInjection", "React fiber detected, dispatching synthetic input");
        }
        await waitUntil2(() => compareSimilarity(html, editor.innerHTML || editor.textContent || ""), 2e3, 50);
        info("EditorInjection", "Body inserted (innerHTML fallback mode)");
        return true;
      } catch (e) {
        lastError = e;
        warn("EditorInjection", "innerHTML fallback failed", e);
      }
    }
    error("EditorInjection", "All injectTistoryBody attempts failed", lastError);
    return false;
  }
  var MainWorldAdapter, ProseMirrorAdapter, CodeMirrorAdapter, MonacoAdapter, EditorManager;
  var init_publishEditor = __esm({
    "extension/platforms/tistory/publishEditor.ts"() {
      "use strict";
      init_editor();
      init_broker();
      init_selectors();
      init_dom();
      init_logger();
      init_publishDom();
      init_publishRuntime();
      init_publishDom();
      MainWorldAdapter = class {
        async inject(html, sampleText, signal) {
          const isHealthy = await SelfHealingBridge.ensureHealthy(signal);
          if (!isHealthy) return false;
          const requestId = crypto.randomUUID();
          const editorName = this.getEditorName();
          return new Promise((resolve, reject) => {
            let abortHandler = null;
            let settled = false;
            const broker = MessageBroker.getInstance();
            const cleanup = () => {
              broker.deregisterResolver(requestId);
              if (abortHandler && signal) {
                signal.removeEventListener("abort", abortHandler);
                abortHandler = null;
              }
            };
            const finalize = (ok) => {
              if (settled) return;
              settled = true;
              cleanup();
              if (ok) {
                resolve(true);
                void (async () => {
                  const verified = await this.verify(html, signal);
                  if (!verified) {
                    warn(editorName, "Injection verification did not match immediately; keeping the injected content to avoid duplicate insertion.");
                  }
                })();
              } else {
                resolve(false);
              }
            };
            abortHandler = () => {
              if (settled) return;
              settled = true;
              cleanup();
              reject(new Error(`${editorName} injection aborted`));
            };
            if (signal?.aborted) {
              settled = true;
              return reject(new Error("Aborted"));
            }
            signal?.addEventListener("abort", abortHandler);
            broker.registerResolver(requestId, (payload) => {
              if (settled) return;
              if (payload?.type === "MAZA_INJECT_POST_RESULT") {
                finalize(payload.ok);
              }
            });
            broker.getChannel().postMessage({
              action: "INJECT",
              requestId,
              html
            });
            void (async () => {
              const completed = await waitUntil2(() => settled, 6e3, 100, signal);
              if (!completed && !settled) {
                settled = true;
                cleanup();
                warn(editorName, "Injection timeout.");
                resolve(false);
              }
            })();
          });
        }
        async verify(html, signal) {
          const isHealthy = await SelfHealingBridge.ensureHealthy(signal);
          if (!isHealthy) return false;
          const requestId = crypto.randomUUID();
          return new Promise((resolve) => {
            let settled = false;
            const broker = MessageBroker.getInstance();
            const cleanup = () => {
              broker.deregisterResolver(requestId);
            };
            broker.registerResolver(requestId, (payload) => {
              if (settled) return;
              if (payload?.type === "MAZA_QUERY_RESULT") {
                settled = true;
                cleanup();
                resolve(compareSimilarity(html, payload.value || ""));
              }
            });
            broker.getChannel().postMessage({
              action: "QUERY",
              requestId
            });
            void (async () => {
              const completed = await waitUntil2(() => settled, 3e3, 100, signal);
              if (!completed && !settled) {
                settled = true;
                cleanup();
                resolve(false);
              }
            })();
          });
        }
      };
      ProseMirrorAdapter = class extends MainWorldAdapter {
        detect() {
          const el = findFirst(SELECTORS.editor);
          return isEditorElementDetected(el);
        }
        getEditorName() {
          return "ProseMirrorAdapter";
        }
        supportsTransactionalEditing() {
          return true;
        }
        supportsHtmlModelSync() {
          return false;
        }
        supportsVisualRestoration() {
          return true;
        }
      };
      CodeMirrorAdapter = class extends MainWorldAdapter {
        detect() {
          const el = findAnywhere(SELECTORS.codeEditor.join(","));
          return isEditorElementDetected(el);
        }
        getEditorName() {
          return "CodeMirrorAdapter";
        }
        supportsTransactionalEditing() {
          return false;
        }
        supportsHtmlModelSync() {
          return true;
        }
        supportsVisualRestoration() {
          return false;
        }
      };
      MonacoAdapter = class extends MainWorldAdapter {
        detect() {
          const el = findAnywhere(SELECTORS.monacoEditor.join(","));
          return isEditorElementDetected(el);
        }
        getEditorName() {
          return "MonacoAdapter";
        }
        supportsTransactionalEditing() {
          return false;
        }
        supportsHtmlModelSync() {
          return true;
        }
        supportsVisualRestoration() {
          return false;
        }
      };
      EditorManager = class {
        async ensureDefaultMode(signal) {
          if (signal?.aborted) return false;
          const pMirror = new ProseMirrorAdapter();
          const cMirror = new CodeMirrorAdapter();
          await waitUntil2(() => pMirror.detect() || cMirror.detect() || isVisible(findAnywhere("textarea#tx_canvas_source, textarea.tf_source, #htmlEditor")), 1e4, 200, signal);
          if (pMirror.detect()) {
            return true;
          }
          const isHtmlMode = cMirror.detect() || isVisible(findAnywhere("textarea#tx_canvas_source, textarea.tf_source, #htmlEditor"));
          if (isHtmlMode) {
            let modeBtn = findFirst(SELECTORS.defaultMode);
            if (!modeBtn || !isVisible(modeBtn)) {
              await openEditorModeDropdown();
              modeBtn = findModeOption(["\uAE30\uBCF8\uBAA8\uB4DC", "\uAE30\uBCF8 \uBAA8\uB4DC", "\uAE30\uBCF8"], ["default", "prose", "wysiwyg", "visual"]);
            }
            if (modeBtn && isVisible(modeBtn)) {
              await clickAnywhere(modeBtn);
              return waitUntil2(() => pMirror.detect(), 1e4, 200, signal);
            }
          }
          return pMirror.detect();
        }
        async ensureHtmlMode(signal) {
          if (signal?.aborted) return false;
          const cMirror = new CodeMirrorAdapter();
          const mEditor = new MonacoAdapter();
          const detectHtmlMode = () => {
            if (cMirror.detect() || mEditor.detect()) return true;
            const rawTA = findAnywhere("textarea#tx_canvas_source, textarea.tf_source, #htmlEditor");
            return rawTA ? isVisible(rawTA) : false;
          };
          if (detectHtmlMode()) {
            info("Editor", "HTML mode already active");
            return true;
          }
          const htmlToggle = findAnywhere(SELECTORS.htmlEditorToggle.join(","));
          if (htmlToggle && isVisible(htmlToggle)) {
            info("Editor", "HTML mode toggle found, clicking to switch editor");
            htmlToggle.click();
            const ok = await waitUntil2(detectHtmlMode, 1e4, 200, signal);
            if (ok) {
              await new Promise((r) => setTimeout(r, 800));
              info("Editor", "HTML mode settled (via toggle)");
            }
            return ok;
          }
          await openEditorModeDropdown();
          const htmlModeBtn = findModeOption([
            "HTML\uBAA8\uB4DC",
            "HTML \uBAA8\uB4DC",
            "HTML",
            "html",
            "\uC18C\uC2A4",
            "\uC18C\uC2A4\uBCF4\uAE30",
            "\uC18C\uC2A4 \uBAA8\uB4DC",
            "HTML Source"
          ], ["html", "source", "code"]);
          if (htmlModeBtn && isVisible(htmlModeBtn)) {
            info("Editor", "HTML mode option found in dropdown, clicking it");
            htmlModeBtn.click();
            const ok = await waitUntil2(detectHtmlMode, 1e4, 200, signal);
            if (ok) {
              await new Promise((r) => setTimeout(r, 800));
              info("Editor", "HTML mode settled (via dropdown)");
            }
            return ok;
          }
          warn("Editor", "HTML mode could not be activated; continuing with current editor mode");
          return false;
        }
        async restoreDefaultMode(signal) {
          return this.ensureDefaultMode(signal);
        }
        async runInjectionFlow(html, sampleText, signal, telemetry) {
          const adapters = [
            { inst: new CodeMirrorAdapter(), name: "CODEMIRROR" },
            { inst: new ProseMirrorAdapter(), name: "PROSEMIRROR" }
          ];
          for (let attempt = 1; attempt <= 3; attempt++) {
            if (signal?.aborted) break;
            for (const adapter of adapters) {
              if (adapter.inst.detect()) {
                info("Editor", `Detection Attempt ${attempt}/3: Detected ${adapter.name}. Executing injection flow...`);
                const ok = await adapter.inst.inject(html, sampleText, signal);
                if (ok) {
                  telemetry?.setAdapterType(adapter.name);
                  return adapter.name;
                }
              }
            }
            if (attempt < 3) {
              await waitUntil2(() => adapters.some((adapter) => adapter.inst.detect()), 1200, 100, signal);
            }
          }
          return "NONE";
        }
      };
    }
  });

  // extension/platforms/tistory/publish.ts
  init_broker();
  init_publishDom();

  // extension/platforms/tistory/actions/editor.ts
  init_dom();

  // extension/utils/delay.ts
  async function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  // extension/platforms/tistory/actions/editor.ts
  init_selectors();
  init_logger();
  function assertNotAborted(signal) {
    if (signal?.aborted) {
      throw new Error("PUBLISH_FLOW_ABORTED");
    }
  }
  async function injectBody(html, signal) {
    try {
      assertNotAborted(signal);
      info("Editor", "Attempting MainWorld injection");
      const { EditorManager: EditorManager2, injectTistoryBody: injectTistoryBody2 } = await Promise.resolve().then(() => (init_publishEditor(), publishEditor_exports));
      const editorManager = new EditorManager2();
      const injectedAdapter = await editorManager.runInjectionFlow(html, "sampleText", signal);
      if (injectedAdapter !== "NONE") {
        info("Editor", `Body content successfully injected via MainWorld (${injectedAdapter})`);
        return;
      }
      info("Editor", "MainWorld injection failed or not applicable, falling back to content script injection");
      const fallbackSuccess = await injectTistoryBody2(html);
      if (!fallbackSuccess) {
        throw new Error("HTML_INJECTION_FAILED");
      }
      info("Editor", "Body content successfully injected via fallback");
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      error("Editor", `Failed to inject body: ${errMsg}`, { htmlLength: html.length });
      throw err;
    }
  }

  // extension/platforms/tistory/actions/category.ts
  init_dom();
  init_selectors();
  init_logger();
  async function selectCategoryById(categoryId) {
    if (!categoryId) {
      warn("Category", "Category ID is empty, skipping category selection");
      return true;
    }
    try {
      info("Category", `Searching for category selector button`);
      const button = findFirst(SELECTORS.category.button);
      if (!button) {
        warn("Category", "Category selector button not found");
        return false;
      }
      info("Category", "Found category selector, clicking to open dropdown");
      button.click();
      await sleep(500);
      const options = findAnywhereAll(SELECTORS.category.option.join(","));
      info("Category", `Found ${options.length} category option(s)`);
      const target = options.find((option) => {
        const dataCategoryId = option.getAttribute("data-category-id");
        const dataId = option.getAttribute("data-id");
        const elementId = option.getAttribute("id");
        return dataCategoryId === categoryId || dataId === categoryId || elementId === categoryId;
      });
      if (!target) {
        const availableIds = options.map((o) => o.getAttribute("data-category-id") || o.getAttribute("data-id") || o.getAttribute("id")).filter(Boolean).join(", ");
        warn("Category", `Category ID "${categoryId}" not found in options. Available IDs: ${availableIds}`);
        return false;
      }
      info("Category", `Found matching category ID: "${categoryId}", clicking`);
      target.click();
      await sleep(500);
      info("Category", `Category with ID "${categoryId}" selected successfully`);
      return true;
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      error("Category", `Category selection error: ${errMsg}`, { categoryId });
      return false;
    }
  }

  // extension/platforms/tistory/actions/validation.ts
  init_logger();
  init_selectors();
  init_dom();

  // extension/utils/tistory-detector.ts
  init_dom();
  function detectTistoryVersion() {
    const versionMeta = findAnywhere('meta[name="tistory-version"]');
    if (versionMeta?.getAttribute("content")) {
      return versionMeta.getAttribute("content") || "unknown";
    }
    if (findAnywhere('[data-ke-editor="true"]')) {
      return "v2022+ (KE Editor)";
    }
    if (findAnywhere(".se2_inputarea")) {
      return "v2020-2021 (SmartEditor2)";
    }
    if (findAnywhere(".fr-element")) {
      return "Froala Editor";
    }
    return "unknown";
  }

  // extension/platforms/tistory/actions/validation.ts
  init_publishEditor();
  var TITLE_MIN_LENGTH = 3;
  var TITLE_MAX_LENGTH = 120;
  var HTML_MIN_LENGTH = 80;
  var ValidationError = class extends Error {
    constructor(code, message, details) {
      super(message);
      this.code = code;
      this.details = details;
      this.name = "ValidationError";
    }
    code;
    details;
  };
  async function validatePublishState(knownEditor) {
    try {
      info("Validation", "Starting publish state validation");
      const tistoryVersion = detectTistoryVersion();
      info("Validation", `Detected Tistory version: ${tistoryVersion}`);
      const getPageText = () => {
        const rootText = document.documentElement?.innerText || document.body?.innerText || "";
        let iframeText = "";
        const iframes = Array.from(document.querySelectorAll("iframe"));
        for (const iframe of iframes) {
          try {
            const doc = iframe.contentDocument || iframe.contentWindow?.document;
            if (doc) {
              iframeText += "\n" + (doc.documentElement?.innerText || doc.body?.innerText || "");
            }
          } catch {
          }
        }
        return (rootText + "\n" + iframeText).trim();
      };
      const pageText = getPageText();
      const bodyText = document.body?.innerText || "";
      const invalidPageMarkers = [
        "\uC798\uBABB\uB41C \uC694\uCCAD\uC785\uB2C8\uB2E4",
        "\uC798\uBABB\uB41C \uC811\uADFC",
        "\uC11C\uBE44\uC2A4 \uC774\uC6A9\uC5D0 \uBD88\uD3B8",
        "\uACFC\uB3C4\uD55C \uC811\uADFC \uC694\uCCAD\uC73C\uB85C",
        "\uC774 \uD398\uC774\uC9C0\uB294 \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4",
        "\uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4",
        "\uC790\uB3D9\uD654\uB41C \uC811\uADFC",
        "\uC790\uB3D9\uD654\uB41C \uC811\uADFC \uC694\uCCAD",
        "IP \uC8FC\uC18C",
        "\uBE14\uB85C\uADF8 \uC0AC\uC6A9\uC774 \uC7A0\uC2DC \uC911\uB2E8\uB418\uC5C8\uC2B5\uB2C8\uB2E4"
      ];
      if (invalidPageMarkers.some((marker) => pageText.includes(marker))) {
        const message = "Tistory\uAC00 \uACFC\uB3C4\uD55C \uC811\uADFC\uC73C\uB85C \uC784\uC2DC \uCC28\uB2E8\uB41C \uD398\uC774\uC9C0\uB97C \uBC18\uD658\uD588\uC2B5\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.";
        error("Validation", message, {
          pageTitle: document.title,
          pageUrl: window.location.href,
          snippet: pageText.slice(0, 200)
        });
        throw new ValidationError("PAGE_BLOCKED", message, {
          pageTitle: document.title,
          pageUrl: window.location.href
        });
      }
      const isManageWritePage = /\/manage\/(post|pages?)\/write|manage\/newpost/.test(window.location.href);
      if (document.title.trim().length === 0 && bodyText.trim().length < 80) {
        const waitMessage = isManageWritePage ? "Manage write page is blank; waiting longer for page shell." : "Page appears not ready, waiting for content to load.";
        info("Validation", waitMessage, {
          readyState: document.readyState,
          bodyChildCount: document.body?.childElementCount,
          bodyLength: bodyText.length
        });
        const ready = await waitUntil(
          () => {
            const textLen = (document.body?.innerText || "").trim().length;
            const childCount = document.body?.childElementCount ?? 0;
            return document.readyState === "complete" || textLen > 120 || childCount >= 2 || !!document.querySelector("[contenteditable], textarea, iframe");
          },
          isManageWritePage ? 3e4 : 6e3,
          300
        );
        if (!ready) {
          if (!isManageWritePage) {
            const message = "Tistory \uD398\uC774\uC9C0\uAC00 \uC544\uC9C1 \uC644\uC804\uD788 \uB85C\uB4DC\uB418\uC9C0 \uC54A\uC558\uAC70\uB098 \uBE48 \uC0C1\uD0DC\uC785\uB2C8\uB2E4. \uD398\uC774\uC9C0\uB97C \uC0C8\uB85C\uACE0\uCE68 \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.";
            error("Validation", message, {
              pageTitle: document.title,
              pageUrl: window.location.href,
              bodyLength: bodyText.length
            });
            throw new ValidationError("PAGE_NOT_READY", message, {
              pageTitle: document.title,
              pageUrl: window.location.href
            });
          }
          warn("Validation", "Manage write page remained blank after extended wait; continuing with editor detection to avoid false early failure.");
        }
      }
      const editorSelectors = SELECTORS.editor.concat(SELECTORS.editorFallback);
      let editor = knownEditor || null;
      if (!editor) {
        editor = await waitForElement(editorSelectors, 3e4);
        if (!editor) {
          info("Validation", "Editor not found using standard selectors. Falling back to generic contenteditable search.");
          editor = await waitForBodyEditor(2e4);
        }
      } else {
        info("Validation", "Editor already found by prepareEditor \u2014 skipping re-detection.");
      }
      if (!editor) {
        const details = { selectors: editorSelectors };
        error("Validation", `Editor not found using selectors: ${editorSelectors.join(" | ")}`, details);
        throw new ValidationError("EDITOR_NOT_FOUND", "Editor element was not found on the current page.", details);
      }
      const titleField = await waitForElement(SELECTORS.title, 5e3);
      if (!titleField) {
        const details = { selectors: SELECTORS.title };
        error("Validation", `Title field not found using selectors: ${SELECTORS.title.join(" | ")}`, details);
        throw new ValidationError("TITLE_FIELD_NOT_FOUND", "Title field could not be located in the editor form.", details);
      }
      info("Validation", "Editor found, Tistory page structure validated (publish button check deferred)");
      return true;
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      error("Validation", `Publish state validation failed: ${errMsg}`);
      throw err;
    }
  }
  function validatePublishPayload(payload) {
    const title = payload.title?.trim() ?? "";
    const html = payload.html?.trim() ?? "";
    if (!title || title.length < TITLE_MIN_LENGTH) {
      const message = `TITLE_TOO_SHORT: Title must be at least ${TITLE_MIN_LENGTH} characters.`;
      error("Validation", message);
      throw new Error(message);
    }
    if (title.length > TITLE_MAX_LENGTH) {
      const message = `TITLE_TOO_LONG: Title must be ${TITLE_MAX_LENGTH} characters or less.`;
      error("Validation", message);
      throw new Error(message);
    }
    if (!html || html.length < HTML_MIN_LENGTH) {
      const message = `EMPTY_BODY: Body content must be at least ${HTML_MIN_LENGTH} characters.`;
      error("Validation", message);
      throw new Error(message);
    }
    if (payload.tags?.length && payload.tags.length > 20) {
      warn("Validation", `Publish payload contains ${payload.tags.length} tags. Only the first 20 will be used.`);
    }
    info("Validation", "Publish payload validated", {
      titleLength: title.length,
      htmlLength: html.length,
      tags: payload.tags?.length ?? 0,
      category: payload.category
    });
    return true;
  }

  // extension/platforms/tistory/workflow/editor.ts
  init_selectors();
  init_dom();
  init_publishDom();
  init_logger();
  async function prepareEditor(signal) {
    if (signal?.aborted) {
      warn("Editor", "prepareEditor aborted");
      return null;
    }
    info("Editor", "Starting editor preparation");
    const pageText = document.documentElement?.innerText || document.body?.innerText || "";
    const blockedMarkers = [
      "\uC11C\uBE44\uC2A4 \uC774\uC6A9\uC5D0 \uBD88\uD3B8\uC744 \uB4DC\uB824 \uC8C4\uC1A1\uD569\uB2C8\uB2E4.",
      "\uACFC\uB3C4\uD55C \uC811\uADFC \uC694\uCCAD\uC73C\uB85C \uBE14\uB85C\uADF8 \uC0AC\uC6A9\uC774 \uC7A0\uC2DC \uC911\uB2E8\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
      "\uC790\uB3D9\uD654\uB41C \uC811\uADFC",
      "\uC811\uADFC \uC694\uCCAD",
      "IP \uC8FC\uC18C",
      "Too Many Requests",
      "429"
    ];
    if (blockedMarkers.some((marker) => pageText.includes(marker))) {
      warn("Editor", "Tistory blocked page detected. Aborting editor preparation.");
      throw new Error("Tistory blocked page detected: too many requests or automated access restriction.");
    }
    const cancelDraftBtn = findFirst(SELECTORS.cancelDraftBtn);
    if (cancelDraftBtn) {
      info("Editor", "Closing existing draft dialog");
      await new Promise((resolve) => requestAnimationFrame(() => {
        cancelDraftBtn.click();
        resolve();
      }));
      await sleep(600);
    }
    const editorSelectors = SELECTORS.editor.concat(SELECTORS.editorFallback);
    const isListPage = window.location.href.includes("/manage/") && !window.location.href.includes("/write") && !window.location.href.includes("/newpost") && !window.location.href.includes("/edit");
    if (!isListPage) {
      const editorFound = await waitForEditorWithObserver(editorSelectors, signal);
      if (editorFound) {
        info("Editor", "Editor found and ready (MutationObserver)");
        const el = editorSelectors.map((s) => findAnywhere(s)).find((e) => e?.isConnected) || null;
        return el;
      }
    }
    if (!signal?.aborted && window.location.href.includes("/manage/")) {
      let writeBtn = findFirst(SELECTORS.writeBtn);
      if (!writeBtn) {
        const isPageManage = /\/manage\/pages?(?:\/|$)/.test(window.location.href);
        const fallbackTexts = isPageManage ? ["\uC0C8 \uD398\uC774\uC9C0 \uC4F0\uAE30", "\uD398\uC774\uC9C0 \uC4F0\uAE30", "\uC0C8 \uD398\uC774\uC9C0", "\uD398\uC774\uC9C0 \uB9CC\uB4E4\uAE30"] : ["\uAE00\uC4F0\uAE30", "\uC0C8 \uAE00", "\uC0C8 \uD3EC\uC2A4\uD2B8", "\uC0C8 \uAE00\uC4F0\uAE30", "\uC0C8 \uAC8C\uC2DC\uBB3C"];
        writeBtn = fallbackTexts.map((text) => findByTextAnywhere(text)).find((el) => !!el) || null;
      }
      if (writeBtn) {
        info("Editor", "Found write button, dispatching reactClick to open editor via SPA router");
        await reactClick(void 0, writeBtn.textContent || void 0);
        const editorFoundAfterClick = await waitForEditorWithObserver(editorSelectors, signal, 2e4);
        if (editorFoundAfterClick) {
          info("Editor", "Editor appeared after write button click");
          const el = editorSelectors.map((s) => findAnywhere(s)).find((e) => e?.isConnected) || null;
          return el;
        }
      } else if (isListPage) {
        warn("Editor", "Write button not found on list page \u2014 attempting href navigation to write URL");
        const isPageManage = /\/manage\/pages?(?:\/|$)/.test(window.location.href);
        const writeUrl = isPageManage ? window.location.href.replace(/\/manage\/pages?\/?.*$/, "/manage/pages/write") : window.location.href.replace(/\/manage\/.*$/, "/manage/newpost/");
        window.location.href = writeUrl;
        return null;
      }
    }
    warn("Editor", "Editor not found after 25s timeout");
    return null;
  }
  function waitForEditorWithObserver(selectors, signal, timeoutMs = 25e3) {
    return new Promise((resolve) => {
      if (signal?.aborted) {
        resolve(false);
        return;
      }
      for (const sel of selectors) {
        const el = findAnywhere(sel);
        if (el && el.isConnected) {
          resolve(true);
          return;
        }
      }
      const timer = setTimeout(() => {
        observer.disconnect();
        resolve(false);
      }, timeoutMs);
      const abortHandler = () => {
        clearTimeout(timer);
        observer.disconnect();
        resolve(false);
      };
      signal?.addEventListener("abort", abortHandler, { once: true });
      const observer = new MutationObserver(() => {
        for (const sel of selectors) {
          const el = findAnywhere(sel);
          if (el && el.isConnected) {
            clearTimeout(timer);
            signal?.removeEventListener("abort", abortHandler);
            observer.disconnect();
            resolve(true);
            return;
          }
        }
      });
      const startObserving = () => {
        if (!document.documentElement) {
          if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", startObserving, { once: true });
          } else {
            setTimeout(startObserving, 100);
          }
          return;
        }
        observer.observe(document.documentElement, { childList: true, subtree: true });
      };
      startObserving();
    });
  }
  async function injectTitle(title, signal) {
    if (signal?.aborted) {
      warn("Editor", "injectTitle aborted");
      return false;
    }
    info("Editor", `Starting to inject title: "${title}"`);
    let titleEl = await waitForElement(SELECTORS.title, 1e4);
    if (!titleEl && signal?.aborted) {
      warn("Editor", "Title element search aborted");
      return false;
    }
    if (!titleEl && window.location.href.includes("/manage/page")) {
      info("Editor", "Searching for title element on manage page");
      titleEl = findFirst(SELECTORS.title);
    }
    if (!titleEl) {
      warn("Editor", "Title element not found");
      if (signal?.aborted) {
        warn("Editor", "Write button search aborted");
        return false;
      }
      const listWriteBtn = findFirst(SELECTORS.writeBtn);
      if (listWriteBtn) {
        listWriteBtn.click();
        return false;
      }
      return false;
    }
    try {
      titleEl.focus?.();
    } catch (e) {
      debug("Editor", "Expected focus exception caught while setting title", e);
    }
    info("Editor", `Setting title value: "${title}"`);
    if ("value" in titleEl) {
      titleEl.value = title;
    } else {
      titleEl.textContent = title;
    }
    const nativeSetter = Object.getOwnPropertyDescriptor(
      Object.getPrototypeOf(titleEl),
      "value"
    )?.set;
    if (nativeSetter && "value" in titleEl) {
      nativeSetter.call(titleEl, title);
    }
    titleEl.dispatchEvent(new Event("input", { bubbles: true }));
    titleEl.dispatchEvent(new Event("change", { bubbles: true }));
    try {
      titleEl.blur?.();
    } catch (e) {
      debug("Editor", "Expected blur exception caught after title injection", e);
    }
    await sleep(50);
    info("Editor", "Title injection completed successfully");
    return true;
  }

  // extension/platforms/tistory/workflow/thumbnail.ts
  init_dom();
  init_selectors();
  init_logger();
  async function replaceImagesWithTistoryCDN(html) {
    const imgRegex = /<img([^>]*?)src="(https?:\/\/(?!.*\.tistory\.com)([^"]+))"([^>]*?)>/gi;
    const matches = [];
    let m;
    while ((m = imgRegex.exec(html)) !== null) {
      matches.push({ full: m[0], src: m[2] });
    }
    if (matches.length === 0) {
      const markdownMatch = html.match(/!\[[^\]]*\]\((https?:\/\/[^\s)]+)\)/i);
      if (!markdownMatch) {
        info("Thumbnail", "No external images found, using HTML as-is");
        return html;
      }
      const markdownSrc = markdownMatch[1];
      info("Thumbnail", `Found external markdown image, uploading: ${markdownSrc}`);
      const cdnUrl2 = await uploadImageToTistory(markdownSrc);
      if (cdnUrl2) {
        info("Thumbnail", `Successfully converted markdown image to CDN URL: ${cdnUrl2}`);
        return html.replace(markdownMatch[1], cdnUrl2);
      }
      warn("Thumbnail", "Failed to upload markdown image to CDN, proceeding with external URL");
      return html;
    }
    const first = matches[0];
    info("Thumbnail", `Found ${matches.length} external images`);
    info("Thumbnail", `Uploading first image: ${first.src}`);
    const cdnUrl = await uploadImageToTistory(first.src);
    if (cdnUrl) {
      info("Thumbnail", `Successfully converted to CDN URL: ${cdnUrl}`);
      const replaced = html.replace(first.full, first.full.replace(first.src, cdnUrl));
      info("Thumbnail", `HTML updated with CDN image`);
      return replaced;
    }
    warn("Thumbnail", "Failed to upload image to CDN, proceeding with external URL");
    return html;
  }
  function extractRepresentativeThumbnailUrl(html) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    const img = findAnywhere(SELECTORS.thumbnail.preview.join(","), doc);
    if (img?.src) return img.src;
    if (img?.dataset.src) return img.dataset.src;
    const fallbackImg = doc.querySelector("img");
    if (fallbackImg?.src) return fallbackImg.src;
    if (fallbackImg?.dataset.src) return fallbackImg.dataset.src;
    const markdownMatch = html.match(/!\[[^\]]*\]\((https?:\/\/[^\s)]+)\)/i);
    if (markdownMatch) return markdownMatch[1];
    return null;
  }
  function getPublishLayerRoot() {
    return findFirst(SELECTORS.publishLayer) || document;
  }
  function isVisible2(element) {
    if (!element) return false;
    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none" && style.opacity !== "0";
  }
  var THUMBNAIL_HINTS = [
    "\uC378\uB124\uC77C",
    "\uB300\uD45C\uC774\uBBF8\uC9C0",
    "\uB300\uD45C \uC774\uBBF8\uC9C0",
    "\uB300\uD45C \uC0AC\uC9C4",
    "\uB300\uD45C",
    "\uC774\uBBF8\uC9C0",
    "\uC0AC\uC9C4",
    "\uCCA8\uBD80",
    "thumbnail",
    "cover",
    "photo",
    "image",
    "\uB300\uD45C \uC124\uC815",
    "\uB300\uD45C \uC120\uD0DD",
    "\uB300\uD45C \uB4F1\uB85D"
  ];
  function hasThumbnailHint(el) {
    const text = el.textContent?.trim().toLowerCase() || "";
    const aria = (el.getAttribute("aria-label") || "").toLowerCase();
    const title = (el.getAttribute("title") || "").toLowerCase();
    const cls = (el.className || "").toString().toLowerCase();
    const id = (el.id || "").toLowerCase();
    const dataTest = (el.getAttribute("data-testid") || "").toLowerCase();
    return THUMBNAIL_HINTS.some(
      (hint) => text.includes(hint) || aria.includes(hint) || title.includes(hint) || cls.includes(hint) || id.includes(hint) || dataTest.includes(hint)
    );
  }
  function findThumbnailButton() {
    const root = getPublishLayerRoot();
    let candidates = findAnywhereAll(SELECTORS.thumbnail.button.join(","), root);
    if (candidates.length === 0 && root !== document) {
      candidates = findAnywhereAll(SELECTORS.thumbnail.button.join(","), document);
    }
    for (const el of candidates) {
      if (!isVisible2(el)) continue;
      if (hasThumbnailHint(el)) return el;
    }
    const broadCandidates = findAnywhereAll('button, a, label, [role="button"], div, span', root);
    if (root !== document) {
      broadCandidates.push(...findAnywhereAll('button, a, label, [role="button"], div, span', document));
    }
    for (const el of broadCandidates) {
      if (!isVisible2(el)) continue;
      if (!hasThumbnailHint(el)) continue;
      if (el.tagName === "DIV" || el.tagName === "SPAN") {
        const onclick = el.getAttribute("onclick");
        if (!onclick && !el.closest('button, a, label, [role="button"]')) continue;
      }
      return el;
    }
    return null;
  }
  function summarizeElement(el) {
    return {
      tag: el.tagName,
      text: (el.textContent || "").trim().slice(0, 120),
      aria: (el.getAttribute("aria-label") || "").trim(),
      id: el.id || "",
      cls: el.className || "",
      visible: isVisible2(el),
      html: el.outerHTML.slice(0, 400)
    };
  }
  function collectThumbnailDiagnostics(root) {
    const buttons = findAnywhereAll(SELECTORS.thumbnail.button.join(","), root);
    const wideButtons = findAnywhereAll('button, a, label, [role="button"]', root);
    const inputs = findAnywhereAll('input[type="file"]', root);
    return {
      publishLayerFound: !!findFirst(SELECTORS.publishLayer),
      buttonSelectors: SELECTORS.thumbnail.button,
      uploadInputSelectors: SELECTORS.uploadInput,
      buttonCandidates: buttons.slice(0, 10).map(summarizeElement),
      broadButtonCandidates: wideButtons.slice(0, 10).map(summarizeElement),
      fileInputs: inputs.slice(0, 5).map((input) => ({
        id: input.id || "",
        cls: input.className || "",
        name: input.name || "",
        accept: input.accept || "",
        visible: isVisible2(input),
        html: input.outerHTML.slice(0, 250)
      }))
    };
  }
  function sendThumbnailDebugSnapshot(root, reason) {
    const snapshot = root instanceof Element ? root.outerHTML.slice(0, 2e3) : document.body.innerHTML.slice(0, 2e3);
    const detail = {
      reason,
      rootType: root instanceof Element ? root.tagName : "document",
      snapshot,
      diagnostics: collectThumbnailDiagnostics(root)
    };
    try {
      chrome.runtime.sendMessage({ type: "MAZA_INFRA_PROGRESS", step: "THUMBNAIL_DEBUG_DOM", detail }).catch(() => {
      });
    } catch (e) {
      console.debug("[MAZA OS] THUMBNAIL_DEBUG_DOM send failed", e);
    }
  }
  async function waitForUploadFileInput(signal) {
    const root = getPublishLayerRoot();
    const existing = findAnywhereAll(SELECTORS.uploadInput[0], root).filter((el) => el.isConnected);
    for (const input of existing) {
      if (input.files?.length === 0) {
        return input;
      }
    }
    if (root !== document) {
      const documentInputs = findAnywhereAll(SELECTORS.uploadInput[0], document).filter((el) => el.isConnected);
      for (const input of documentInputs) {
        if (input.files?.length === 0) {
          return input;
        }
      }
    }
    return new Promise((resolve) => {
      const uploadRoot = root instanceof Document ? document.body : root;
      const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          for (const node of Array.from(mutation.addedNodes)) {
            if (!(node instanceof HTMLElement)) continue;
            const fileInput = node.matches('input[type="file"]') ? node : findAnywhere('input[type="file"]', node);
            if (fileInput) {
              observer.disconnect();
              resolve(fileInput);
              return;
            }
          }
        }
      });
      observer.observe(uploadRoot, { childList: true, subtree: true });
      if (signal) {
        signal.addEventListener("abort", () => {
          observer.disconnect();
          resolve(null);
        }, { once: true });
      }
      setTimeout(() => {
        observer.disconnect();
        resolve(null);
      }, 8e3);
    });
  }
  async function waitForThumbnailConfirm(root, signal) {
    const confirmTexts = ["\uD655\uC778", "\uD655\uC778\uD558\uAE30", "\uC801\uC6A9", "\uC644\uB8CC", "\uB4F1\uB85D", "\uC800\uC7A5", "\uC5C5\uB85C\uB4DC"];
    const deadline = Date.now() + 7e3;
    while (Date.now() < deadline) {
      if (signal?.aborted) return null;
      for (const text of confirmTexts) {
        const button = findByTextAnywhere(text, root);
        if (button && isVisible2(button)) return button;
      }
      await sleep(300);
    }
    return null;
  }
  async function waitForThumbnailPreview(root, signal) {
    const deadline = Date.now() + 7e3;
    while (Date.now() < deadline) {
      if (signal?.aborted) return false;
      const preview = findAnywhere(SELECTORS.thumbnail.preview.join(","), root);
      if (preview && preview.src && isVisible2(preview)) {
        return true;
      }
      await sleep(300);
    }
    return false;
  }
  async function uploadThumbnailToPublishLayer(thumbnailImgUrl, signal) {
    if (signal?.aborted) {
      warn("Thumbnail", "uploadThumbnailToPublishLayer aborted");
      return false;
    }
    notifyProgress("THUMBNAIL_UPLOAD_START", thumbnailImgUrl);
    info("Thumbnail", `Starting thumbnail upload: ${thumbnailImgUrl}`);
    await waitUntil(() => !!findFirst(SELECTORS.publishLayer), 1e3, 300, signal);
    let thumbnailButton = null;
    await waitUntil(() => {
      thumbnailButton = findThumbnailButton();
      return !!thumbnailButton;
    }, 6e3, 200, signal);
    if (!thumbnailButton) {
      warn("Thumbnail", "Thumbnail button not found in publish layer");
      notifyProgress("THUMBNAIL_UPLOAD_FAIL", "Thumbnail button not found");
      sendThumbnailDebugSnapshot(getPublishLayerRoot(), "button-not-found");
      try {
        const probes = findAnywhereAll('button, a, label, [role="button"], .thumbnail, .thumb, .cover');
        const samples = probes.filter((el) => (el.textContent || "").trim().length > 0 || (el.getAttribute("aria-label") || "").trim().length > 0).slice(0, 5).map((el) => ({ text: (el.textContent || "").trim().slice(0, 120), aria: el.getAttribute("aria-label") || "", id: el.id || "", cls: el.className || "" }));
        try {
          chrome.runtime.sendMessage({ type: "MAZA_INFRA_PROGRESS", step: "THUMB_PROBES", detail: samples }).catch(() => {
          });
        } catch (e) {
        }
      } catch (e) {
      }
      return false;
    }
    clickAnywhere(thumbnailButton);
    await sleep(300);
    let fileInput = await waitForUploadFileInput(signal);
    if (!fileInput) {
      const retryButton = findThumbnailButton();
      if (retryButton) {
        clickAnywhere(retryButton);
        await sleep(300);
        fileInput = await waitForUploadFileInput(signal);
      }
    }
    if (!fileInput) {
      warn("Thumbnail", "File input for thumbnail upload did not appear");
      notifyProgress("THUMBNAIL_UPLOAD_FAIL", "File input did not appear");
      sendThumbnailDebugSnapshot(getPublishLayerRoot(), "file-input-not-found");
      return false;
    }
    const blob = await fetchImageBlob(thumbnailImgUrl);
    if (!blob) {
      warn("Thumbnail", "Unable to fetch thumbnail image blob");
      return false;
    }
    const extension = thumbnailImgUrl.toLowerCase().includes(".png") ? "png" : "jpg";
    const fileName = `maza_thumbnail_${Date.now()}.${extension}`;
    const file = new File([blob], fileName, { type: blob.type || `image/${extension}` });
    const dt = new DataTransfer();
    dt.items.add(file);
    fileInput.files = dt.files;
    fileInput.dispatchEvent(new Event("change", { bubbles: true }));
    const root = getPublishLayerRoot();
    const confirmButton = await waitForThumbnailConfirm(root, signal);
    if (confirmButton) {
      clickAnywhere(confirmButton);
      await sleep(800);
      notifyProgress("THUMBNAIL_UPLOAD_SUCCESS", thumbnailImgUrl);
      return true;
    }
    warn("Thumbnail", "Thumbnail confirm button not found, checking preview as fallback");
    const previewSuccess = await waitForThumbnailPreview(root, signal);
    if (previewSuccess) {
      info("Thumbnail", "Thumbnail preview detected after upload, marking upload as successful");
      notifyProgress("THUMBNAIL_UPLOAD_SUCCESS", thumbnailImgUrl);
      return true;
    }
    warn("Thumbnail", "Thumbnail upload did not complete or confirm button was missing");
    notifyProgress("THUMBNAIL_UPLOAD_FAIL", "Upload confirm button missing");
    return false;
  }
  function detectTistoryUploadEndpoints(blogDomain) {
    const known = [
      { url: `https://${blogDomain}/upload`, field: "image" },
      { url: `https://${blogDomain}/upload/image`, field: "image" },
      { url: `https://${blogDomain}/manage/attachment/upload`, field: "uploadedfile" },
      { url: `https://${blogDomain}/manage/upload`, field: "image" },
      { url: `https://${blogDomain}/photo/upload`, field: "image" }
    ];
    const forms = findAnywhereAll(SELECTORS.uploadForm.join(","));
    for (const form of forms) {
      const action = form.getAttribute("action")?.trim();
      if (!action) continue;
      let url = action;
      if (url.startsWith("/")) {
        url = `https://${blogDomain}${url}`;
      }
      if (!url.includes(blogDomain)) continue;
      if (!findAnywhere('input[type="file"]', form)) continue;
      known.push({ url, field: "image" });
    }
    const unique = /* @__PURE__ */ new Map();
    for (const candidate of known) {
      unique.set(`${candidate.url}|${candidate.field}`, candidate);
    }
    return Array.from(unique.values());
  }
  async function fetchImageBlob(imageUrl) {
    if (typeof chrome !== "undefined" && typeof chrome.runtime?.sendMessage === "function") {
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: "FETCH_IMAGE", url: imageUrl }, resolve);
      });
      if (!response.ok || !response.dataUrl) {
        warn("Thumbnail", `Background image fetch failed: ${response.error || "unknown error"}`);
        return null;
      }
      const dataResponse = await fetch(response.dataUrl);
      if (!dataResponse.ok) {
        warn("Thumbnail", `Data URL fetch failed: ${dataResponse.status}`);
        return null;
      }
      return await dataResponse.blob();
    }
    try {
      const res = await fetch(imageUrl);
      if (!res.ok) {
        warn("Thumbnail", `Direct image fetch failed: ${res.status}`);
        return null;
      }
      return await res.blob();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      warn("Thumbnail", `Direct image fetch failed: ${errorMessage}`);
      return null;
    }
  }
  async function uploadImageToTistory(imageUrl) {
    try {
      const blob = await fetchImageBlob(imageUrl);
      if (!blob) {
        throw new Error("Unable to retrieve image blob");
      }
      const blogDomain = window.location.hostname;
      const ext = imageUrl.toLowerCase().includes(".png") ? "png" : "jpg";
      const fileName = `maza_thumb_${Date.now()}.${ext}`;
      const csrfMeta = findFirst(SELECTORS.csrfToken);
      const csrfToken = csrfMeta?.content || "";
      const endpointCandidates = detectTistoryUploadEndpoints(blogDomain);
      const uploadFields = ["image", "uploadedfile", "file", "files[]"];
      for (const candidate of endpointCandidates) {
        const triedFields = [candidate.field, ...uploadFields.filter((f) => f !== candidate.field)];
        for (const field of triedFields) {
          try {
            const formData = new FormData();
            formData.append(field, blob, fileName);
            if (csrfToken) formData.append("_csrf", csrfToken);
            const uploadRes = await fetch(candidate.url, {
              method: "POST",
              body: formData,
              credentials: "include",
              headers: {
                ...csrfToken ? { "X-CSRF-Token": csrfToken } : {},
                "X-Requested-With": "XMLHttpRequest",
                Accept: "application/json, text/plain, */*"
              }
            });
            if (!uploadRes.ok) {
              warn("Thumbnail", `Endpoint ${candidate.url} (field: ${field}) returned ${uploadRes.status}, trying next...`);
              continue;
            }
            const contentType = uploadRes.headers.get("content-type") || "";
            let cdnUrl = null;
            if (contentType.includes("application/json")) {
              const data = await uploadRes.json();
              cdnUrl = data?.url || data?.imageUrl || data?.data?.url || data?.replacer || null;
            } else {
              const text = await uploadRes.text();
              const urlMatch = text.match(/<url>(https?:\/\/[^<]+)<\/url>/i) || text.match(/"url"\s*:\s*"(https?:\/\/[^\"]+)"/i) || text.match(/(https?:\/\/[^"'<>\s]+\.tistory\.com\/[^"'<>\s]+)/i);
              if (urlMatch) cdnUrl = urlMatch[1];
            }
            if (cdnUrl) {
              info("Thumbnail", `Successfully uploaded to ${candidate.url}: ${cdnUrl}`);
              return cdnUrl;
            }
          } catch (err) {
            warn("Thumbnail", `Endpoint ${candidate.url} (field: ${field}) failed`);
          }
        }
      }
      warn("Thumbnail", "All upload endpoints failed, using external URL");
      return null;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      warn("Thumbnail", `Image upload failed (non-fatal): ${errorMessage}`);
      return null;
    }
  }

  // extension/platforms/tistory/workflow/publishLayer.ts
  init_selectors();
  init_dom();
  init_logger();
  function isVisible3(element) {
    if (!element) return false;
    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none" && style.opacity !== "0";
  }
  function isPublishLayerOpen() {
    const layer = findFirst(SELECTORS.publishLayer);
    if (layer) return true;
    const confirm = findFirst(SELECTORS.confirmBtn);
    if (confirm) return true;
    const publishTextBtn = findByTextAnywhere("\uACF5\uAC1C \uBC1C\uD589") || findByTextAnywhere("\uBE44\uACF5\uAC1C \uBC1C\uD589");
    if (publishTextBtn) {
      const style = window.getComputedStyle(publishTextBtn);
      const rect = publishTextBtn.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden") {
        return true;
      }
    }
    return false;
  }
  async function findPublishLayerTrigger() {
    const textCandidates = ["\uACF5\uAC1C \uBC1C\uD589", "\uACF5\uAC1C\uBC1C\uD589", "\uBC1C\uD589", "\uAC8C\uC2DC", "\uC644\uB8CC", "\uAE00 \uBC1C\uD589"];
    for (const text of textCandidates) {
      const button = findByTextAnywhere(text);
      if (button && isVisible3(button)) return button;
    }
    const ariaCandidates = ['button[aria-label*="\uACF5\uAC1C"]', 'button[aria-label*="\uBC1C\uD589"]', 'button[aria-label*="\uAC8C\uC2DC"]'];
    for (const selector of ariaCandidates) {
      const button = findAnywhere(selector);
      if (button && isVisible3(button)) return button;
    }
    const fallback = findFirst(SELECTORS.publishBtn);
    return fallback && isVisible3(fallback) ? fallback : null;
  }
  function clickElement(element) {
    element.focus?.();
    element.click();
    try {
      element.dispatchEvent(new MouseEvent("pointerdown", { bubbles: true, cancelable: true, view: window }));
      element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
      element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
      element.dispatchEvent(new MouseEvent("pointerup", { bubbles: true, cancelable: true, view: window }));
    } catch (err) {
    }
  }
  async function ensurePublishOptions(publishAt) {
    const publicButtons = findAnywhereAll(SELECTORS.publishOption.public.join(",")).filter((el) => ["\uACF5\uAC1C", "Public"].includes(el.textContent?.trim() || ""));
    for (const btn of publicButtons) {
      if (isVisible3(btn)) {
        const alreadySelected = btn.getAttribute("aria-pressed") === "true" || btn.getAttribute("aria-selected") === "true" || btn.classList.contains("active") || btn.classList.contains("selected");
        if (!alreadySelected) {
          btn.click();
          await sleep(200);
        }
      }
    }
    const isScheduled = !!(publishAt && new Date(publishAt).getTime() > Date.now());
    if (isScheduled) {
      info("PublishLayer", `Target publish_at is in the future (${publishAt}). Switching to Reservation Mode.`);
      const rootSearchNode = document.querySelector(".layer_post, #mceu_31, .dialog-publish, .box_post_setting") || document;
      const labels = Array.from(rootSearchNode.querySelectorAll("label"));
      let scheduleTab = labels.find((l) => l.textContent?.trim() === "\uC608\uC57D" || l.textContent?.includes("\uC608\uC57D \uBC1C\uD589")) || null;
      if (!scheduleTab) {
        const fallbackBtns = Array.from(rootSearchNode.querySelectorAll("button, a, span")).filter((el) => el.textContent?.trim() === "\uC608\uC57D");
        if (fallbackBtns.length > 0) scheduleTab = fallbackBtns[0];
      }
      if (scheduleTab) {
        clickElement(scheduleTab);
        const radioInput = document.querySelector('input#pubTime02, input[value="reserve"], input[name="pubTime"][value="2"]');
        if (radioInput && !radioInput.checked) {
          radioInput.checked = true;
          radioInput.dispatchEvent(new Event("change", { bubbles: true }));
        }
        await sleep(800);
        try {
          const d = new Date(publishAt);
          const yy = d.getFullYear().toString();
          const mm = (d.getMonth() + 1).toString().padStart(2, "0");
          const dd = d.getDate().toString().padStart(2, "0");
          const hh = d.getHours().toString().padStart(2, "0");
          let minNum = d.getMinutes();
          if (minNum % 10 !== 0) {
            minNum = Math.ceil(minNum / 10) * 10;
            if (minNum >= 60) minNum = 50;
          }
          const min = minNum.toString().padStart(2, "0");
          const setReactValue = (input, value) => {
            try {
              input.removeAttribute("readonly");
              input.focus();
              const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
              nativeSetter?.call(input, value);
              input.dispatchEvent(new Event("input", { bubbles: true }));
              input.dispatchEvent(new Event("change", { bubbles: true }));
              input.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Enter", code: "Enter" }));
              input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "Enter", code: "Enter" }));
              input.blur();
            } catch (e) {
              console.warn("[MAZA OS] setReactValue error", e);
            }
          };
          const dateInput = document.querySelector('input.tf_date, input#pubDate, input[name="date"]');
          if (dateInput) {
            setReactValue(dateInput, `${yy}-${mm}-${dd}`);
            if (dateInput.value !== `${yy}-${mm}-${dd}`) {
              setReactValue(dateInput, `${yy}. ${mm}. ${dd}.`);
            }
          } else {
            warn("PublishLayer", "Date input not found. Reservation might fail.");
          }
          const timeInput = document.querySelector('input.tf_time, input#pubTime, input[name="time"]');
          if (timeInput) {
            setReactValue(timeInput, `${hh}:${min}`);
          } else {
            warn("PublishLayer", "Time input not found. Reservation might fail.");
          }
          await sleep(500);
        } catch (err) {
          warn("PublishLayer", "Failed to input reservation date/time.", err);
        }
      } else {
        warn("PublishLayer", "Reservation tab not found. Could not set reservation.");
      }
    } else {
      const nowRootSearchNode = document.querySelector(".layer_post, #mceu_31, .dialog-publish, .box_post_setting") || document;
      const nowTabCandidates = [
        document.querySelector('label[for="pubTime01"]'),
        document.querySelector("input#pubTime01"),
        ...Array.from(nowRootSearchNode.querySelectorAll("label")).filter((l) => l.textContent?.includes("\uD604\uC7AC") || l.textContent?.includes("\uC989\uC2DC")),
        ...Array.from(nowRootSearchNode.querySelectorAll("button, a, span")).filter((el) => el.textContent?.trim() === "\uD604\uC7AC" || el.textContent?.trim() === "\uC989\uC2DC \uBC1C\uD589")
      ];
      let nowTab = null;
      for (const el of nowTabCandidates) {
        if (el) {
          if (el.tagName.toLowerCase() === "input" && el.type === "radio") {
            nowTab = el;
            break;
          }
          if (isVisible3(el)) {
            nowTab = el;
            break;
          }
        }
      }
      if (nowTab) {
        clickElement(nowTab);
        await sleep(400);
      }
    }
  }
  function getPublishConfirmButtons() {
    const candidates = [];
    const pagePublishBtn = findByTextAnywhere("\uACF5\uAC1C \uBC1C\uD589");
    if (pagePublishBtn && isVisible3(pagePublishBtn)) candidates.push(pagePublishBtn);
    for (const selector of SELECTORS.confirmBtn) {
      const el = findAnywhere(selector);
      if (el && isVisible3(el) && !candidates.includes(el)) candidates.push(el);
    }
    if (candidates.length > 0) return candidates;
    const fallbackButtons = [
      findByTextAnywhere("\uBC1C\uD589"),
      findByTextAnywhere("\uD655\uC778")
    ].filter((el) => !!el && isVisible3(el));
    return fallbackButtons;
  }
  function getPublishConfirmButton() {
    return getPublishConfirmButtons()[0] || null;
  }
  function normalizeButton(button) {
    button.removeAttribute("disabled");
    button.removeAttribute("aria-disabled");
    button.classList.remove("disabled");
    if ("disabled" in button) {
      try {
        button.disabled = false;
      } catch {
      }
    }
  }
  async function clickConfirmButton(button) {
    normalizeButton(button);
    clickElement(button);
    await sleep(300);
  }
  function reportPublishConfirmedOnce(publishedUrl) {
    const taskId = window.__MAZA_CURRENT_TASK_ID ?? null;
    const lastReportedTaskId = window.__MAZA_PUBLISH_CONFIRMED_TASK_ID ?? null;
    if (taskId && lastReportedTaskId === taskId) {
      return;
    }
    window.__MAZA_PUBLISH_CONFIRMED_TASK_ID = taskId;
    chrome.runtime.sendMessage({
      type: "TASK_CONFIRMED_PUBLISHING",
      publishedUrl,
      taskId
    }).catch((err) => {
      warn("PublishLayer", `Failed to send TASK_CONFIRMED_PUBLISHING message for task ${taskId}:`, err);
    });
  }
  async function openPublishLayer(signal) {
    if (isPublishLayerOpen()) {
      info("PublishLayer", "Publish layer already open");
      return true;
    }
    info("PublishLayer", "Starting to open publish layer...");
    for (let attempt = 1; attempt <= 5; attempt += 1) {
      if (signal?.aborted) {
        warn("PublishLayer", "openPublishLayer aborted");
        return false;
      }
      const trigger = await findPublishLayerTrigger();
      if (trigger) {
        info("PublishLayer", `Attempt ${attempt}: Found publish trigger, clicking`);
        clickElement(trigger);
      } else {
        info("PublishLayer", `Attempt ${attempt}: No trigger found, clicking documentElement`);
        document.documentElement.click();
      }
      await sleep(150 + attempt * 50);
      const opened = await waitUntil(isPublishLayerOpen, 2e3, 100, signal);
      if (opened) {
        info("PublishLayer", `Publish layer opened on attempt ${attempt}`);
        return true;
      }
      warn("PublishLayer", `Attempt ${attempt} failed to open publish layer. Retrying...`);
    }
    warn("PublishLayer", "Failed to open publish layer after 5 attempts");
    return false;
  }
  async function confirmPublish(signal, publishAt) {
    if (!isPublishLayerOpen()) {
      warn("PublishLayer", "Publish layer is not open");
      return false;
    }
    info("PublishLayer", "Starting to confirm publish (Maza scheduler handles timing)");
    let confirmButton = getPublishConfirmButton();
    if (!confirmButton || !isVisible3(confirmButton)) {
      info("PublishLayer", "Immediate text scan failed, waiting for selector-based button...");
      confirmButton = await waitForElement(SELECTORS.confirmBtn, 5e3, signal);
    }
    if (!confirmButton || !isVisible3(confirmButton)) {
      info("PublishLayer", "Confirm button not found in normal selectors, trying fallback");
      confirmButton = getPublishConfirmButton();
    }
    if (!confirmButton || !isVisible3(confirmButton)) {
      const candidates = Array.from(document.querySelectorAll("button, a, div, span")).filter((el) => {
        const text = (el.textContent || "").trim();
        return ["\uACF5\uAC1C \uBC1C\uD589", "\uACF5\uAC1C", "\uBC1C\uD589", "\uAC8C\uC2DC", "\uC644\uB8CC", "\uD655\uC778"].some((term) => text.includes(term));
      }).slice(0, 10).map((el) => ({ tag: el.tagName, text: (el.textContent || "").trim().slice(0, 120), aria: (el.getAttribute("aria-label") || "").trim(), id: el.id || "", cls: el.className || "" }));
      try {
        chrome.runtime.sendMessage({ type: "MAZA_INFRA_PROGRESS", step: "PUBLISH_CONFIRM_DIAGNOSTIC", detail: { candidates } }).catch(() => {
        });
      } catch {
      }
      return false;
    }
    const taskId = window.__MAZA_CURRENT_TASK_ID ?? "unknown-task";
    info("PublishLayer", "Ensuring publish options are set");
    await ensurePublishOptions(publishAt);
    info("PublishLayer", "Clicking confirm button to publish");
    await clickConfirmButton(confirmButton);
    reportPublishConfirmedOnce(`https://${window.location.hostname}/manage/post`);
    if (signal?.aborted) {
      warn("PublishLayer", "confirmPublish aborted while waiting for layer close");
      return false;
    }
    info("PublishLayer", "Waiting for publish layer to close...");
    const isPublishComplete = () => {
      if (document.documentElement.getAttribute("data-maza-error") === "DAILY_LIMIT_EXCEEDED") {
        throw new Error("DAILY_LIMIT_EXCEEDED");
      }
      const layerClosed = !isPublishLayerOpen();
      if (layerClosed) return true;
      const href = window.location.href;
      const pathname = window.location.pathname;
      const onPostPage = /\/\d+\/?$/.test(pathname);
      const onTistoryPage = pathname.includes("/pages/");
      const onManageList = (href.includes("/manage/post") || href.includes("/manage/page")) && !href.includes("/write") && !href.includes("/newpost");
      return onPostPage || onTistoryPage || onManageList;
    };
    const closed = await waitUntil(isPublishComplete, 3e4, 250, signal);
    if (!closed) {
      warn("PublishLayer", "Publish layer did not close, attempting retry");
      const fallbackButtons = getPublishConfirmButtons();
      for (let attempt = 1; attempt <= 2; attempt += 1) {
        const fallback = fallbackButtons[attempt - 1] || getPublishConfirmButton();
        if (!fallback || !isVisible3(fallback)) continue;
        console.log("[PublishFlow RETRY]", taskId, attempt, "confirmPublish");
        warn("PublishLayer", `Retry attempt ${attempt} clicking confirm button again`);
        await clickConfirmButton(fallback);
        const retryClosed = await waitUntil(isPublishComplete, 15e3, 250, signal);
        if (retryClosed) {
          info("PublishLayer", "Publish completed on retry");
          return true;
        }
      }
      warn("PublishLayer", "Publish layer did not close after retry attempts");
      return false;
    }
    info("PublishLayer", "Publish layer closed successfully");
    return closed;
  }

  // extension/platforms/tistory/actions/tags.ts
  init_dom();
  init_logger();
  init_selectors();
  var TAG_INPUT_SELECTORS = SELECTORS.tagInput.join(", ");
  var HASHTAG_PATTERN = /#([a-zA-Z0-9ㄱ-ㅎㅏ-ㅣ가-힣_\-]+)/g;
  var HEX_COLOR_PATTERN = /^[0-9a-fA-F]{3,6}$/;
  var EXCLUDED_TAGS = /* @__PURE__ */ new Set(["toc"]);
  function normalizeTag(tag) {
    return tag.replace(/^#/, "").trim();
  }
  function shouldIncludeTag(tag) {
    const normalized = normalizeTag(tag);
    if (!normalized) return false;
    if (EXCLUDED_TAGS.has(normalized.toLowerCase())) return false;
    if (HEX_COLOR_PATTERN.test(normalized)) return false;
    return true;
  }
  function escapeRegExp(value) {
    return value.replace(/[.*+?^${}()|[\\]\\]/g, "\\$&");
  }
  function extractTagsFromHtml(html) {
    const tags = /* @__PURE__ */ new Set();
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
    let node = walker.nextNode();
    while (node) {
      const text = node.textContent || "";
      let match;
      while ((match = HASHTAG_PATTERN.exec(text)) !== null) {
        const candidate = match[1];
        if (!shouldIncludeTag(candidate)) continue;
        tags.add(normalizeTag(candidate));
        if (tags.size >= 10) break;
      }
      if (tags.size >= 10) break;
      node = walker.nextNode();
    }
    if (tags.size === 0) {
      const markdownTagRegex = /#([a-zA-Z0-9ㄱ-ㅎㅏ-ㅣ가-힣_\-]+)/g;
      let match;
      while ((match = markdownTagRegex.exec(html)) !== null) {
        const candidate = match[1];
        if (!shouldIncludeTag(candidate)) continue;
        tags.add(normalizeTag(candidate));
        if (tags.size >= 10) break;
      }
    }
    return Array.from(tags).slice(0, 10);
  }
  function dispatchTagEntryEvents(input, tag) {
    input.value = tag;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new KeyboardEvent("keydown", {
      key: "Enter",
      code: "Enter",
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true
    }));
    input.dispatchEvent(new KeyboardEvent("keyup", {
      key: "Enter",
      code: "Enter",
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true
    }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function setTagInputValue(input, tag) {
    input.focus();
    input.value = tag;
    input.dispatchEvent(new Event("input", { bubbles: true }));
  }
  function cleanHashtagsFromHtml(html, tags) {
    if (!tags.length) return html;
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
      const normalizedTags = tags.map(normalizeTag).filter(Boolean);
      const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
      let node = walker.nextNode();
      while (node) {
        const parentElement = node.parentElement;
        if (parentElement && parentElement.closest('[data-maza-tags="true"]')) {
          node = walker.nextNode();
          continue;
        }
        let text = node.textContent || "";
        for (const tag of normalizedTags) {
          const escaped = escapeRegExp(tag);
          const pattern = new RegExp(`(^|\\s|\\u00A0)#${escaped}(?=$|\\s|[.,!?;:\\)\\(\\[\\]{}]|\\u00A0)`, "gi");
          text = text.replace(pattern, "$1");
        }
        if (text !== node.textContent) {
          node.textContent = text;
        }
        node = walker.nextNode();
      }
      findAnywhereAll("p, div, span, h1, h2, h3, h4, h5, h6", doc).forEach((el) => {
        if (!el.textContent?.trim()) {
          el.remove();
        }
      });
      doc.body.normalize();
      return doc.body.innerHTML.trim();
    } catch (err) {
      error("Tags", "Failed to clean hashtags from HTML", err);
      return html;
    }
  }
  function hasFilledTags() {
    const inputs = findAnywhereAll(TAG_INPUT_SELECTORS);
    return inputs.some((input) => input.value.trim().length > 0);
  }
  async function injectTags(tags, signal) {
    if (signal?.aborted) {
      warn("Tags", "injectTags aborted");
      return false;
    }
    const normalizedTags = tags.map(normalizeTag).filter((tag) => tag.length > 0).slice(0, 10);
    if (normalizedTags.length === 0) {
      info("Tags", "No valid tags to inject");
      return false;
    }
    info("Tags", `Looking for tag input element (selectors: ${TAG_INPUT_SELECTORS})`);
    const tagInput = await waitForElement(TAG_INPUT_SELECTORS, 8e3, signal);
    if (!tagInput) {
      warn("Tags", "Tag input element not found");
      return false;
    }
    try {
      tagInput.focus();
    } catch (err) {
      debug("Tags", "Expected focus exception in tag input", err);
    }
    for (const tag of normalizedTags) {
      if (signal?.aborted) {
        warn("Tags", "injectTags aborted during tag loop");
        return false;
      }
      info("Tags", `Injecting tag: ${tag}`);
      setTagInputValue(tagInput, tag);
      dispatchTagEntryEvents(tagInput, tag);
      await sleep(300);
      if (tagInput.value.trim() === tag) {
        info("Tags", `Retrying tag entry for: ${tag}`);
        tagInput.value = `${tag},`;
        tagInput.dispatchEvent(new Event("input", { bubbles: true }));
        dispatchTagEntryEvents(tagInput, tag);
        await sleep(300);
      }
    }
    await sleep(600);
    info("Tags", "Tag injection completed");
    return true;
  }

  // extension/core/runtime/telemetry.ts
  async function forwardCrashSnapshot(snapshot) {
    try {
      const storage = await chrome.storage.local.get(["mazaOrigin"]);
      const origin = storage.mazaOrigin?.replace(/\/$/, "") || "";
      const apiBase = origin ? `${origin}/api` : "https://mazastudio.kr/api";
      await fetch(`${apiBase}/observability/log`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          context: "TelemetryManager.captureCrash",
          error: { message: snapshot.errorMessage },
          meta: {
            level: "error",
            failedState: snapshot.failedState,
            activeEditor: snapshot.activeEditor,
            taskId: snapshot.taskId,
            retryCount: snapshot.retryCount,
            stepTimings: snapshot.stepTimings,
            domSnapshot: snapshot.domSnapshot,
            timestamp: snapshot.timestamp
          }
        })
      });
    } catch {
    }
  }
  var TelemetryManager = class {
    startTimes = /* @__PURE__ */ new Map();
    stepTimings = {};
    retryCount = 0;
    adapterType = "UNKNOWN";
    trackStepStart(step) {
      this.startTimes.set(step, performance.now());
    }
    trackStepEnd(step) {
      const startTime = this.startTimes.get(step);
      if (startTime) {
        const elapsed = performance.now() - startTime;
        this.stepTimings[step] = Math.round(elapsed);
      }
    }
    incrementRetry() {
      this.retryCount++;
    }
    setAdapterType(adapter) {
      this.adapterType = adapter;
    }
    getRetryCount() {
      return this.retryCount;
    }
    compileMetrics(success, partialSuccess, warnings) {
      return {
        adapterType: this.adapterType,
        editorDetectionTimeMs: this.stepTimings["editorDetection"] || 0,
        contentInjectionTimeMs: this.stepTimings["contentInjection"] || 0,
        thumbnailUploadTimeMs: this.stepTimings["thumbnailUpload"] || 0,
        publishDurationMs: this.stepTimings["publishDuration"] || 0,
        retryCount: this.retryCount,
        success,
        partialSuccess,
        warnings
      };
    }
    // [중요 개선 7] Crash Replay 스냅샷 기능
    // 실패 발생 시 원격 복기 디버깅이 가능하도록 브라우저 돔 및 세션 정밀 상태 수집
    captureCrash(failedState, errorMessage) {
      const taskId = typeof window !== "undefined" ? String(window.__MAZA_CURRENT_TASK_ID || "unknown-task") : "unknown-task";
      const snapshot = {
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        failedState,
        activeEditor: this.adapterType,
        taskId,
        errorMessage,
        domSnapshot: document.documentElement.outerHTML.substring(0, 8e4),
        // 가볍게 80KB 범위 내 캡처
        stepTimings: this.stepTimings,
        retryCount: this.retryCount
      };
      console.error("[MAZA Telemetry] Autonomous Crash Replay Captured:", snapshot);
      try {
        localStorage.setItem("maza_last_crash", JSON.stringify(snapshot));
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      void forwardCrashSnapshot(snapshot);
      return snapshot;
    }
  };

  // extension/core/runtime/stateMachine.ts
  var HierarchicalStateMachine = class {
    currentState = "INIT";
    subFlows = {
      contentFlow: "PENDING",
      tagFlow: "PENDING",
      thumbnailFlow: "PENDING",
      categoryFlow: "PENDING",
      verifyFlow: "PENDING"
    };
    transitionTo(nextState) {
      console.log(`[MAZA FSM] Core State Transition: ${this.currentState} \u2794 ${nextState}`);
      this.currentState = nextState;
    }
    getCurrentState() {
      return this.currentState;
    }
    setSubFlow(key, status) {
      console.log(`[MAZA FSM] Sub-Flow Update: [${key}] \u2794 ${status}`);
      this.subFlows[key] = status;
    }
    getSubFlows() {
      return this.subFlows;
    }
    // [중요 개선 6] Partial Success (부분 성공) 가중 판정 알고리즘
    // 본문 주입과 최종 발행이 완료되었다면, 썸네일이나 태그가 실패했더라도
    // 전체 실패 처리를 하지 않고 'PUBLISHED_WITH_WARNINGS' 등의 안정 상태로 회복시킵니다.
    evaluateFinalResult() {
      const warnings = [];
      if (this.subFlows.contentFlow === "FAILED") {
        return { ok: false, status: "FAILED_CONTENT_INJECTION", warnings: ["Content flow failed."] };
      }
      if (this.subFlows.verifyFlow === "FAILED") {
        return { ok: false, status: "FAILED_PUBLISH_VERIFICATION", warnings: ["Verify flow failed."] };
      }
      if (this.subFlows.thumbnailFlow === "FAILED") {
        warnings.push("Thumbnail upload failed, representative image was not set.");
      }
      if (this.subFlows.tagFlow === "FAILED") {
        warnings.push("Tag injection failed.");
      }
      if (this.subFlows.categoryFlow === "FAILED") {
        warnings.push("Category setting failed.");
      }
      if (warnings.length > 0) {
        return {
          ok: true,
          status: "PUBLISHED_WITH_WARNINGS",
          warnings
        };
      }
      return {
        ok: true,
        status: "PUBLISHED_COMPLETELY",
        warnings: []
      };
    }
  };

  // extension/platforms/tistory/workflow/publishFlow.ts
  init_logger();
  var PublishFlowError = class extends Error {
    constructor(code, message, details) {
      super(message);
      this.code = code;
      this.details = details;
      this.name = "PublishFlowError";
    }
    code;
    details;
  };
  async function publishFlow(payload, signal) {
    const telemetry = new TelemetryManager();
    telemetry.setAdapterType("TISTORY");
    telemetry.trackStepStart("publishDuration");
    const fsm = new HierarchicalStateMachine();
    const taskId = payload.taskId || payload.task_id || window.__MAZA_CURRENT_TASK_ID || "unknown-task";
    console.log("[PublishFlow START]", taskId, Date.now());
    startTimer("PublishFlow:total");
    info("PublishFlow", "Starting publish flow");
    try {
      if (signal?.aborted) {
        warn("PublishFlow", "Publish flow aborted before start");
        throw new Error("PUBLISH_FLOW_ABORTED");
      }
      try {
        telemetry.trackStepStart("editorDetection");
        startTimer("PublishFlow:editor-prep");
        info("PublishFlow", "Preparing editor");
        const foundEditor = await prepareEditor(signal);
        fsm.transitionTo("EDITOR_READY");
        telemetry.trackStepEnd("editorDetection");
        endTimer("PublishFlow:editor-prep", "PublishFlow", "Editor prepared successfully");
        try {
          startTimer("PublishFlow:validation");
          info("PublishFlow", "Validating publish state and payload");
          await validatePublishState(foundEditor);
          validatePublishPayload(payload);
          endTimer("PublishFlow:validation", "PublishFlow", "Publish state validated");
        } catch (err) {
          error("PublishFlow", "Publish state validation failed", err);
          throw err;
        }
      } catch (err) {
        error("PublishFlow", "Editor preparation failed", err);
        telemetry.captureCrash(fsm.getCurrentState(), err instanceof Error ? err.message : String(err));
        throw err;
      }
      const rawHtml = payload.html?.trim() ?? "";
      if (!rawHtml) {
        error("PublishFlow", "Publish payload HTML is empty");
        throw new PublishFlowError("EMPTY_BODY", "EMPTY_BODY: Content is missing or empty.");
      }
      startTimer("PublishFlow:thumbnail");
      info("PublishFlow", "Replacing external images with Tistory CDN");
      const html = await replaceImagesWithTistoryCDN(rawHtml);
      endTimer("PublishFlow:thumbnail", "PublishFlow", "Image processing completed");
      if (!html || html.trim().length === 0) {
        error("PublishFlow", "Body is empty after image processing");
        throw new PublishFlowError("EMPTY_BODY", "EMPTY_BODY: Content is missing or empty.");
      }
      info("PublishFlow", `HTML prepared (${html.length} chars)`);
      if (payload.title) {
        startTimer("PublishFlow:title");
        info("PublishFlow", `Injecting title: "${payload.title}"`);
        const titleInjected = await injectTitle(payload.title, signal);
        if (!titleInjected) {
          error("PublishFlow", "Title injection failed");
          throw new PublishFlowError("TITLE_INJECTION_FAILED", "TITLE_INJECTION_FAILED: Unable to inject title into the editor.");
        }
        endTimer("PublishFlow:title", "PublishFlow", "Title injected successfully");
      }
      const tags = payload.tags && payload.tags.length > 0 ? payload.tags : extractTagsFromHtml(html);
      const bodyHtml = cleanHashtagsFromHtml(html, tags);
      try {
        telemetry.trackStepStart("contentInjection");
        startTimer("PublishFlow:body");
        info("PublishFlow", "Injecting body content");
        try {
          const { EditorManager: EditorManager2 } = await Promise.resolve().then(() => (init_publishEditor(), publishEditor_exports));
          const editorManager = new EditorManager2();
          const switched = await editorManager.ensureHtmlMode(signal);
          if (switched) {
            info("PublishFlow", "HTML mode active \u2014 editorBridge will skip ProseMirror and inject into CodeMirror");
          } else {
            warn("PublishFlow", "HTML mode switch failed; will inject in current mode");
          }
          await injectBody(bodyHtml, signal);
          if (switched) {
            info("PublishFlow", "Restoring default mode to ensure Tistory syncs the content state and prevents empty posts");
            await editorManager.restoreDefaultMode(signal);
          }
        } catch (e) {
          warn("PublishFlow", "Editor mode switch or injection error, proceeding anyway", e);
        }
        fsm.transitionTo("CONTENT_INJECTED");
        fsm.setSubFlow("contentFlow", "SUCCESS");
        telemetry.trackStepEnd("contentInjection");
        endTimer("PublishFlow:body", "PublishFlow", "Body content injected");
      } catch (err) {
        fsm.setSubFlow("contentFlow", "FAILED");
        telemetry.captureCrash(fsm.getCurrentState(), err instanceof Error ? err.message : String(err));
        error("PublishFlow", "Body injection failed", err);
        throw err;
      }
      if (tags.length > 0) {
        telemetry.trackStepStart("tagInjection");
        startTimer("PublishFlow:tags");
        info("PublishFlow", `Injecting tags: ${tags.join(", ")}`);
        const tagsInjected = await injectTags(tags, signal);
        if (tagsInjected) {
          fsm.setSubFlow("tagFlow", "SUCCESS");
        } else {
          fsm.setSubFlow("tagFlow", "FAILED");
          warn("PublishFlow", "Tag injection failed or was not completed");
        }
        telemetry.trackStepEnd("tagInjection");
        endTimer("PublishFlow:tags", "PublishFlow", "Tag injection completed");
      } else {
        fsm.setSubFlow("tagFlow", "SKIPPED");
      }
      startTimer("PublishFlow:open-layer");
      info("PublishFlow", "Opening publish layer");
      const layerOpened = await openPublishLayer(signal);
      if (!layerOpened) {
        error("PublishFlow", "Failed to open publish layer");
        throw new PublishFlowError("PUBLISH_LAYER_OPEN_FAILED", "PUBLISH_LAYER_OPEN_FAILED: Could not open Tistory publish layer.");
      }
      await sleep(2500);
      endTimer("PublishFlow:open-layer", "PublishFlow", "Publish layer opened");
      if (payload.categoryId || payload.category) {
        telemetry.trackStepStart("categoryInjection");
        startTimer("PublishFlow:category");
        const catId = payload.categoryId;
        const catName = payload.category;
        info("PublishFlow", `Selecting category: ID="${catId}" or Name="${catName}"`);
        const selectedId = catId || (catName ? catName : void 0);
        if (!selectedId) {
          fsm.setSubFlow("categoryFlow", "SKIPPED");
          telemetry.trackStepEnd("categoryInjection");
        } else {
          try {
            const success = await selectCategoryById(selectedId);
            if (success) {
              fsm.setSubFlow("categoryFlow", "SUCCESS");
              endTimer("PublishFlow:category", "PublishFlow", `Category "${selectedId}" selected successfully`);
            } else {
              fsm.setSubFlow("categoryFlow", "FAILED");
              endTimer("PublishFlow:category", "PublishFlow", `Category "${selectedId}" selection failed`);
              warn("PublishFlow", `Failed to select category: ${selectedId}, proceeding anyway`);
            }
            telemetry.trackStepEnd("categoryInjection");
          } catch (error2) {
            const message = error2 instanceof Error ? error2.message : "Unknown category selection error.";
            fsm.setSubFlow("categoryFlow", "FAILED");
            telemetry.trackStepEnd("categoryInjection");
            warn("PublishFlow", `Category selection failed: ${message}, proceeding anyway`, { categoryId: catId, category: catName });
          }
        }
      } else {
        fsm.setSubFlow("categoryFlow", "SKIPPED");
      }
      telemetry.trackStepStart("thumbnailUpload");
      startTimer("PublishFlow:thumbnail-upload");
      const thumbnailImgUrl = payload.thumbnailUrl || extractRepresentativeThumbnailUrl(html);
      if (thumbnailImgUrl) {
        info("PublishFlow", `Uploading representative thumbnail: ${thumbnailImgUrl}`);
        const thumbOk = await uploadThumbnailToPublishLayer(thumbnailImgUrl, signal);
        if (thumbOk) {
          fsm.setSubFlow("thumbnailFlow", "SUCCESS");
        } else {
          fsm.setSubFlow("thumbnailFlow", "FAILED");
          warn("PublishFlow", "Representative thumbnail upload failed or was skipped");
        }
      } else {
        fsm.setSubFlow("thumbnailFlow", "SKIPPED");
        info("PublishFlow", "No representative thumbnail detected");
      }
      telemetry.trackStepEnd("thumbnailUpload");
      endTimer("PublishFlow:thumbnail-upload", "PublishFlow", "Representative thumbnail handling completed");
      if (tags.length > 0 && !hasFilledTags()) {
        console.log("[PublishFlow RETRY]", taskId, "tag-injection");
        info("PublishFlow", "Tag fields are empty after publish layer opened, retrying tag injection");
        const retryTagsInjected = await injectTags(tags, signal);
        if (!retryTagsInjected) {
          warn("PublishFlow", "Tag retry injection failed");
        }
      }
      telemetry.trackStepStart("publishConfirmation");
      startTimer("PublishFlow:confirm");
      info("PublishFlow", "Confirming publish and waiting for completion");
      if (!isPublishLayerOpen()) {
        warn("PublishFlow", "Publish layer closed during thumbnail step, reopening...");
        const reopened = await openPublishLayer(signal);
        if (!reopened) {
          fsm.setSubFlow("verifyFlow", "FAILED");
          error("PublishFlow", "Failed to reopen publish layer before confirm");
          throw new PublishFlowError("PUBLISH_LAYER_OPEN_FAILED", "PUBLISH_LAYER_REOPEN_FAILED: Could not reopen publish layer.");
        }
      }
      const publishConfirmed = await confirmPublish(signal, payload.publishAt);
      telemetry.trackStepEnd("publishConfirmation");
      if (!publishConfirmed) {
        fsm.setSubFlow("verifyFlow", "FAILED");
        error("PublishFlow", "Publish confirmation failed or timed out");
        throw new PublishFlowError("PUBLISH_CONFIRMATION_FAILED", "PUBLISH_CONFIRMATION_FAILED: Publish confirmation did not complete successfully.");
      }
      fsm.setSubFlow("verifyFlow", "SUCCESS");
      fsm.transitionTo("VERIFIED");
      endTimer("PublishFlow:confirm", "PublishFlow", "Publish confirmed and completed");
      const finalResult = fsm.evaluateFinalResult();
      telemetry.trackStepEnd("publishDuration");
      const metrics = telemetry.compileMetrics(finalResult.ok, finalResult.status === "PUBLISHED_WITH_WARNINGS", finalResult.warnings);
      info("PublishFlow", `Publish complete with status: ${finalResult.status}`);
      info("PublishFlow", "Publish telemetry metrics", metrics);
      fsm.transitionTo("DONE");
      endTimer("PublishFlow:total", "PublishFlow", "Publish flow completed successfully");
      const isScheduled = !!(payload.publishAt && new Date(payload.publishAt).getTime() > Date.now());
      const publishedUrl = publishConfirmed?.url ?? (isScheduled ? `https://${window.location.hostname}/manage/post` : window.location.href);
      const postIdMatch = publishedUrl.match(/\/(\d+)\/?$/);
      return {
        ok: finalResult.ok,
        success: finalResult.ok,
        status: finalResult.status,
        published_url: publishedUrl,
        postUrl: publishedUrl,
        postId: postIdMatch ? postIdMatch[1] : void 0,
        warnings: finalResult.warnings,
        metrics
      };
    } finally {
      console.log("[PublishFlow END]", taskId);
    }
  }

  // extension/platforms/tistory/publish.ts
  init_publishRuntime();
  init_logger();
  function isError(value) {
    return value instanceof Error || typeof value === "object" && value !== null && "message" in value && typeof value.message === "string";
  }
  var _injectContentInFlight = false;
  async function injectContent(title, html, category, categoryId, thumbnailUrl) {
    const taskId = window.__MAZA_CURRENT_TASK_ID || "unknown-task";
    if (!html || html.trim().length < 50) {
      log.error("PublishDriver", "\u274C Empty or too-short body content. Aborting to prevent empty post publish.", { length: html?.length ?? 0 });
      return { ok: false, success: false, status: "FAILED", error: "EMPTY_BODY: Content too short (< 50 chars). Check html_content in DB." };
    }
    if (_injectContentInFlight || window.__MAZA_INJECTING__) {
      const taskId2 = window.__MAZA_CURRENT_TASK_ID || "unknown-task";
      log.warn("PublishDriver", "injectContent already in flight. Ignoring duplicate call.", { taskId: taskId2 });
      console.log("[PublishFlow DUPLICATE]", taskId2, Date.now());
      return { ok: true, success: true, status: "ALREADY_RUNNING", error: "Already running" };
    }
    _injectContentInFlight = true;
    window.__MAZA_INJECTING__ = true;
    log.info("PublishDriver", "Autopilot Sequence Initiated.", { category, taskId });
    const orchestrator = new CleanupOrchestrator();
    const broker = MessageBroker.getInstance();
    broker.resetApiIntercept();
    broker.start();
    const abortController = new AbortController();
    const signal = abortController.signal;
    try {
      const result = await publishFlow(
        {
          title: title.trim(),
          html: html.trim(),
          category,
          categoryId,
          thumbnailUrl
        },
        signal
      );
      console.log("[PublishFlow END]", taskId);
      return result;
    } catch (err) {
      const errorMessage = isError(err) ? err.message : "UNKNOWN_ERROR";
      log.error("PublishDriver", "Execution crashed in publish wrapper.", err);
      console.log("[PublishFlow END]", taskId);
      abortController.abort();
      if (err instanceof ValidationError) {
        return { ok: false, success: false, status: "VALIDATION_FAILED", error: err.code, reason: err.message };
      }
      if (err instanceof MazaFatalError) {
        if (err.message === "NAVIGATING_TO_EDITOR") {
          return { ok: true, success: true, status: "NAVIGATING_TO_EDITOR" };
        }
        return { ok: false, success: false, status: "FAILED", error: err.message };
      }
      return { ok: false, success: false, status: "FAILED", error: errorMessage };
    } finally {
      _injectContentInFlight = false;
      window.__MAZA_INJECTING__ = false;
      orchestrator.cleanup();
      broker.cleanup();
    }
  }

  // extension/platforms/tistory/infra.ts
  init_dom();
  init_selectors();
  init_broker();
  init_logger();
  async function ensureMainWorldLoaded() {
    await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "LOAD_MAIN_WORLD_SCRIPT" }, () => {
        if (chrome.runtime.lastError) {
          console.debug("[MAZA Infra] Failed to load MAIN world script:", chrome.runtime.lastError.message);
        }
        resolve();
      });
    });
  }
  async function injectViaMainWorld(html) {
    await ensureMainWorldLoaded();
    const broker = MessageBroker.getInstance();
    broker.start();
    const requestId = crypto.randomUUID();
    return new Promise((resolve) => {
      const timeoutId = setTimeout(() => {
        broker.deregisterResolver(requestId);
        resolve({ ok: false, error: "MAIN_WORLD_INJECTION_TIMEOUT" });
      }, 9e3);
      broker.registerResolver(requestId, (payload) => {
        if (payload?.type !== "MAZA_INJECT_INFRA_RESULT") return;
        clearTimeout(timeoutId);
        broker.deregisterResolver(requestId);
        resolve({ ok: payload.ok === true, step: payload.step, error: payload.error });
      });
      broker.getChannel().postMessage({
        action: "INJECT_INFRA",
        requestId,
        html
      });
    });
  }
  async function injectInfra(html) {
    try {
      info("Infra", "Starting Infra Injection...");
      notifyProgress("STARTING");
      const href = window.location.href;
      const blockedPageMarkers = [
        "\uC11C\uBE44\uC2A4 \uC774\uC6A9\uC5D0 \uBD88\uD3B8\uC744 \uB4DC\uB824 \uC8C4\uC1A1\uD569\uB2C8\uB2E4.",
        "\uACFC\uB3C4\uD55C \uC811\uADFC \uC694\uCCAD\uC73C\uB85C \uBE14\uB85C\uADF8 \uC0AC\uC6A9\uC774 \uC7A0\uC2DC \uC911\uB2E8\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
        "\uC790\uB3D9\uD654\uB41C \uC811\uADFC",
        "IP \uC8FC\uC18C",
        "\uC811\uADFC \uC694\uCCAD",
        "Too Many Requests",
        "429"
      ];
      const bodyText = document.body?.innerText || "";
      if (blockedPageMarkers.some((marker) => bodyText.includes(marker))) {
        const blockMessage = "\uD2F0\uC2A4\uD1A0\uB9AC\uAC00 \uACFC\uB3C4\uD55C \uC811\uADFC\uC73C\uB85C \uC784\uC2DC \uCC28\uB2E8\uD55C \uD398\uC774\uC9C0\uB97C \uBC18\uD658\uD588\uC2B5\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.";
        error("Infra", blockMessage);
        notifyProgress("ERROR", blockMessage);
        return { ok: false, error: blockMessage };
      }
      if (href.includes("/auth/login") || href.includes("accounts.kakao.com") || href.includes("auth.kakao.com")) {
        try {
          const storage = await new Promise(
            (resolve) => chrome.storage.local.get(["mazaToken", "lastSignedInAt"], (s) => resolve(s || {}))
          );
          const token = storage.mazaToken;
          const lastSigned = typeof storage.lastSignedInAt === "number" ? storage.lastSignedInAt : typeof storage.lastSignedInAt === "string" ? Number(storage.lastSignedInAt) : 0;
          const now = Date.now();
          console.debug("[MAZA Infra] Login page detected", { href, tokenPresent: !!token, lastSignedAgoMs: lastSigned ? now - lastSigned : null });
          if (token || lastSigned && now - lastSigned < 3e4) {
            notifyProgress("WAITING_LOGIN", "\uB85C\uADF8\uC778 \uC0C1\uD0DC \uD655\uC778 \uC911\uC785\uB2C8\uB2E4. \uC7A0\uC2DC \uAE30\uB2E4\uB824 \uC8FC\uC138\uC694.");
            return { ok: false, error: "AWAITING_LOGIN_REDIRECT" };
          } else {
            notifyProgress("WAITING_LOGIN", "\uB85C\uADF8\uC778 \uC644\uB8CC \uD6C4 \uC790\uB3D9\uC73C\uB85C HTML \uD3B8\uC9D1 \uD654\uBA74\uC73C\uB85C \uC774\uB3D9\uD569\uB2C8\uB2E4.");
            return { ok: false, error: "AWAITING_LOGIN" };
          }
        } catch (e) {
          notifyProgress("WAITING_LOGIN", "\uB85C\uADF8\uC778 \uC644\uB8CC \uD6C4 \uC790\uB3D9\uC73C\uB85C HTML \uD3B8\uC9D1 \uD654\uBA74\uC73C\uB85C \uC774\uB3D9\uD569\uB2C8\uB2E4.");
          throw new Error("\uD2F0\uC2A4\uD1A0\uB9AC \uB85C\uADF8\uC778\uC774 \uD544\uC694\uD569\uB2C8\uB2E4. \uCE74\uCE74\uC624 \uB85C\uADF8\uC778\uC744 \uC644\uB8CC\uD574 \uC8FC\uC138\uC694.");
        }
      }
      if (!href.includes("/manage/")) {
        throw new Error("\uC2A4\uD0A8 \uD3B8\uC9D1 \uD398\uC774\uC9C0\uAC00 \uC544\uB2D9\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");
      }
      const hasEditor = findAnywhere(SELECTORS.codeEditor.join(","));
      if (!hasEditor) {
        info("Infra", "Editor not visible. Trying to navigate to HTML edit mode...");
        try {
          const avatar = findAnywhere('img[alt*="\uD504\uB85C\uD544"], .avatar, .profile');
          console.debug("[MAZA Infra] Editor not found; diagnostic:", { href, avatarFound: !!avatar });
        } catch (e) {
          console.debug("[MAZA Infra] Diagnostic check failed", e);
        }
        notifyProgress("BUTTON_CLICKED");
        const bodyReady = await waitForElement(["body"], 3e3).catch(() => false);
        if (!bodyReady) {
          info("Infra", "Warning: page body not ready yet, proceeding anyway.");
        }
        await ensureMainWorldLoaded();
        const allEditorSelectors = SELECTORS.codeEditor.concat(SELECTORS.editorFallback);
        let appeared = null;
        let attempts = 0;
        while (!appeared && attempts < 4) {
          attempts++;
          const htmlEditBtn = findByTextAnywhere("html \uD3B8\uC9D1") || findByTextAnywhere("HTML \uD3B8\uC9D1") || findAnywhere(SELECTORS.htmlEditorToggle.join(",")) || findAnywhere('a[href*="/source/html"], a[href*="#/source/html"], button[href*="/source/html"], button[href*="#/source/html"], [data-action*="source/html"], [data-id*="html"], [aria-label*="HTML"], [aria-label*="html"], [title*="HTML"]');
          if (htmlEditBtn) {
            await clickAnywhere(htmlEditBtn);
            info("Infra", `HTML edit button clicked (attempt ${attempts}).`);
          } else if (!href.includes("#/source/html")) {
            const targetUrl = href.replace(/(#.*)?$/, "#/source/html");
            info("Infra", `HTML edit button not found. Switching to ${targetUrl} (attempt ${attempts})`);
            window.location.hash = "#/source/html";
          }
          appeared = await waitForElement(allEditorSelectors, 4e3);
          if (appeared) break;
        }
        if (!appeared) {
          const snapshot = (document.body?.innerText || "").slice(0, 400);
          notifyProgress("ERROR", `\uC5D0\uB514\uD130 \uD0D0\uC9C0 \uC2E4\uD328: snapshot=${snapshot.substring(0, 200)}`);
          throw new Error("HTML \uC5D0\uB514\uD130\uB97C \uC5F4 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uC2A4\uD0A8 \uD3B8\uC9D1 \uD398\uC774\uC9C0\uC5D0\uC11C \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");
        }
      }
      notifyProgress("EDITOR_READY");
      info("Infra", "Injecting via MAIN World script...");
      const injectResult = await injectViaMainWorld(html);
      if (!injectResult.ok) {
        throw new Error(injectResult.error || "CodeMirror \uC8FC\uC785 \uC2E4\uD328");
      }
      if (injectResult.step === "ALREADY_INJECTED") {
        info("Infra", "Infra already injected.");
        notifyProgress("ALREADY_INJECTED");
        return { ok: true, step: "ALREADY_INJECTED" };
      }
      notifyProgress("CODE_INJECTED");
      info("Infra", "Code injected successfully. Clicking apply button...");
      await new Promise((r) => setTimeout(r, 800));
      const applyBtn = findByTextAnywhere("\uC801\uC6A9") || findByTextAnywhere("\uC800\uC7A5") || findAnywhere('button[type="submit"]');
      if (applyBtn) {
        notifyProgress("SAVE_CLICKED");
        await clickAnywhere(applyBtn);
        info("Infra", "Apply button clicked.");
        await new Promise((r) => setTimeout(r, 2500));
      } else {
        warn("Infra", "Apply button not found. Manual save required.");
      }
      notifyProgress("SUCCESS");
      return { ok: true, step: "SUCCESS" };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      error("Infra", "Infra injection failed", err);
      notifyProgress("ERROR", message);
      return { ok: false, error: message };
    }
  }

  // extension/content/injector.ts
  console.log("%c[MAZA OS] Tistory Injector Active!", "color: #8b5cf6; font-weight: bold; font-size: 14px;");
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "MAZA_PING") {
      sendResponse({ ok: true });
      return false;
    }
    if (msg.type === "DELIVER") {
      handleTask(msg.task).then(sendResponse).catch((err) => sendResponse({ ok: false, error: err.message }));
      return true;
    }
  });
  var MAX_READY_ATTEMPTS = 5;
  var readyAttempts = 0;
  function announceReady() {
    if (!isTistoryWritePage(window.location.href)) {
      console.log(`[MAZA OS] Not a write page (${window.location.pathname}), skipping READY signal.`);
      return;
    }
    if (readyAttempts >= MAX_READY_ATTEMPTS) {
      console.warn(`[MAZA OS] Gave up sending READY signal after ${MAX_READY_ATTEMPTS} attempts.`);
      return;
    }
    const backoffMs = Math.pow(2, readyAttempts) * 500;
    readyAttempts++;
    chrome.runtime.sendMessage({ type: "CONTENT_SCRIPT_READY" }, (response) => {
      if (chrome.runtime.lastError) {
        setTimeout(announceReady, backoffMs);
      } else {
        console.log("[MAZA OS] READY acknowledged.");
      }
    });
  }
  announceReady();
  var isTaskRunning = false;
  function isTistoryWritePage(url) {
    return /\/(?:manage\/(?:newpost|newpage|page\b|pages?\/write|pages?\/post\/(?:write|\d+\/edit)|post\/write|post\/\d+\/edit)|blog\/write|entry)/.test(url);
  }
  function isTistoryBlockedPage(text) {
    const blockedMarkers = [
      "\uC11C\uBE44\uC2A4 \uC774\uC6A9\uC5D0 \uBD88\uD3B8\uC744 \uB4DC\uB824 \uC8C4\uC1A1\uD569\uB2C8\uB2E4.",
      "\uACFC\uB3C4\uD55C \uC811\uADFC \uC694\uCCAD\uC73C\uB85C \uBE14\uB85C\uADF8 \uC0AC\uC6A9\uC774 \uC7A0\uC2DC \uC911\uB2E8\uB418\uC5C8\uC2B5\uB2C8\uB2E4.",
      "\uC790\uB3D9\uD654\uB41C \uC811\uADFC",
      "\uC811\uADFC \uC694\uCCAD",
      "IP \uC8FC\uC18C",
      "Too Many Requests",
      "429"
    ];
    return blockedMarkers.some((m) => text.includes(m));
  }
  async function handleTask(task) {
    if (isTaskRunning) {
      return { ok: false, status: "ALREADY_RUNNING", error: "Task is already running" };
    }
    isTaskRunning = true;
    try {
      const pageText = document.documentElement?.innerText || document.body?.innerText || "";
      if (isTistoryBlockedPage(pageText)) {
        return { ok: false, status: "FAILED", error: "\uD2F0\uC2A4\uD1A0\uB9AC\uAC00 \uACFC\uB3C4\uD55C \uC811\uADFC\uC73C\uB85C \uC784\uC2DC \uCC28\uB2E8\uB41C \uD398\uC774\uC9C0\uB97C \uBC18\uD658\uD588\uC2B5\uB2C8\uB2E4." };
      }
      if (task.platform !== "tistory") return { ok: false, error: "Unsupported platform" };
      if (task.type === "PUBLISH_POST") {
        const currentUrl = window.location.href;
        const onWritePage = isTistoryWritePage(currentUrl);
        const isDomain = /tistory\.com|wordpress|blogger|medium/.test(currentUrl);
        if (!onWritePage && isDomain) {
          const path = new URL(currentUrl).pathname;
          const publishedPostPage = /^\/manage\/post(?:\/\d+)?$/.test(path) || path.includes("/entry/");
          if (/\/manage\/posts/.test(path) || publishedPostPage) {
            return { ok: true, status: "ALREADY_PUBLISHED", error: "", published_url: currentUrl, postUrl: currentUrl };
          }
          const currentUrlBase = currentUrl.split("?")[0].split("#")[0].replace(/\/$/, "");
          const taskUrlBase = task.url.split("?")[0].split("#")[0].replace(/\/$/, "");
          if (currentUrlBase !== taskUrlBase) {
            setTimeout(() => {
              window.location.href = task.url;
            }, 100);
            return { ok: true, status: "NAVIGATING_TO_EDITOR" };
          }
        }
        const MIN_BODY_LENGTH = 80;
        if (!task.payload.html || task.payload.html.trim().length < MIN_BODY_LENGTH) {
          return { ok: false, error: `\uBCF8\uBB38\uC774 \uB108\uBB34 \uC9E7\uC2B5\uB2C8\uB2E4 (\uCD5C\uC18C ${MIN_BODY_LENGTH}\uC790).` };
        }
        window.__MAZA_CURRENT_TASK_ID = task.id;
        task.payload.taskId = task.id;
        return await injectContent(
          task.payload.title,
          task.payload.html,
          task.payload.category,
          task.payload.categoryId,
          typeof task.payload.thumbnailUrl === "string" ? task.payload.thumbnailUrl : void 0
        );
      }
      if (task.type === "INFRA_INJECT") {
        return injectInfra(task.payload.html);
      }
      return { ok: false, error: "Unknown Task" };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return { ok: false, error: msg };
    } finally {
      isTaskRunning = false;
      readyAttempts = 0;
    }
  }
})();
//# sourceMappingURL=injector.js.map
