"use strict";
(() => {
  // extension/platforms/tistory/selectors.ts
  var SELECTORS = {
    // 글쓰기 버튼 (관리자 페이지)
    writeBtn: 'a[href*="/manage/newpost"], a[href*="/manage/post/write"], a.btn_tistory.btn_write',
    // 에디터 모드 전환 (WYSIWYG 직접 주입 방식으로 전환 — HTML 모드 탐지 제거)
    modeMenu: '#editor-mode-select, .btn_mode, [class*="mode_select"], [class*="modeSelect"], [class*="editor-mode"], button[class*="mode"]',
    defaultMode: 'li[data-mode="default"], button[data-mode="default"], div[data-mode="default"], [data-mode="default"], [data-code="default"], li[data-mode="prose"], [data-mode="prose"], [data-code="wysiwyg"], button[data-code="wysiwyg"], [data-mode="visual"]',
    // 기본 필드
    title: '#post-title-field, input.tf_title, textarea.tf_tit, .tf_tit, [placeholder*="\uC81C\uBAA9"], .ph_tit, input[name="title"], .editor-title-input',
    // 발행 버튼 (최신 Tistory UI 대응)
    publishBtn: '#publish-layer-open, button.btn_publish, button.btn_done, .btn_done, .btn_publish, button[data-action="publish"], button[type="submit"]:not([type="hidden"]), [class*="btn_submit"], [class*="btn_confirm"], [class*="btn_ok"], button[aria-label*="\uBC1C\uD589"], button[aria-label*="\uAC8C\uC2DC"], button[aria-label*="\uC644\uB8CC"]',
    confirmBtn: '#publish-btn, button.btn_confirm, button.btn_done, .btn_confirm, .btn_done, button[type="submit"], [class*="btn_confirm_submit"]',
    // 태그 필드
    tagInput: '#post-tag-field, .tf_tag, [placeholder*="\uD0DC\uADF8"], .ph_tag, .tag_input'
  };

  // extension/utils/dom.ts
  function findAnywhere(selector, root = document) {
    const el = root.querySelector(selector);
    if (el) return el;
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          const found = findAnywhere(selector, doc);
          if (found) return found;
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        const found = findAnywhere(selector, node.shadowRoot);
        if (found) return found;
      }
    }
    return null;
  }
  function findAnywhereAll(selector, root = document) {
    const elements = [];
    elements.push(...Array.from(root.querySelectorAll(selector)));
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          elements.push(...findAnywhereAll(selector, doc));
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        elements.push(...findAnywhereAll(selector, node.shadowRoot));
      }
    }
    return elements;
  }
  function findByTextAnywhere(text, root = document) {
    const interactive = root.querySelectorAll('button, a, [role="button"], input[type="button"], input[type="submit"]');
    for (const el of Array.from(interactive)) {
      if (el.textContent?.trim() === text || el.textContent?.includes(text)) {
        return el;
      }
    }
    const all = root.querySelectorAll("span, p, div, label");
    let bestMatch = null;
    let minLength = Infinity;
    for (const el of Array.from(all)) {
      const elText = el.textContent || "";
      if (elText.includes(text)) {
        if (elText.length < minLength) {
          minLength = elText.length;
          bestMatch = el;
        }
      }
    }
    if (bestMatch) return bestMatch;
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          const found = findByTextAnywhere(text, doc);
          if (found) return found;
        }
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
    }
    return null;
  }
  async function clickAnywhere(target) {
    const el = typeof target === "string" ? findAnywhere(target) : target;
    if (el) {
      el.click();
      try {
        el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
        el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      return true;
    }
    return false;
  }
  function notifyProgress(step, detail) {
    chrome.runtime.sendMessage({
      type: "MAZA_INFRA_PROGRESS",
      step,
      detail,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }).catch(() => {
    });
  }
  async function waitForElement(selector, timeout = 1e4) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const el = findAnywhere(selector);
      if (el) return el;
      await new Promise((r) => setTimeout(r, 1e3));
    }
    return null;
  }

  // extension/core/adapters/editor.ts
  function tokenize(str) {
    const normalized = str.normalize("NFC").replace(/[\u200B-\u200D\uFEFF]/g, "").replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'\n\r]/g, " ").toLowerCase();
    return new Set(normalized.split(/\s+/).filter((t) => t.length > 0));
  }
  function compareSimilarity(expectedHtml, actualText) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(expectedHtml, "text/html");
    const expectedTokens = tokenize(doc.body.textContent || "");
    let cleanActualText = actualText;
    if (actualText.includes("<") && (actualText.includes(">") || actualText.includes("</"))) {
      try {
        const actualDoc = parser.parseFromString(actualText, "text/html");
        cleanActualText = actualDoc.body.textContent || actualText;
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
    }
    const actualTokens = tokenize(cleanActualText);
    if (expectedTokens.size === 0) return true;
    if (actualTokens.size === 0) return false;
    let intersectionSize = 0;
    for (const token of expectedTokens) {
      if (actualTokens.has(token)) intersectionSize++;
    }
    const unionSize = expectedTokens.size + actualTokens.size - intersectionSize;
    const similarity = intersectionSize / unionSize;
    const threshold = 0.3;
    console.log(`[MAZA Telemetry] Token size: ${expectedTokens.size}, Similarity: ${similarity.toFixed(3)} (Min: ${threshold})`);
    return similarity >= threshold;
  }

  // extension/core/runtime/broker.ts
  var MessageBroker = class _MessageBroker {
    static instance = null;
    channel;
    resolvers = /* @__PURE__ */ new Map();
    apiSuccessIntercepted = false;
    initialized = false;
    constructor() {
      this.channel = new BroadcastChannel("maza-runtime");
    }
    static getInstance() {
      if (!this.instance) {
        this.instance = new _MessageBroker();
      }
      return this.instance;
    }
    registerResolver(requestId, resolve) {
      this.resolvers.set(requestId, resolve);
    }
    deregisterResolver(requestId) {
      this.resolvers.delete(requestId);
    }
    isApiSuccessIntercepted() {
      return this.apiSuccessIntercepted;
    }
    resetApiIntercept() {
      this.apiSuccessIntercepted = false;
    }
    getChannel() {
      return this.channel;
    }
    start() {
      if (this.initialized) return;
      this.initialized = true;
      this.channel.onmessage = (event) => {
        const { type, requestId, ok, value } = event.data || {};
        if (type === "MAZA_PUBLISH_API_SUCCESS") {
          console.log("[MAZA Broker] Caught intercepted fetch/XHR API publish success token.");
          this.apiSuccessIntercepted = true;
          return;
        }
        if (requestId) {
          const resolver = this.resolvers.get(requestId);
          if (resolver) {
            resolver({ type, ok, value });
          }
        }
      };
    }
    // 브릿지 해제 및 포트 클린업
    cleanup() {
      try {
        this.channel.close();
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      this.resolvers.clear();
      this.initialized = false;
      _MessageBroker.instance = null;
      console.log("[MAZA Broker] BroadcastChannel successfully closed & unmounted.");
    }
  };

  // extension/core/runtime/stateMachine.ts
  var HierarchicalStateMachine = class {
    currentState = "INIT";
    subFlows = {
      contentFlow: "PENDING",
      tagFlow: "PENDING",
      thumbnailFlow: "PENDING",
      verifyFlow: "PENDING"
    };
    transitionTo(nextState) {
      console.log(`[MAZA FSM] Core State Transition: ${this.currentState} \u2794 ${nextState}`);
      this.currentState = nextState;
    }
    getCurrentState() {
      return this.currentState;
    }
    setSubFlow(key, status) {
      console.log(`[MAZA FSM] Sub-Flow Update: [${key}] \u2794 ${status}`);
      this.subFlows[key] = status;
    }
    getSubFlows() {
      return this.subFlows;
    }
    // [중요 개선 6] Partial Success (부분 성공) 가중 판정 알고리즘
    // 본문 주입과 최종 발행이 완료되었다면, 썸네일이나 태그가 실패했더라도
    // 전체 실패 처리를 하지 않고 'PUBLISHED_WITH_WARNINGS' 등의 안정 상태로 회복시킵니다.
    evaluateFinalResult() {
      const warnings = [];
      if (this.subFlows.contentFlow === "FAILED") {
        return { ok: false, status: "FAILED_CONTENT_INJECTION", warnings: ["Content flow failed."] };
      }
      if (this.subFlows.verifyFlow === "FAILED") {
        return { ok: false, status: "FAILED_PUBLISH_VERIFICATION", warnings: ["Verify flow failed."] };
      }
      if (this.subFlows.thumbnailFlow === "FAILED") {
        warnings.push("Thumbnail upload failed, representative image was not set.");
      }
      if (this.subFlows.tagFlow === "FAILED") {
        warnings.push("Tag injection failed.");
      }
      if (warnings.length > 0) {
        return {
          ok: true,
          status: "PUBLISHED_WITH_WARNINGS",
          warnings
        };
      }
      return {
        ok: true,
        status: "PUBLISHED_COMPLETELY",
        warnings: []
      };
    }
  };

  // extension/core/runtime/telemetry.ts
  var TelemetryManager = class {
    startTimes = /* @__PURE__ */ new Map();
    stepTimings = {};
    retryCount = 0;
    adapterType = "UNKNOWN";
    trackStepStart(step) {
      this.startTimes.set(step, performance.now());
    }
    trackStepEnd(step) {
      const startTime = this.startTimes.get(step);
      if (startTime) {
        const elapsed = performance.now() - startTime;
        this.stepTimings[step] = Math.round(elapsed);
      }
    }
    incrementRetry() {
      this.retryCount++;
    }
    setAdapterType(adapter) {
      this.adapterType = adapter;
    }
    getRetryCount() {
      return this.retryCount;
    }
    compileMetrics(success, partialSuccess, warnings) {
      return {
        adapterType: this.adapterType,
        editorDetectionTimeMs: this.stepTimings["editorDetection"] || 0,
        contentInjectionTimeMs: this.stepTimings["contentInjection"] || 0,
        thumbnailUploadTimeMs: this.stepTimings["thumbnailUpload"] || 0,
        publishDurationMs: this.stepTimings["publishDuration"] || 0,
        retryCount: this.retryCount,
        success,
        partialSuccess,
        warnings
      };
    }
    // [중요 개선 7] Crash Replay 스냅샷 기능
    // 실패 발생 시 원격 복기 디버깅이 가능하도록 브라우저 돔 및 세션 정밀 상태 수집
    captureCrash(failedState, errorMessage) {
      const snapshot = {
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        failedState,
        activeEditor: this.adapterType,
        errorMessage,
        domSnapshot: document.documentElement.outerHTML.substring(0, 8e4),
        // 가볍게 80KB 범위 내 캡처
        stepTimings: this.stepTimings,
        retryCount: this.retryCount
      };
      console.error("[MAZA Telemetry] Autonomous Crash Replay Captured:", snapshot);
      try {
        localStorage.setItem("maza_last_crash", JSON.stringify(snapshot));
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      return snapshot;
    }
  };

  // extension/platforms/tistory/publish.ts
  async function uploadImageToTistory(imageUrl) {
    try {
      const res = await fetch(imageUrl);
      if (!res.ok) throw new Error(`Image fetch failed: ${res.status}`);
      const blob = await res.blob();
      const blogDomain = window.location.hostname;
      const ext = imageUrl.includes(".png") ? "png" : "jpg";
      const fileName = `maza_thumb_${Date.now()}.${ext}`;
      const csrfMeta = document.querySelector('meta[name="csrf-token"], meta[name="_csrf"]');
      const csrfToken = csrfMeta?.content || "";
      const endpointCandidates = [
        { url: `https://${blogDomain}/upload`, field: "image" },
        { url: `https://${blogDomain}/upload/image`, field: "image" },
        { url: `https://${blogDomain}/manage/attachment/upload`, field: "uploadedfile" },
        { url: `https://${blogDomain}/manage/upload`, field: "image" },
        { url: `https://${blogDomain}/photo/upload`, field: "image" }
      ];
      for (const candidate of endpointCandidates) {
        try {
          const formData = new FormData();
          formData.append(candidate.field, blob, fileName);
          if (csrfToken) formData.append("_csrf", csrfToken);
          const uploadRes = await fetch(candidate.url, {
            method: "POST",
            body: formData,
            credentials: "include",
            headers: csrfToken ? { "X-CSRF-Token": csrfToken } : {}
          });
          if (!uploadRes.ok) {
            console.warn(`[MAZA Thumb] ${candidate.url} returned ${uploadRes.status}, trying next...`);
            continue;
          }
          const contentType = uploadRes.headers.get("content-type") || "";
          let cdnUrl = null;
          if (contentType.includes("application/json")) {
            const data = await uploadRes.json();
            cdnUrl = data?.url || data?.imageUrl || data?.data?.url || data?.replacer || null;
          } else {
            const text = await uploadRes.text();
            const urlMatch = text.match(/<url>(https?:\/\/[^<]+)<\/url>/i) || text.match(/"url"\s*:\s*"(https?:\/\/[^"]+)"/i);
            if (urlMatch) cdnUrl = urlMatch[1];
          }
          if (cdnUrl) {
            console.log(`[MAZA Thumb] Uploaded via ${candidate.url}:`, cdnUrl);
            return cdnUrl;
          }
        } catch (e) {
          console.warn(`[MAZA Thumb] Endpoint ${candidate.url} failed:`, e);
        }
      }
      console.warn("[MAZA Thumb] All endpoints failed. Using external URL as fallback.");
      return null;
    } catch (err) {
      console.warn("[MAZA Thumb] Image upload failed (non-fatal):", err);
      return null;
    }
  }
  async function replaceImagesWithTistoryCDN(html) {
    const imgRegex = /<img([^>]*?)src="(https?:\/\/(?!.*\.tistory\.com)([^"]+))"([^>]*?)>/gi;
    const matches = [];
    let m;
    const tempRegex = /<img([^>]*?)src="(https?:\/\/(?!.*\.tistory\.com)([^"]+))"([^>]*?)>/gi;
    while ((m = tempRegex.exec(html)) !== null) {
      matches.push({ full: m[0], src: m[2] });
    }
    if (matches.length === 0) return html;
    const first = matches[0];
    console.log("[MAZA Thumb] Uploading thumbnail image:", first.src);
    const cdnUrl = await uploadImageToTistory(first.src);
    if (cdnUrl) {
      return html.replace(first.full, first.full.replace(first.src, cdnUrl));
    }
    return html;
  }
  var ShortObserver = class {
    // [AEAR Enterprise] DOM Storm 방어를 위해 requestAnimationFrame 배칭 및 감시 옵션 하드닝 적용
    static async observeFor(target, options, callback, timeoutMs = 3500) {
      return new Promise((resolve) => {
        let isSettled = false;
        let mutationBuffer = [];
        let animationFrameId = null;
        const observer = new MutationObserver((mutations) => {
          if (isSettled) return;
          mutationBuffer.push(...mutations);
          if (animationFrameId !== null) return;
          animationFrameId = window.requestAnimationFrame(() => {
            animationFrameId = null;
            if (isSettled) return;
            const done = callback(mutationBuffer, observer);
            mutationBuffer = [];
            if (done) {
              isSettled = true;
              observer.disconnect();
              resolve(true);
            }
          });
        });
        const hardenedOptions = {
          ...options,
          attributes: options.attributes ?? false,
          characterData: options.characterData ?? false
        };
        observer.observe(target, hardenedOptions);
        setTimeout(() => {
          if (isSettled) return;
          isSettled = true;
          if (animationFrameId !== null) {
            window.cancelAnimationFrame(animationFrameId);
          }
          observer.disconnect();
          resolve(false);
        }, timeoutMs);
      });
    }
  };
  var CleanupOrchestrator = class {
    observers = /* @__PURE__ */ new Set();
    timeouts = /* @__PURE__ */ new Set();
    listeners = /* @__PURE__ */ new Set();
    registerObserver(obs) {
      this.observers.add(obs);
    }
    registerTimeout(id) {
      this.timeouts.add(id);
    }
    registerListener(target, type, handler, options) {
      target.addEventListener(type, handler, options);
      this.listeners.add({ target, type, handler, options });
    }
    cleanup() {
      for (const obs of this.observers) {
        try {
          obs.disconnect();
        } catch (e) {
          console.debug("[MAZA OS] Expected exception caught:", e);
        }
      }
      this.observers.clear();
      for (const id of this.timeouts) {
        try {
          clearTimeout(id);
        } catch (e) {
          console.debug("[MAZA OS] Expected exception caught:", e);
        }
      }
      this.timeouts.clear();
      for (const item of this.listeners) {
        try {
          item.target.removeEventListener(item.type, item.handler, item.options);
        } catch (e) {
          console.debug("[MAZA OS] Expected exception caught:", e);
        }
      }
      this.listeners.clear();
      console.log("[MAZA CleanupOrchestrator] Autopilot memory nodes successfully reclaimed.");
    }
  };
  async function waitUntil(predicate, timeoutMs = 8e3, pollInterval = 250, signal) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      if (signal?.aborted) return false;
      try {
        if (predicate()) return true;
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      await new Promise((r) => setTimeout(r, pollInterval));
    }
    return false;
  }
  function cleanHashtagsFromHtml(html, tags) {
    if (tags.length === 0) return html;
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
      const elements = Array.from(doc.body.querySelectorAll("p, div, span, h1, h2, h3, h4, h5, h6"));
      if (elements.length > 0) {
        const targets = elements.slice(-3);
        for (const el of targets) {
          let content = el.innerHTML;
          for (const tag of tags) {
            const tagRegex = new RegExp(`(?<=\\s|^|>|&nbsp;)#${tag}(?=<|\\s|$|&nbsp;)`, "g");
            content = content.replace(tagRegex, "");
          }
          el.innerHTML = content;
        }
      }
      doc.body.innerHTML = doc.body.innerHTML.replace(/<p>(?:\s|&nbsp;)*<\/p>/g, "");
      return doc.body.innerHTML;
    } catch (e) {
      let clean = html;
      const lastPart = clean.slice(-1e3);
      let cleanedLast = lastPart;
      for (const tag of tags) {
        const tagRegex = new RegExp(`(?=>|\\s)#${tag}(?=<|\\s|$)`, "g");
        cleanedLast = cleanedLast.replace(tagRegex, "");
      }
      return clean.slice(0, -1e3) + cleanedLast;
    }
  }
  function findThumbnailButton(root = document) {
    const candidates = Array.from(root.querySelectorAll("button, div, label, span, a"));
    const found = candidates.find((el) => {
      const text = el.textContent?.trim() || "";
      const aria = el.getAttribute("aria-label") || "";
      const cls = el.className || "";
      return text.includes("\uC378\uB124\uC77C") || text.includes("\uB300\uD45C") || text.includes("\uCEE4\uBC84") || aria.includes("\uC378\uB124\uC77C") || aria.includes("\uB300\uD45C") || aria.includes("\uCEE4\uBC84") || cls.toString().includes("thumbnail") || cls.toString().includes("cover") || cls.toString().includes("represent") || cls.toString().includes("btn_thumbnail") || el.id.includes("thumbnail") || el.id.includes("cover");
    });
    if (found) return found;
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          const res = findThumbnailButton(doc);
          if (res) return res;
        }
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
    }
    return null;
  }
  async function waitForThumbnailButton(timeout = 1e4, signal) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (signal?.aborted) return null;
      const btn = findThumbnailButton();
      if (btn) return btn;
      await new Promise((r) => setTimeout(r, 400));
    }
    return null;
  }
  async function prepareEditor() {
    const cancelDraftBtn = document.querySelector(".btn_layer.btn_cancel, .layer_post .btn_cancel");
    if (cancelDraftBtn) {
      cancelDraftBtn.click();
      await new Promise((r) => setTimeout(r, 800));
    }
    const editorSelectors = [
      '[data-ke-editor="true"]',
      ".ke-content[contenteditable]",
      ".ProseMirror[contenteditable]",
      '[role="textbox"][contenteditable]',
      "#editor-root [contenteditable]",
      ".tt-editor [contenteditable]",
      '[contenteditable="true"]'
    ];
    const start = Date.now();
    while (Date.now() - start < 1e4) {
      for (const sel of editorSelectors) {
        const el = findAnywhere(sel);
        if (el && el.isConnected) {
          await new Promise((r) => setTimeout(r, 300));
          return;
        }
      }
      await new Promise((r) => setTimeout(r, 400));
    }
  }
  async function injectTitle(title) {
    const titleSelectors = [
      "#post-title-field",
      "input.tf_title",
      "textarea.tf_tit",
      ".tf_tit",
      '[placeholder*="\uC81C\uBAA9"]',
      ".ph_tit",
      'input[name="title"]',
      ".editor-title-input"
    ].join(", ");
    let titleEl = await waitForElement(titleSelectors, 1e4);
    if (!titleEl && window.location.href.includes("/manage/page")) {
      titleEl = findAnywhere('input[name="title"], .editor-title-input, input[type="text"]');
    }
    if (!titleEl) {
      const listWriteBtn = await waitForElement(SELECTORS.writeBtn, 3e3);
      if (listWriteBtn) {
        listWriteBtn.click();
        return false;
      }
      return false;
    }
    try {
      titleEl.focus?.();
    } catch (e) {
      console.debug("[MAZA OS] Expected exception caught:", e);
    }
    if (titleEl.tagName === "TEXTAREA" || titleEl.tagName === "INPUT") {
      titleEl.value = title;
    } else {
      titleEl.textContent = title;
    }
    titleEl.dispatchEvent(new Event("input", { bubbles: true }));
    titleEl.dispatchEvent(new Event("change", { bubbles: true }));
    try {
      titleEl.blur?.();
    } catch (e) {
      console.debug("[MAZA OS] Expected exception caught:", e);
    }
    await new Promise((r) => setTimeout(r, 500));
    return true;
  }
  function isVisible(element) {
    if (!element) return false;
    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none" && style.opacity !== "0";
  }
  function findModeOption(texts, dataModes = []) {
    const candidates = Array.from(document.querySelectorAll('button, li, span, div, a, [role="menuitem"], [role="option"]'));
    return candidates.find((el) => {
      if (!isVisible(el)) return false;
      const text = (el.textContent || "").trim();
      const currentMode = (el.getAttribute("data-mode") || el.getAttribute("data-code") || "").toLowerCase();
      if (dataModes.length && dataModes.some((mode) => mode.toLowerCase() === currentMode)) {
        return true;
      }
      return texts.some((t) => text === t || text.replace(/\s+/g, "") === t.replace(/\s+/g, "") || text.includes(t));
    }) || null;
  }
  function isEditorModeDropdownOpen() {
    const menuButton = findAnywhere(SELECTORS.modeMenu);
    if (menuButton && menuButton.getAttribute("aria-expanded") === "true") {
      return true;
    }
    const candidateButtons = Array.from(document.querySelectorAll(
      'button, [role="button"], a, .btn_menu, .btn_mode, [class*="menu"], [class*="mode"], [class*="Mode"]'
    ));
    const triggerBtn = candidateButtons.find((el) => {
      if (!isVisible(el)) return false;
      const text = (el.textContent || "").trim();
      return /기본모드|기본 모드|HTML모드|HTML 모드/.test(text) || /모드|mode/i.test(text) && text.length <= 20;
    });
    if (triggerBtn && triggerBtn.getAttribute("aria-expanded") === "true") {
      return true;
    }
    const defaultBtn = findAnywhere(SELECTORS.defaultMode);
    if (defaultBtn && isVisible(defaultBtn)) {
      return true;
    }
    return false;
  }
  async function openEditorModeDropdown() {
    if (isEditorModeDropdownOpen()) {
      console.log("[MAZA Editor] Editor mode dropdown is already open.");
      return true;
    }
    const menuButton = findAnywhere(SELECTORS.modeMenu);
    if (menuButton && isVisible(menuButton)) {
      menuButton.click();
      await new Promise((r) => setTimeout(r, 600));
      return true;
    }
    const candidateButtons = Array.from(document.querySelectorAll(
      'button, [role="button"], a, .btn_menu, .btn_mode, [class*="menu"], [class*="mode"], [class*="Mode"]'
    ));
    const triggerBtn = candidateButtons.find((el) => {
      if (!isVisible(el)) return false;
      const text = (el.textContent || "").trim();
      return /기본모드|기본 모드|HTML모드|HTML 모드/.test(text) || /모드|mode/i.test(text) && text.length <= 20;
    });
    if (triggerBtn) {
      if (triggerBtn.getAttribute("aria-expanded") === "true") {
        return true;
      }
      triggerBtn.click();
      await new Promise((r) => setTimeout(r, 600));
      return true;
    }
    const reactTriggered = await reactClick(
      '#editor-mode-select, .btn_mode, [class*="mode_select"]',
      "\uAE30\uBCF8\uBAA8\uB4DC"
    );
    if (reactTriggered) {
      await new Promise((r) => setTimeout(r, 600));
      return true;
    }
    return false;
  }
  async function reactClick(selector, textContent) {
    return new Promise((resolve) => {
      let timeoutId = null;
      const requestId = crypto.randomUUID();
      const broker = MessageBroker.getInstance();
      broker.registerResolver(requestId, (payload) => {
        if (timeoutId) clearTimeout(timeoutId);
        broker.deregisterResolver(requestId);
        resolve(payload?.ok === true);
      });
      broker.getChannel().postMessage({
        requestId,
        action: "REACT_CLICK",
        selector,
        textContent
      });
      timeoutId = setTimeout(() => {
        broker.deregisterResolver(requestId);
        resolve(false);
      }, 1500);
    });
  }
  function isPublishLayerOpen() {
    const hasConfirmBtn = !!Array.from(document.querySelectorAll("button")).find((el) => {
      const txt = el.textContent?.trim() || "";
      return txt === "\uACF5\uAC1C \uBC1C\uD589" || txt === "\uBE44\uACF5\uAC1C \uBC1C\uD589" || txt === "\uBC1C\uD589" || txt === "\uACF5\uAC1C\uBC1C\uD589" || txt.includes("\uACF5\uAC1C \uBC1C\uD589");
    });
    return hasConfirmBtn || !!(document.querySelector(".layer_post") || document.querySelector(".layer_publish") || document.querySelector('[class*="layer_post"]') || document.querySelector('[class*="layer_publish"]') || document.querySelector('[role="dialog"][class*="publish"]'));
  }
  async function openPublishLayer(signal) {
    if (isPublishLayerOpen()) return true;
    for (let attempt = 0; attempt < 5; attempt++) {
      if (signal?.aborted) return false;
      try {
        document.body.click();
        document.body.focus();
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      await new Promise((r) => setTimeout(r, 150));
      const textCandidates = ["\uC644\uB8CC", "\uBC1C\uD589", "\uAC8C\uC2DC", "\uAE00 \uBC1C\uD589"];
      let publishBtn = null;
      for (const text of textCandidates) {
        const btn = findByTextAnywhere(text);
        if (btn && isVisible(btn)) {
          publishBtn = btn;
          break;
        }
      }
      if (!publishBtn) {
        publishBtn = findAnywhere(SELECTORS.publishBtn);
      }
      if (publishBtn && isVisible(publishBtn)) {
        console.log(`[MAZA] Publish button found: attempt ${attempt + 1}`);
        publishBtn.focus();
        await new Promise((r) => setTimeout(r, 100));
        publishBtn.click();
      } else {
        await reactClick(SELECTORS.publishBtn, "\uC644\uB8CC");
      }
      await new Promise((r) => setTimeout(r, 500));
      const layerOk = await waitUntil(isPublishLayerOpen, 3e3, 250, signal);
      if (layerOk) {
        console.log(`[MAZA] Publish layer opened: attempt ${attempt + 1}`);
        return true;
      }
    }
    return false;
  }
  var RetryBudget = class {
    constructor(limitMs = 15e3) {
      this.limitMs = limitMs;
    }
    limitMs;
    spent = 0;
    consume(ms) {
      this.spent += ms;
      return this.spent <= this.limitMs;
    }
  };
  var MazaFatalError = class extends Error {
    isFatal = true;
    constructor(message) {
      super(message);
      this.name = "MazaFatalError";
    }
  };
  async function retryWithJitter(fn, options) {
    let attempt = 0;
    let currentDelay = options.delay;
    const factor = options.factor || 1.5;
    const budget = options.budget || new RetryBudget();
    while (true) {
      if (options.signal?.aborted) {
        throw new Error("Operation aborted");
      }
      try {
        return await fn(options.signal);
      } catch (e) {
        attempt++;
        options.telemetry?.incrementRetry();
        if (attempt >= options.retries || e.isFatal) {
          throw e;
        }
        const jitter = (Math.random() * 0.2 - 0.1) * currentDelay;
        const sleepTime = Math.max(50, Math.floor(currentDelay + jitter));
        if (!budget.consume(sleepTime)) {
          throw new Error("Retry budget exhausted");
        }
        await new Promise((resolve, reject) => {
          const timeout = setTimeout(resolve, sleepTime);
          const abortHandler = () => {
            clearTimeout(timeout);
            reject(new Error("Operation aborted"));
          };
          options.signal?.addEventListener("abort", abortHandler);
        });
        currentDelay *= factor;
      }
    }
  }
  var SelfHealingBridge = class {
    static async ensureHealthy(signal) {
      const isHealthy = await this.ping(signal);
      if (isHealthy) return true;
      try {
        await chrome.runtime.sendMessage({ type: "LOAD_MAIN_WORLD_SCRIPT" });
        await new Promise((r) => setTimeout(r, 600));
        return await this.ping(signal);
      } catch (e) {
        console.warn("[MAZA Bridge] Lazy initialization check...");
      }
      return false;
    }
    static async ping(signal) {
      const requestId = crypto.randomUUID();
      return new Promise((resolve) => {
        let timeoutId = null;
        let settled = false;
        const broker = MessageBroker.getInstance();
        broker.registerResolver(requestId, (payload) => {
          if (settled) return;
          settled = true;
          if (timeoutId) clearTimeout(timeoutId);
          broker.deregisterResolver(requestId);
          resolve(payload?.type === "MAZA_PONG_RESULT");
        });
        if (signal?.aborted) {
          settled = true;
          broker.deregisterResolver(requestId);
          return resolve(false);
        }
        broker.getChannel().postMessage({
          requestId,
          action: "PING"
        });
        timeoutId = setTimeout(() => {
          if (settled) return;
          settled = true;
          broker.deregisterResolver(requestId);
          resolve(false);
        }, 800);
      });
    }
  };
  var MainWorldAdapter = class {
    async inject(html, sampleText, signal) {
      const isHealthy = await SelfHealingBridge.ensureHealthy(signal);
      if (!isHealthy) return false;
      const requestId = crypto.randomUUID();
      const editorName = this.getEditorName();
      return new Promise((resolve, reject) => {
        let timeoutId = null;
        let abortHandler = null;
        let settled = false;
        const broker = MessageBroker.getInstance();
        const cleanup = () => {
          if (timeoutId) {
            clearTimeout(timeoutId);
            timeoutId = null;
          }
          broker.deregisterResolver(requestId);
          if (abortHandler && signal) {
            signal.removeEventListener("abort", abortHandler);
            abortHandler = null;
          }
        };
        const finalize = (ok) => {
          if (settled) return;
          settled = true;
          cleanup();
          if (ok) {
            const triggerVerify = async () => {
              const verified = await this.verify(html, signal);
              resolve(verified);
            };
            if ("requestIdleCallback" in window) {
              window.requestIdleCallback(() => triggerVerify(), { timeout: 800 });
            } else {
              setTimeout(() => triggerVerify(), 600);
            }
          } else {
            resolve(false);
          }
        };
        abortHandler = () => {
          if (settled) return;
          settled = true;
          cleanup();
          reject(new Error(`${editorName} injection aborted`));
        };
        if (signal?.aborted) {
          settled = true;
          return reject(new Error("Aborted"));
        }
        signal?.addEventListener("abort", abortHandler);
        broker.registerResolver(requestId, (payload) => {
          if (settled) return;
          if (payload?.type === "MAZA_INJECT_POST_RESULT") {
            finalize(payload.ok);
          }
        });
        broker.getChannel().postMessage({
          action: "INJECT",
          requestId,
          html
        });
        timeoutId = setTimeout(() => {
          if (settled) return;
          settled = true;
          cleanup();
          console.warn(`[MAZA ${editorName}] Injection timeout.`);
          resolve(false);
        }, 6e3);
      });
    }
    async verify(html, signal) {
      const isHealthy = await SelfHealingBridge.ensureHealthy(signal);
      if (!isHealthy) return false;
      const requestId = crypto.randomUUID();
      return new Promise((resolve) => {
        let timeoutId = null;
        let settled = false;
        const broker = MessageBroker.getInstance();
        const cleanup = () => {
          if (timeoutId) clearTimeout(timeoutId);
          broker.deregisterResolver(requestId);
        };
        broker.registerResolver(requestId, (payload) => {
          if (settled) return;
          if (payload?.type === "MAZA_QUERY_RESULT") {
            settled = true;
            cleanup();
            resolve(compareSimilarity(html, payload.value || ""));
          }
        });
        broker.getChannel().postMessage({
          action: "QUERY",
          requestId
        });
        timeoutId = setTimeout(() => {
          if (settled) return;
          settled = true;
          cleanup();
          resolve(false);
        }, 3e3);
      });
    }
  };
  function isEditorElementDetected(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    return el.isConnected && style.display !== "none" && style.visibility !== "hidden";
  }
  var ProseMirrorAdapter = class extends MainWorldAdapter {
    detect() {
      const el = findAnywhere('[data-ke-editor="true"], [role="textbox"][contenteditable], .ProseMirror, #editor-root [contenteditable]');
      return isEditorElementDetected(el);
    }
    getEditorName() {
      return "ProseMirrorAdapter";
    }
    supportsTransactionalEditing() {
      return true;
    }
    supportsHtmlModelSync() {
      return false;
    }
    supportsVisualRestoration() {
      return true;
    }
  };
  var CodeMirrorAdapter = class extends MainWorldAdapter {
    detect() {
      const el = findAnywhere(".CodeMirror, .cm-editor, textarea#tx_canvas_source, textarea.tf_source");
      return isEditorElementDetected(el);
    }
    getEditorName() {
      return "CodeMirrorAdapter";
    }
    supportsTransactionalEditing() {
      return false;
    }
    supportsHtmlModelSync() {
      return true;
    }
    supportsVisualRestoration() {
      return false;
    }
  };
  async function waitForBodyEditor(timeout = 2e4) {
    const start = Date.now();
    const selectors = [
      ".ke-content[contenteditable]",
      '[data-ke-editor="true"]',
      ".ProseMirror[contenteditable]",
      '[role="textbox"][contenteditable="true"]',
      '#editor-root [contenteditable="true"]',
      '.tt-editor [contenteditable="true"]',
      "iframe.ke-iframe",
      '[contenteditable="true"]'
    ];
    while (Date.now() - start < timeout) {
      let editor = null;
      for (const sel of selectors) {
        const elems = findAnywhereAll(sel).filter((el) => {
          const id = el.id || "";
          const cls = (el.className || "").toString();
          const aria = el.getAttribute("aria-label") || "";
          const placeholder = el.getAttribute("placeholder") || "";
          const isTitleField = id.includes("title") || id.includes("tit") || cls.includes("title") || cls.includes("tf_tit") || cls.includes("post-title") || aria.includes("\uC81C\uBAA9") || placeholder.includes("\uC81C\uBAA9");
          if (isTitleField) return false;
          const style = window.getComputedStyle(el);
          if (style.display === "none" || style.visibility === "hidden") return false;
          return el.isConnected;
        });
        if (elems.length) {
          editor = elems.sort((a, b) => (b.offsetHeight || 0) - (a.offsetHeight || 0))[0];
          break;
        }
      }
      if (editor) return editor;
      await new Promise((r) => setTimeout(r, 300));
    }
    return null;
  }
  async function injectTistoryBody(html) {
    const editor = await waitForBodyEditor();
    if (!editor) {
      console.error("[MAZA] editor timeout. Body HTML dump (first 500):", document.body.innerHTML?.slice(0, 500));
      return false;
    }
    console.log("[MAZA] injecting to", editor.tagName, editor.className, editor.innerText?.slice(0, 50));
    if (editor.tagName === "IFRAME") {
      try {
        const iframeDoc = editor.contentDocument;
        if (iframeDoc) {
          const body = iframeDoc.body;
          body.focus();
          iframeDoc.execCommand("selectAll", false);
          iframeDoc.execCommand("delete", false);
          iframeDoc.execCommand("insertHTML", false, html);
          body.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertFromPaste" }));
          console.log("[MAZA] Body inserted (iframe mode)");
          return true;
        }
      } catch (e) {
        console.warn("[MAZA] iframe inject failed:", e);
      }
      return false;
    }
    editor.focus();
    await new Promise((r) => setTimeout(r, 300));
    try {
      document.execCommand("selectAll", false);
      document.execCommand("delete", false);
      const inserted = document.execCommand("insertHTML", false, html);
      if (inserted) {
        editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertFromPaste" }));
        console.log("[MAZA] Body inserted (execCommand insertHTML mode)");
        return true;
      }
    } catch (e) {
      console.warn("[MAZA] execCommand insertHTML failed, fallback to innerHTML:", e);
    }
    try {
      editor.innerHTML = html;
      editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertFromPaste" }));
      editor.dispatchEvent(new Event("change", { bubbles: true }));
      const reactKey = Object.keys(editor).find((k) => k.startsWith("__reactFiber") || k.startsWith("__reactInternals"));
      if (reactKey) {
        console.log("[MAZA] React fiber detected, dispatching synthetic input");
      }
      console.log("[MAZA] Body inserted (innerHTML fallback mode)");
      return true;
    } catch (e) {
      console.error("[MAZA] All injection methods failed:", e);
      return false;
    }
  }
  function setNativeValue(element, value) {
    const valueSetter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(element), "value")?.set;
    if (valueSetter) {
      valueSetter.call(element, value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      element.value = value;
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  async function reliableSetValue(input, value) {
    for (let i = 0; i < 3; i++) {
      setNativeValue(input, value);
      await new Promise((r) => setTimeout(r, 200));
      if (input.value === value) {
        return true;
      }
    }
    return false;
  }
  function isElementVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
  var EditorManager = class {
    // [AEAR Enterprise] 에디터를 기본 모드(ProseMirror)로 완전히 정착시키기 위한 안전성 확보
    async ensureDefaultMode(signal) {
      if (signal?.aborted) return false;
      const pMirror = new ProseMirrorAdapter();
      const cMirror = new CodeMirrorAdapter();
      await waitUntil(() => pMirror.detect() || cMirror.detect(), 5e3, 200, signal);
      if (pMirror.detect()) {
        return true;
      }
      if (cMirror.detect()) {
        let modeBtn = findAnywhere(SELECTORS.defaultMode);
        if (!modeBtn || !isVisible(modeBtn)) {
          await openEditorModeDropdown();
          modeBtn = findModeOption(["\uAE30\uBCF8\uBAA8\uB4DC", "\uAE30\uBCF8 \uBAA8\uB4DC", "\uAE30\uBCF8"], ["default", "prose", "wysiwyg", "visual"]);
        }
        if (modeBtn && isVisible(modeBtn)) {
          await clickAnywhere(modeBtn);
          await new Promise((r) => setTimeout(r, 800));
          return waitUntil(() => pMirror.detect(), 5e3, 200, signal);
        }
      }
      return pMirror.detect();
    }
    // [DEPRECATED] HTML 모드 탐색 완전 제거 — WYSIWYG 직접 주입(injectTistoryBody)으로 전환
    // 티스토리 기본모드(WYSIWYG) 상태에서 contenteditable에 직접 주입하므로 HTML 모드 전환 불필요
    async ensureHtmlMode(_signal) {
      return false;
    }
    async restoreDefaultMode(signal) {
      return this.ensureDefaultMode(signal);
    }
    async runInjectionFlow(html, sampleText, signal, telemetry) {
      const adapters = [
        { inst: new ProseMirrorAdapter(), name: "PROSEMIRROR" },
        { inst: new CodeMirrorAdapter(), name: "CODEMIRROR" }
      ];
      for (let attempt = 1; attempt <= 3; attempt++) {
        if (signal?.aborted) break;
        for (const adapter of adapters) {
          if (adapter.inst.detect()) {
            console.log(`[MAZA Editor] Detection Attempt ${attempt}/3: Detected ${adapter.name}. Executing injection flow...`);
            const ok = await adapter.inst.inject(html, sampleText, signal);
            if (ok) {
              telemetry?.setAdapterType(adapter.name);
              return adapter.name;
            }
          }
        }
        if (attempt < 3) {
          await new Promise((r) => setTimeout(r, 400));
        }
      }
      return "NONE";
    }
  };
  var ThumbnailManager = class {
    async upload(thumbnailImgUrl, signal) {
      if (signal?.aborted) return false;
      try {
        const response = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: "FETCH_IMAGE", url: thumbnailImgUrl }, resolve);
        });
        if (!response.ok || !response.dataUrl) return false;
        const res = await fetch(response.dataUrl);
        const blob = await res.blob();
        const file = new File([blob], "thumbnail.jpg", { type: blob.type });
        const thumbButton = await waitForThumbnailButton(8e3, signal);
        if (!thumbButton) return false;
        let fileInput = null;
        const beforeInputs = Array.from(document.querySelectorAll('input[type="file"]'));
        const container = document.querySelector(".layer_post") || document.body;
        thumbButton.click();
        const uploadTriggered = await ShortObserver.observeFor(
          container,
          { childList: true, subtree: true },
          (mutations) => {
            for (const m of mutations) {
              for (const node of Array.from(m.addedNodes)) {
                if (node.nodeType !== Node.ELEMENT_NODE) continue;
                const el = node;
                const found = el.tagName === "INPUT" && el.getAttribute("type") === "file" ? el : el.querySelector('input[type="file"]');
                if (found) {
                  fileInput = found;
                  return true;
                }
              }
            }
            return false;
          },
          3500
          // 최대 3.5초만 살려둠
        );
        if (!uploadTriggered || !fileInput) {
          await waitUntil(() => fileInput !== null, 2e3, 150, signal);
        }
        if (!fileInput) {
          const afterInputs = Array.from(document.querySelectorAll('input[type="file"]'));
          fileInput = afterInputs.find((i) => !beforeInputs.includes(i) && i.isConnected) || afterInputs[0] || null;
        }
        if (!fileInput) return false;
        const dt = new DataTransfer();
        dt.items.add(file);
        fileInput.files = dt.files;
        fileInput.dispatchEvent(new Event("change", { bubbles: true }));
        const modal = document.querySelector(".thumbnail-modal") || document;
        const budget = new RetryBudget(1e4);
        const uploadSuccess = await retryWithJitter(async () => {
          const preview = modal.querySelector(".thumbnail_preview img") || modal.querySelector('[class*="preview"] img');
          const confirmBtn = Array.from(modal.querySelectorAll("button")).find((el) => el.textContent?.includes("\uD655\uC778")) || findByTextAnywhere("\uD655\uC778");
          const previewImg = preview;
          const srcReady = previewImg?.src && previewImg.naturalWidth > 0;
          if (srcReady && confirmBtn && !confirmBtn.disabled) {
            return true;
          }
          throw new Error("Preview not ready...");
        }, { retries: 20, delay: 350, factor: 1.05, signal, budget });
        if (uploadSuccess) {
          const confirmBtn = Array.from(modal.querySelectorAll("button")).find((el) => el.textContent?.includes("\uD655\uC778")) || findByTextAnywhere("\uD655\uC778");
          if (confirmBtn) {
            confirmBtn.click();
            await new Promise((r) => setTimeout(r, 1e3));
            return true;
          }
        }
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      return false;
    }
  };
  var TagManager = class {
    extractTags(html) {
      const foundTags = [];
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
      const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
      let node = walker.nextNode();
      const regex = /#([a-zA-Z0-9ㄱ-ㅎㅏ-ㅣ가-힣_\-]+)/g;
      while (node) {
        const txt = node.textContent || "";
        let m;
        while ((m = regex.exec(txt)) !== null) {
          const tag = m[1];
          if (!/^[0-9a-fA-F]{3,6}$/.test(tag) && tag.toLowerCase() !== "toc" && !foundTags.includes(tag)) {
            foundTags.push(tag);
          }
        }
        node = walker.nextNode();
      }
      return foundTags;
    }
    cleanHashtagsFromHtml(html, tags) {
      return cleanHashtagsFromHtml(html, tags);
    }
    async inject(foundTags, signal) {
      if (foundTags.length === 0 || signal?.aborted) return false;
      await new Promise((r) => setTimeout(r, 500));
      const tagInput = findAnywhere(".tag_input input") || findAnywhere("input#tagText") || findAnywhere("input.text_tag") || findAnywhere('input[name="tag"]') || findAnywhere('input[placeholder*="\uD0DC\uADF8"]') || findAnywhere('input[placeholder*="tag"]');
      if (tagInput) {
        for (const tag of foundTags) {
          if (signal?.aborted) return false;
          await reliableSetValue(tagInput, tag.trim());
          tagInput.dispatchEvent(new Event("input", { bubbles: true }));
          tagInput.dispatchEvent(new Event("change", { bubbles: true }));
          tagInput.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
          tagInput.dispatchEvent(new KeyboardEvent("keyup", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
          await new Promise((r) => setTimeout(r, 250));
          await new Promise((r) => setTimeout(r, 300));
        }
        return true;
      }
      return false;
    }
  };
  var PublishVerifier = class {
    async verify(signal) {
      let confirmed = false;
      let lastScreenshot = null;
      for (let i = 0; i < 8; i++) {
        if (signal?.aborted) return { ok: false, error: "ABORTED" };
        const modal = document.querySelector(".layer_post") || document.querySelector(".layer_publish") || document.querySelector('[class*="layer_post"]') || document.querySelector('[class*="layer_publish"]') || document.body;
        let confirmBtn = modal.querySelector("#publish-btn, button.btn_confirm, .btn_confirm");
        if (!confirmBtn || !isElementVisible(confirmBtn)) {
          const fallback = Array.from(modal.querySelectorAll("button")).find((el) => {
            const txt = el.textContent?.trim() || "";
            return txt === "\uBC1C\uD589" || txt === "\uD655\uC778" || txt === "\uACF5\uAC1C \uBC1C\uD589" || txt.includes("\uBC1C\uD589") || txt.includes("\uACF5\uAC1C\uBC1C\uD589");
          });
          if (fallback) confirmBtn = fallback;
        }
        if (confirmBtn && isElementVisible(confirmBtn)) {
          console.log("[MAZA Editor] Clicking final publish button in modal:", confirmBtn.tagName, confirmBtn.textContent?.trim());
          confirmed = true;
          chrome.runtime.sendMessage({
            type: "TASK_CONFIRMED_PUBLISHING",
            publishedUrl: `https://${window.location.hostname}/manage/post`
          }).catch(() => {
          });
          const publicLabels = Array.from(modal.querySelectorAll("label, span, button, .text")).filter((el) => {
            const txt = el.textContent?.trim() || "";
            return txt === "\uACF5\uAC1C" || txt === "Public";
          });
          for (const el of publicLabels) {
            if (isElementVisible(el)) {
              console.log('[MAZA Editor] Selecting "Public" (\uACF5\uAC1C) option...');
              el.click();
              await reactClick(void 0, "\uACF5\uAC1C");
              await new Promise((r) => setTimeout(r, 200));
            }
          }
          const topicDropdowns = Array.from(modal.querySelectorAll("button, a, div, span.txt_select")).filter((el) => {
            const txt = el.textContent?.trim() || "";
            return txt === "\uC120\uD0DD \uC548 \uD568" || txt === "\uC8FC\uC81C \uC120\uD0DD" || txt.includes("\uC8FC\uC81C \uC120\uD0DD");
          });
          for (const topicDropdown of topicDropdowns) {
            if (isElementVisible(topicDropdown)) {
              console.log("[MAZA Editor] Topic is not selected. Opening topic dropdown...");
              topicDropdown.click();
              await reactClick(void 0, topicDropdown.textContent?.trim());
              await new Promise((r) => setTimeout(r, 600));
              const options = Array.from(document.querySelectorAll('.list_select li, .layer_post li, [role="option"], .box_select li a, .list_item, .item_select'));
              const validOption = options.find((el) => {
                const txt = el.textContent?.trim() || "";
                return txt.length > 0 && txt !== "\uC120\uD0DD \uC548 \uD568" && txt !== "\uC8FC\uC81C \uC120\uD0DD" && !txt.includes("\uC120\uD0DD \uC548 \uD568");
              });
              if (validOption) {
                console.log("[MAZA Editor] Selecting topic:", validOption.textContent?.trim());
                const aTag = validOption.querySelector("a") || validOption;
                aTag.click();
                await reactClick(void 0, validOption.textContent?.trim());
                await new Promise((r) => setTimeout(r, 400));
              }
              break;
            }
          }
          confirmBtn.removeAttribute("disabled");
          confirmBtn.removeAttribute("aria-disabled");
          confirmBtn.classList.remove("disabled");
          confirmBtn.disabled = false;
          confirmBtn.click();
          const mouseEvents = ["mousedown", "mouseup", "click"];
          for (const ev of mouseEvents) {
            confirmBtn.dispatchEvent(new MouseEvent(ev, { bubbles: true, cancelable: true, view: window }));
          }
          const pointerEvents = ["pointerdown", "pointerup"];
          for (const ev of pointerEvents) {
            confirmBtn.dispatchEvent(new PointerEvent(ev, { bubbles: true, cancelable: true, view: window }));
          }
          chrome.runtime.sendMessage({
            type: "EXECUTE_MAIN_WORLD",
            funcId: "forceReactClick",
            args: [".btn_confirm, #publish-btn"]
          });
          await reactClick(void 0, confirmBtn.textContent?.trim() || "\uBC1C\uD589");
        }
        if (confirmed) {
          const broker = MessageBroker.getInstance();
          const budget = new RetryBudget(45e3);
          try {
            const result = await retryWithJitter(async () => {
              const curUrl = window.location.href;
              const apiSuccess = broker.isApiSuccessIntercepted();
              const hasPostUrl = /\/entry\/|\/\d+/.test(curUrl);
              const isManagePosts = curUrl.includes("/manage/posts");
              const ogUrl = document.querySelector('meta[property="og:url"]')?.getAttribute("content") || "";
              const canonicalUrl = document.querySelector('link[rel="canonical"]')?.getAttribute("href") || "";
              const isOut = !curUrl.includes("/manage/post/write") && !curUrl.includes("/manage/page/write") && !curUrl.includes("/manage/newpost");
              let score = 0;
              if (apiSuccess) score += 2;
              if (hasPostUrl) score += 1.5;
              if (isManagePosts) score += 1.5;
              if (isOut) score += 0.8;
              console.log(`[MAZA OS Verifier] Deterministic Score: ${score}/5.8 (Threshold: 2.0)`);
              if (score >= 2) {
                const candidateUrl = ogUrl || canonicalUrl || curUrl;
                if (isManagePosts || score >= 3.5) {
                  console.log(`[MAZA OS Verifier] Fast-path verification passed. Bypassing fetch check.`);
                  return { ok: true, status: "PUBLISHED", published_url: candidateUrl };
                }
                console.log(`[MAZA OS Verifier] Verification: Fetching canonical page "${candidateUrl}" to verify 200 OK and title match.`);
                try {
                  const checkRes = await fetch(candidateUrl, { method: "GET", cache: "no-store" });
                  if (checkRes.status === 200) {
                    const htmlText = await checkRes.text();
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(htmlText, "text/html");
                    const checkTitle = doc.querySelector("title")?.textContent || "";
                    const ogTitle = doc.querySelector('meta[property="og:title"]')?.getAttribute("content") || "";
                    console.log(`[MAZA OS Verifier] Verified \uB77C\uC774\uBE0C \uB9E4\uCE6D \uC131\uACF5: Title="${checkTitle}" | OG Title="${ogTitle}"`);
                    return { ok: true, status: "PUBLISHED", published_url: candidateUrl };
                  } else {
                    console.warn(`[MAZA OS Verifier] Fetch verification returned non-200 status: ${checkRes.status}`);
                  }
                } catch (fetchErr) {
                  console.warn(`[MAZA OS Verifier] Fetch failed (possibly due to network/CORS), evaluating fallback...`, fetchErr);
                }
                if (score >= 3.5) {
                  console.log(`[MAZA OS Verifier] Fetch verification failed but scoring threshold is extremely strong (${score}). Bypassing...`);
                  return { ok: true, status: "PUBLISHED", published_url: candidateUrl };
                }
              }
              throw new Error("Wait route...");
            }, { retries: 45, delay: 500, factor: 1.05, signal, budget });
            return result;
          } catch (e) {
            console.warn("[MAZA OS Verifier] verification attempt waiting...", e);
          }
        }
        await new Promise((r) => setTimeout(r, 1e3));
      }
      try {
        const capRes = await chrome.runtime.sendMessage({ type: "CAPTURE_SCREENSHOT" });
        if (capRes?.ok && capRes.screenshot) {
          lastScreenshot = capRes.screenshot;
          console.log("[MAZA OS Verifier] Diagnostic screenshot captured successfully.");
        }
      } catch (screenshotErr) {
        console.warn("[MAZA OS Verifier] Background screenshot request failed:", screenshotErr);
      }
      return { ok: false, error: "PUBLISH_VERIFICATION_TIMEOUT", screenshot: lastScreenshot || void 0 };
    }
  };
  var _injectContentInFlight = false;
  async function injectContent(title, html) {
    if (!html || html.trim().length < 50) {
      console.error("[MAZA OS Driver] \u274C Empty or too-short body content. Aborting to prevent empty post publish.", { length: html?.length ?? 0 });
      return { ok: false, status: "FAILED", error: "EMPTY_BODY: Content too short (< 50 chars). Check html_content in DB." };
    }
    if (_injectContentInFlight || window.__MAZA_INJECTING__) {
      console.warn("[MAZA OS Driver] injectContent already in flight. Ignoring duplicate call.");
      return { ok: false, status: "DUPLICATE_IGNORED", error: "Already running" };
    }
    _injectContentInFlight = true;
    window.__MAZA_INJECTING__ = true;
    console.log("[MAZA OS Tistory Driver] Autopilot Sequence Initiated.");
    const telemetry = new TelemetryManager();
    telemetry.trackStepStart("publishDuration");
    const fsm = new HierarchicalStateMachine();
    const orchestrator = new CleanupOrchestrator();
    const broker = MessageBroker.getInstance();
    broker.resetApiIntercept();
    broker.start();
    const abortController = new AbortController();
    const signal = abortController.signal;
    const editorManager = new EditorManager();
    const thumbnailManager = new ThumbnailManager();
    const tagManager = new TagManager();
    const publishVerifier = new PublishVerifier();
    let cleanHtml = html.trim();
    const titleText = title.trim();
    let foundTags = [];
    let thumbnailImgUrl = null;
    console.log("[MAZA Thumb] Uploading thumbnail to Tistory CDN...");
    cleanHtml = await replaceImagesWithTistoryCDN(cleanHtml);
    try {
      fsm.transitionTo("INIT");
      try {
        await chrome.runtime.sendMessage({ type: "LOAD_MAIN_WORLD_SCRIPT" });
        await new Promise((r) => setTimeout(r, 900));
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      fsm.transitionTo("EDITOR_READY");
      telemetry.trackStepStart("editorDetection");
      await prepareEditor();
      try {
        const parser = new DOMParser();
        const doc = parser.parseFromString(cleanHtml, "text/html");
        const firstHeading = doc.querySelector("h1, h2, h3, h4, h5, h6");
        if (firstHeading && firstHeading.textContent?.trim() === titleText) {
          firstHeading.remove();
          cleanHtml = doc.body.innerHTML;
        }
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      cleanHtml = cleanHtml.replace(/(?<!highlight\s*\{\s*)color\s*:\s*(?:white|#fff(fff)?|#fcfcfc)/gi, "color: inherit");
      cleanHtml = cleanHtml.replace(/(?<!syntax|code|pre|img)background-color\s*:\s*(?:black|#000(000)?|#111(111)?)/gi, "background-color: transparent");
      let parsedUrl = null;
      const imgMatch = cleanHtml.match(/<img[^>]+(?:src|data-src)=["']([^"']+)["']/i);
      if (imgMatch) {
        parsedUrl = imgMatch[1];
      } else {
        const mdMatch = cleanHtml.match(/!\[.*?\]\((https?:\/\/[^\s)]+)\)/i);
        if (mdMatch) parsedUrl = mdMatch[1];
      }
      thumbnailImgUrl = parsedUrl;
      foundTags = tagManager.extractTags(cleanHtml);
      cleanHtml = tagManager.cleanHashtagsFromHtml(cleanHtml, foundTags);
      telemetry.trackStepEnd("editorDetection");
      fsm.transitionTo("CONTENT_INJECTED");
      telemetry.trackStepStart("contentInjection");
      let bodyOk = false;
      try {
        console.log("[MAZA WYSIWYG] Attempting MainWorld transaction injection via runInjectionFlow...");
        const injectedAdapter = await editorManager.runInjectionFlow(cleanHtml, "sampleText", signal, telemetry);
        if (injectedAdapter !== "NONE") {
          console.log(`[MAZA WYSIWYG] Injected successfully via ${injectedAdapter}`);
          bodyOk = true;
        }
      } catch (err) {
        console.warn("[MAZA WYSIWYG] MainWorld transaction injection failed, trying fallback...", err);
      }
      if (!bodyOk) {
        console.warn("[MAZA WYSIWYG] Falling back to content-script level injectTistoryBody...");
        bodyOk = await injectTistoryBody(cleanHtml);
      }
      if (!bodyOk) {
        console.error("[MAZA WYSIWYG] Both MainWorld and content-script injection failed (timeout)");
        fsm.setSubFlow("contentFlow", "FAILED");
        console.warn("editor missing");
        const finalMetrics2 = telemetry.compileMetrics(false, false, ["editor missing"]);
        return { ok: false, status: "FAILED", error: "BODY_INJECTION_FAILED", metrics: finalMetrics2 };
      }
      fsm.setSubFlow("contentFlow", "SUCCESS");
      telemetry.trackStepEnd("contentInjection");
      const titleOk = await injectTitle(titleText);
      if (!titleOk) {
        console.warn("[MAZA OS Driver] Title injection failed \u2014 continuing...");
      }
      try {
        const tagOk = await tagManager.inject(foundTags, signal);
        fsm.setSubFlow("tagFlow", tagOk ? "SUCCESS" : "FAILED");
      } catch (e) {
        fsm.setSubFlow("tagFlow", "FAILED");
      }
      fsm.transitionTo("PUBLISH_LAYER");
      const layerOpened = await openPublishLayer(signal);
      if (!layerOpened) {
        fsm.setSubFlow("verifyFlow", "FAILED");
        const finalMetrics2 = telemetry.compileMetrics(false, false, ["Failed to open publish layer"]);
        return { ok: false, status: "FAILED_PUBLISH_LAYER", metrics: finalMetrics2 };
      }
      if (thumbnailImgUrl) {
        telemetry.trackStepStart("thumbnailUpload");
        await new Promise((r) => setTimeout(r, 1e3));
        try {
          const thumbOk = await thumbnailManager.upload(thumbnailImgUrl, signal);
          fsm.setSubFlow("thumbnailFlow", thumbOk ? "SUCCESS" : "FAILED");
        } catch (e) {
          fsm.setSubFlow("thumbnailFlow", "FAILED");
        }
        telemetry.trackStepEnd("thumbnailUpload");
      } else {
        fsm.setSubFlow("thumbnailFlow", "SKIPPED");
      }
      await tagManager.inject(foundTags, signal);
      fsm.transitionTo("VERIFIED");
      const publishResult = await publishVerifier.verify(signal);
      if (!publishResult.ok) {
        fsm.setSubFlow("verifyFlow", "FAILED");
        const finalMetrics2 = telemetry.compileMetrics(false, false, [publishResult.error || "PUBLISH_VERIFICATION_TIMEOUT"]);
        return {
          ok: false,
          status: "FAILED",
          error: publishResult.error || "PUBLISH_VERIFICATION_TIMEOUT",
          metrics: finalMetrics2
        };
      }
      fsm.setSubFlow("verifyFlow", "SUCCESS");
      fsm.transitionTo("DONE");
      telemetry.trackStepEnd("publishDuration");
      const evalResult = fsm.evaluateFinalResult();
      const finalMetrics = telemetry.compileMetrics(evalResult.ok, evalResult.status === "PUBLISHED_WITH_WARNINGS", evalResult.warnings);
      return {
        ok: evalResult.ok,
        status: evalResult.status,
        published_url: publishResult.published_url,
        warnings: evalResult.warnings,
        metrics: finalMetrics
      };
    } catch (err) {
      console.error(`[MAZA OS Driver] Execution crashed at state: ${fsm.getCurrentState()}.`, err);
      abortController.abort();
      telemetry.trackStepEnd("publishDuration");
      telemetry.captureCrash(fsm.getCurrentState(), err.message || "UNKNOWN_ERROR");
      const finalMetrics = telemetry.compileMetrics(false, false, [err.message || "FATAL_CRASH"]);
      if (err instanceof MazaFatalError) {
        if (err.message === "NAVIGATING_TO_EDITOR") {
          return { ok: true, status: "NAVIGATING_TO_EDITOR", metrics: finalMetrics };
        }
        return { ok: false, status: "FAILED", error: err.message, metrics: finalMetrics };
      }
      return { ok: false, status: "FAILED", error: err.message || "UNKNOWN_ERROR", metrics: finalMetrics };
    } finally {
      _injectContentInFlight = false;
      window.__MAZA_INJECTING__ = false;
      orchestrator.cleanup();
      broker.cleanup();
    }
  }

  // extension/platforms/tistory/infra.ts
  async function autoAcceptTistoryDialog() {
    await new Promise((resolve) => {
      chrome.runtime.sendMessage({
        type: "EXECUTE_MAIN_WORLD",
        funcId: "autoAcceptDialog"
      }, (res) => resolve(res));
    });
  }
  async function injectViaMainWorld(html) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({
        type: "EXECUTE_MAIN_WORLD",
        funcId: "injectInfra",
        args: [html]
      }, (res) => {
        resolve(res || { ok: false, error: "No response from background script" });
      });
    });
  }
  async function injectInfra(html) {
    try {
      console.log("[MAZA OS] Starting Infra Injection...");
      notifyProgress("STARTING");
      const href = window.location.href;
      if (href.includes("/auth/login") || href.includes("accounts.kakao.com") || href.includes("auth.kakao.com")) {
        notifyProgress("WAITING_LOGIN", "\uB85C\uADF8\uC778 \uC644\uB8CC \uD6C4 \uC790\uB3D9\uC73C\uB85C HTML \uD3B8\uC9D1 \uD654\uBA74\uC73C\uB85C \uC774\uB3D9\uD569\uB2C8\uB2E4.");
        throw new Error("\uD2F0\uC2A4\uD1A0\uB9AC \uB85C\uADF8\uC778\uC774 \uD544\uC694\uD569\uB2C8\uB2E4. \uCE74\uCE74\uC624 \uB85C\uADF8\uC778\uC744 \uC644\uB8CC\uD574 \uC8FC\uC138\uC694.");
      }
      if (!href.includes("/manage/")) {
        throw new Error("\uC2A4\uD0A8 \uD3B8\uC9D1 \uD398\uC774\uC9C0\uAC00 \uC544\uB2D9\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");
      }
      const hasEditor = findAnywhere(".CodeMirror, .cm-editor, #htmlEditor");
      if (!hasEditor) {
        console.log("[MAZA OS] Editor not visible. Trying to navigate to HTML edit mode...");
        notifyProgress("BUTTON_CLICKED");
        await autoAcceptTistoryDialog();
        const htmlEditBtn = findByTextAnywhere("html \uD3B8\uC9D1") || findByTextAnywhere("HTML \uD3B8\uC9D1") || findAnywhere('[href*="source/html"], [data-tab="html"]');
        if (htmlEditBtn) {
          await clickAnywhere(htmlEditBtn);
          console.log("[MAZA OS] HTML edit button clicked.");
        }
        const appeared = await waitForElement(".CodeMirror, .cm-editor, textarea", 15e3);
        if (!appeared) {
          throw new Error("HTML \uC5D0\uB514\uD130\uB97C \uC5F4 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uC2A4\uD0A8 \uD3B8\uC9D1 \uD398\uC774\uC9C0\uC5D0\uC11C \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");
        }
      }
      notifyProgress("EDITOR_READY");
      console.log("[MAZA OS] Injecting via MAIN World script...");
      const injectResult = await injectViaMainWorld(html);
      if (!injectResult.ok) {
        throw new Error(injectResult.error || "CodeMirror \uC8FC\uC785 \uC2E4\uD328");
      }
      if (injectResult.step === "ALREADY_INJECTED") {
        console.log("[MAZA OS] Infra already injected.");
        notifyProgress("ALREADY_INJECTED");
        return { ok: true, step: "ALREADY_INJECTED" };
      }
      notifyProgress("CODE_INJECTED");
      console.log("[MAZA OS] Code injected successfully. Clicking apply button...");
      await new Promise((r) => setTimeout(r, 800));
      const applyBtn = findByTextAnywhere("\uC801\uC6A9") || findByTextAnywhere("\uC800\uC7A5") || findAnywhere('button[type="submit"]');
      if (applyBtn) {
        notifyProgress("SAVE_CLICKED");
        await clickAnywhere(applyBtn);
        console.log("[MAZA OS] Apply button clicked.");
      } else {
        console.warn("[MAZA OS] Apply button not found. Manual save required.");
      }
      notifyProgress("SUCCESS");
      return { ok: true, step: "SUCCESS" };
    } catch (err) {
      console.error("[MAZA OS] Infra injection failed:", err);
      notifyProgress("ERROR", err.message);
      return { ok: false, error: err.message };
    }
  }

  // extension/content/injector.ts
  console.log("%c[MAZA OS] Tistory Injector Active!", "color: #8b5cf6; font-weight: bold; font-size: 14px;");
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    console.log(`[MAZA OS] Message Received: ${msg.type}`);
    if (msg.type === "MAZA_PING") {
      sendResponse({ ok: true });
      return false;
    }
    if (msg.type === "RUN_TASK") {
      handleTask(msg.task).then(sendResponse).catch((err) => sendResponse({ ok: false, error: err.message }));
      return true;
    }
  });
  var MAX_READY_ATTEMPTS = 3;
  var readyAttempts = 0;
  function announceReady() {
    if (readyAttempts >= MAX_READY_ATTEMPTS) {
      console.warn(`[MAZA OS] Gave up sending READY signal after ${MAX_READY_ATTEMPTS} attempts.`);
      return;
    }
    const backoffMs = Math.pow(2, readyAttempts) * 500;
    readyAttempts++;
    console.log(`[MAZA OS] Sending READY signal to background (attempt ${readyAttempts}/${MAX_READY_ATTEMPTS})...`);
    chrome.runtime.sendMessage({ type: "CONTENT_SCRIPT_READY" }, (response) => {
      if (chrome.runtime.lastError) {
        console.warn(`[MAZA OS] Background not ready yet, retrying in ${backoffMs}ms...`);
        setTimeout(announceReady, backoffMs);
      } else {
        console.log("[MAZA OS] READY signal acknowledged by background.");
      }
    });
  }
  announceReady();
  async function handleTask(task) {
    console.log(`[MAZA OS] Received Task: ${task.type}`);
    if (task.platform === "tistory") {
      if (task.type === "PUBLISH_POST") {
        return injectContent(task.payload.title, task.payload.body || task.payload.html);
      }
      if (task.type === "INFRA_INJECT") {
        return injectInfra(task.payload.html);
      }
    }
    return { ok: false, error: "Unknown Task" };
  }
})();
//# sourceMappingURL=injector.js.map
