"use strict";
(() => {
  // extension/utils/dom.ts
  function findAnywhere(selector, root = document) {
    if (Array.isArray(selector)) {
      for (const s of selector) {
        const found = findAnywhere(s, root);
        if (found) return found;
      }
      return null;
    }
    const el = root.querySelector(selector);
    if (el) return el;
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          const found = findAnywhere(selector, doc);
          if (found) return found;
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        const found = findAnywhere(selector, node.shadowRoot);
        if (found) return found;
      }
    }
    return null;
  }
  function findAnywhereAll(selector, root = document) {
    const elements = [];
    const seen = /* @__PURE__ */ new Set();
    const pushUnique = (items) => {
      for (const item of items) {
        if (!seen.has(item)) {
          seen.add(item);
          elements.push(item);
        }
      }
    };
    if (Array.isArray(selector)) {
      for (const s of selector) {
        pushUnique(findAnywhereAll(s, root));
      }
      return elements;
    }
    pushUnique(Array.from(root.querySelectorAll(selector)));
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          pushUnique(findAnywhereAll(selector, doc));
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        pushUnique(findAnywhereAll(selector, node.shadowRoot));
      }
    }
    return elements;
  }

  // extension/content/contextDetector.ts
  function detectContext() {
    const url = window.location.href;
    const title = document.title;
    if (url.includes("youtube.com/watch")) {
      const videoId = new URLSearchParams(window.location.search).get("v") || "";
      const thumbnail = videoId ? `https://img.youtube.com/vi/${videoId}/mqdefault.jpg` : "";
      const description = findAnywhere('meta[name="description"]')?.content || "";
      return {
        type: "MAZA_CONTEXT",
        contextType: "youtube",
        data: { url, title, videoId, thumbnailUrl: thumbnail, description }
      };
    }
    const bodyImages = findAnywhereAll("body > img, body > picture > img");
    if (bodyImages.length === 1) {
      const img = bodyImages[0];
      return {
        type: "MAZA_CONTEXT",
        contextType: "image",
        data: { url, title, imageUrl: img.src }
      };
    }
    const blogDomains = [
      "tistory.com",
      "naver.com",
      "brunch.co.kr",
      "velog.io",
      "medium.com",
      "wordpress.com",
      "blogspot.com",
      "blog.naver.com",
      "news.naver.com",
      "chosun.com",
      "hani.co.kr",
      "donga.com",
      "mk.co.kr"
    ];
    const isBlog = blogDomains.some((d) => url.includes(d));
    if (isBlog) {
      const ogImage = findAnywhere('meta[property="og:image"]')?.content || "";
      const metaDesc = findAnywhere('meta[name="description"]')?.content || "";
      const articleEl = findAnywhere("article, .post-content, .entry-content, #post-content, .article-body");
      const text = articleEl ? (articleEl.textContent || "").trim().slice(0, 500) : "";
      return {
        type: "MAZA_CONTEXT",
        contextType: "blog",
        data: { url, title, thumbnailUrl: ogImage, description: metaDesc, text }
      };
    }
    const searchEngines = {
      "google.com/search": "q",
      "search.naver.com": "query",
      "search.daum.net": "q",
      "bing.com/search": "q"
    };
    for (const [domain, param] of Object.entries(searchEngines)) {
      if (url.includes(domain)) {
        const keyword = new URLSearchParams(window.location.search).get(param) || "";
        if (keyword) {
          return {
            type: "MAZA_CONTEXT",
            contextType: "keyword",
            data: { url, title, keyword }
          };
        }
      }
    }
    return null;
  }
  async function sendContextToMazaStudio(context) {
    try {
      chrome.runtime.sendMessage({ type: "MAZA_CONTEXT_DETECTED", context }).catch(() => {
      });
    } catch (e) {
      console.debug("[MAZA Context] Error sending context via message:", e);
    }
  }
  function run() {
    const currentUrl = window.location.href;
    if (currentUrl.includes("mazastudio.kr") || /localhost:\d+/.test(currentUrl)) return;
    const context = detectContext();
    if (context) {
      console.log("[MAZA Context] Detected:", context.contextType, context.data.title);
      sendContextToMazaStudio(context);
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", run);
  } else {
    run();
  }
})();
//# sourceMappingURL=contextDetector.js.map
