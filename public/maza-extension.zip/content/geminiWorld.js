"use strict";
(() => {
  // extension/utils/dom.ts
  function findAnywhere(selector, root = document) {
    if (Array.isArray(selector)) {
      for (const s of selector) {
        const found = findAnywhere(s, root);
        if (found) return found;
      }
      return null;
    }
    const el = root.querySelector(selector);
    if (el) return el;
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          const found = findAnywhere(selector, doc);
          if (found) return found;
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        const found = findAnywhere(selector, node.shadowRoot);
        if (found) return found;
      }
    }
    return null;
  }
  function findAnywhereAll(selector, root = document) {
    const elements = [];
    const seen = /* @__PURE__ */ new Set();
    const pushUnique = (items) => {
      for (const item of items) {
        if (!seen.has(item)) {
          seen.add(item);
          elements.push(item);
        }
      }
    };
    if (Array.isArray(selector)) {
      for (const s of selector) {
        pushUnique(findAnywhereAll(s, root));
      }
      return elements;
    }
    pushUnique(Array.from(root.querySelectorAll(selector)));
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          pushUnique(findAnywhereAll(selector, doc));
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        pushUnique(findAnywhereAll(selector, node.shadowRoot));
      }
    }
    return elements;
  }

  // extension/content/geminiWorld.ts
  var GEMINI_RESPONSE_SELECTORS = ["model-response"];
  var MAZA_BUTTON_CLASS = "maza-gemini-scrap-btn";
  var MAZA_DONE_ATTR = "data-maza-injected";
  async function getResponseTextFromContainer(container) {
    let text = (container.textContent || "").trim();
    const images = findAnywhereAll("img", container);
    const validImages = images.filter((img) => {
      const src = img.src || "";
      return src && !src.includes("avatar") && !src.includes("favicon") && !src.includes("data:image/svg+xml") && !src.startsWith("chrome-extension://");
    });
    if (validImages.length > 0) {
      text += "\n\n---\n**\uCCA8\uBD80\uB41C \uC774\uBBF8\uC9C0:**\n";
      for (let idx = 0; idx < validImages.length; idx++) {
        const img = validImages[idx];
        let finalSrc = img.src;
        try {
          if (finalSrc.startsWith("blob:") || finalSrc.startsWith("http")) {
            const res = await fetch(finalSrc);
            const blob = await res.blob();
            finalSrc = await new Promise((resolve) => {
              const reader = new FileReader();
              reader.onloadend = () => resolve(reader.result);
              reader.onerror = () => resolve(img.src);
              reader.readAsDataURL(blob);
            });
          }
        } catch (err) {
          console.warn("MAZA: \uC774\uBBF8\uC9C0 Base64 \uBCC0\uD658 \uC2E4\uD328", err);
        }
        text += `
![\uC81C\uBBF8\uB098\uC774 \uC0DD\uC131 \uC774\uBBF8\uC9C0 ${idx + 1}](${finalSrc})
`;
      }
    }
    return text;
  }
  function createMazaButton(responseContainer, sourceUrl) {
    const btn = document.createElement("button");
    btn.className = MAZA_BUTTON_CLASS;
    btn.setAttribute("title", "MAZA \uC544\uC774\uB514\uC5B4 \uAE08\uACE0\uC5D0 \uC800\uC7A5");
    btn.innerHTML = `
    <img src="${chrome.runtime.getURL("icons/icon16.png")}" 
         style="width:14px;height:14px;vertical-align:middle;margin-right:5px;" />
    <span>MAZA \uC800\uC7A5</span>
  `;
    btn.style.cssText = `
    display: inline-flex;
    align-items: center;
    gap: 4px;
    margin: 6px 4px 0 0;
    padding: 5px 12px;
    background: linear-gradient(135deg, #4F46E5, #7C3AED);
    color: #fff;
    border: none;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 800;
    cursor: pointer;
    letter-spacing: 0.05em;
    box-shadow: 0 2px 8px rgba(79,70,229,0.3);
    transition: all 0.2s ease;
    z-index: 9999;
  `;
    btn.addEventListener("mouseenter", () => {
      btn.style.transform = "translateY(-1px)";
      btn.style.boxShadow = "0 4px 16px rgba(79,70,229,0.4)";
    });
    btn.addEventListener("mouseleave", () => {
      btn.style.transform = "translateY(0)";
      btn.style.boxShadow = "0 2px 8px rgba(79,70,229,0.3)";
    });
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      btn.innerHTML = "\u23F3 \uC774\uBBF8\uC9C0 \uBCC0\uD658 \uC911...";
      btn.style.opacity = "0.7";
      btn.style.cursor = "not-allowed";
      const content = await getResponseTextFromContainer(responseContainer);
      if (!content) {
        btn.innerHTML = "\u26A0\uFE0F \uB0B4\uC6A9 \uC5C6\uC74C";
        setTimeout(() => {
          btn.innerHTML = "<span>MAZA \uC800\uC7A5</span>";
        }, 2e3);
        return;
      }
      btn.innerHTML = "\u23F3 \uC800\uC7A5 \uC911...";
      btn.style.opacity = "0.7";
      btn.style.cursor = "not-allowed";
      try {
        const response = await chrome.runtime.sendMessage({
          type: "MAZA_SCRAP_IDEA",
          payload: {
            content,
            source_url: sourceUrl,
            source_title: document.title || "Gemini"
          }
        }).catch(() => null);
        if (response?.ok) {
          btn.innerHTML = "\u2705 \uAE08\uACE0\uC5D0 \uC800\uC7A5\uB428!";
          btn.style.background = "linear-gradient(135deg, #059669, #10B981)";
          setTimeout(() => {
            btn.innerHTML = "<span>MAZA \uC800\uC7A5</span>";
            btn.style.background = "linear-gradient(135deg, #4F46E5, #7C3AED)";
            btn.style.opacity = "1";
            btn.style.cursor = "pointer";
          }, 2500);
        } else {
          btn.innerHTML = "\u274C \uC2E4\uD328 (\uB85C\uADF8\uC778 \uD655\uC778)";
          setTimeout(() => {
            btn.innerHTML = "<span>MAZA \uC800\uC7A5</span>";
            btn.style.opacity = "1";
            btn.style.cursor = "pointer";
          }, 2500);
        }
      } catch {
        btn.innerHTML = "\u274C \uC624\uB958 \uBC1C\uC0DD";
        setTimeout(() => {
          btn.innerHTML = "<span>MAZA \uC800\uC7A5</span>";
          btn.style.opacity = "1";
          btn.style.cursor = "pointer";
        }, 2500);
      }
    });
    return btn;
  }
  function injectButtons() {
    const responseContainers = findAnywhereAll(GEMINI_RESPONSE_SELECTORS);
    responseContainers.forEach((container) => {
      if (container.getAttribute(MAZA_DONE_ATTR)) return;
      let ancestor = container.parentElement;
      while (ancestor) {
        if (ancestor.getAttribute(MAZA_DONE_ATTR)) return;
        ancestor = ancestor.parentElement;
      }
      if (findAnywhere(`.${MAZA_BUTTON_CLASS}`, container)) return;
      container.setAttribute(MAZA_DONE_ATTR, "true");
      const btnWrap = document.createElement("div");
      btnWrap.style.cssText = "display:flex;align-items:center;flex-wrap:wrap;margin-top:6px;padding:4px 0;";
      const btn = createMazaButton(container, window.location.href);
      btnWrap.appendChild(btn);
      container.appendChild(btnWrap);
    });
  }
  var observer = new MutationObserver(() => {
    injectButtons();
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  injectButtons();
})();
//# sourceMappingURL=geminiWorld.js.map
