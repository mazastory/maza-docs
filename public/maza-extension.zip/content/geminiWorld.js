"use strict";
(() => {
  // extension/content/geminiWorld.ts
  var MAZA_BUTTON_CLASS = "maza-gemini-scrap-btn";
  var MAZA_DONE_ATTR = "data-maza-injected";
  function getResponseTextFromContainer(container) {
    return (container.textContent || "").trim().substring(0, 1e4);
  }
  function createMazaButton(responseContainer, sourceUrl) {
    const btn = document.createElement("button");
    btn.className = MAZA_BUTTON_CLASS;
    btn.setAttribute("title", "MAZA \uC544\uC774\uB514\uC5B4 \uAE08\uACE0\uC5D0 \uC800\uC7A5");
    btn.innerHTML = `
    <img src="${chrome.runtime.getURL("icons/icon16.png")}" 
         style="width:14px;height:14px;vertical-align:middle;margin-right:5px;" />
    <span>MAZA \uC800\uC7A5</span>
  `;
    btn.style.cssText = `
    display: inline-flex;
    align-items: center;
    gap: 4px;
    margin: 6px 4px 0 0;
    padding: 5px 12px;
    background: linear-gradient(135deg, #4F46E5, #7C3AED);
    color: #fff;
    border: none;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 800;
    cursor: pointer;
    letter-spacing: 0.05em;
    box-shadow: 0 2px 8px rgba(79,70,229,0.3);
    transition: all 0.2s ease;
    z-index: 9999;
  `;
    btn.addEventListener("mouseenter", () => {
      btn.style.transform = "translateY(-1px)";
      btn.style.boxShadow = "0 4px 16px rgba(79,70,229,0.4)";
    });
    btn.addEventListener("mouseleave", () => {
      btn.style.transform = "translateY(0)";
      btn.style.boxShadow = "0 2px 8px rgba(79,70,229,0.3)";
    });
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const content = getResponseTextFromContainer(responseContainer);
      if (!content) {
        btn.innerHTML = "\u26A0\uFE0F \uB0B4\uC6A9 \uC5C6\uC74C";
        setTimeout(() => {
          btn.innerHTML = "<span>MAZA \uC800\uC7A5</span>";
        }, 2e3);
        return;
      }
      btn.innerHTML = "\u23F3 \uC800\uC7A5 \uC911...";
      btn.style.opacity = "0.7";
      btn.style.cursor = "not-allowed";
      try {
        const response = await chrome.runtime.sendMessage({
          type: "MAZA_SCRAP_IDEA",
          payload: {
            content,
            source_url: sourceUrl,
            source_title: document.title || "Gemini"
          }
        });
        if (response?.ok) {
          btn.innerHTML = "\u2705 \uAE08\uACE0\uC5D0 \uC800\uC7A5\uB428!";
          btn.style.background = "linear-gradient(135deg, #059669, #10B981)";
          setTimeout(() => {
            btn.innerHTML = "<span>MAZA \uC800\uC7A5</span>";
            btn.style.background = "linear-gradient(135deg, #4F46E5, #7C3AED)";
            btn.style.opacity = "1";
            btn.style.cursor = "pointer";
          }, 2500);
        } else {
          btn.innerHTML = "\u274C \uC2E4\uD328 (\uB85C\uADF8\uC778 \uD655\uC778)";
          setTimeout(() => {
            btn.innerHTML = "<span>MAZA \uC800\uC7A5</span>";
            btn.style.opacity = "1";
            btn.style.cursor = "pointer";
          }, 2500);
        }
      } catch {
        btn.innerHTML = "\u274C \uC624\uB958 \uBC1C\uC0DD";
        setTimeout(() => {
          btn.innerHTML = "<span>MAZA \uC800\uC7A5</span>";
          btn.style.opacity = "1";
          btn.style.cursor = "pointer";
        }, 2500);
      }
    });
    return btn;
  }
  function injectButtons() {
    const responseContainers = document.querySelectorAll(
      "model-response, .response-container, [data-response-index], .markdown.markdown-main-panel"
    );
    responseContainers.forEach((container) => {
      if (container.getAttribute(MAZA_DONE_ATTR)) return;
      container.setAttribute(MAZA_DONE_ATTR, "true");
      const btnWrap = document.createElement("div");
      btnWrap.style.cssText = "display:flex;align-items:center;flex-wrap:wrap;margin-top:6px;padding:4px 0;";
      const btn = createMazaButton(container, window.location.href);
      btnWrap.appendChild(btn);
      container.appendChild(btnWrap);
    });
  }
  var observer = new MutationObserver(() => {
    injectButtons();
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  injectButtons();
})();
//# sourceMappingURL=geminiWorld.js.map
