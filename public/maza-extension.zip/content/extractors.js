// @ts-nocheck
/**
 * Maza Bridge v3 — content/extractors.js
 * 페이지에서 데이터를 추출하는 유틸리티
 */
'use strict';
window.MAZA_EXTRACT = {
    /**
     * GA4 스크립트 감지
     */
    hasGA4() {
        const scripts = Array.from(document.querySelectorAll('script[src]'));
        return scripts.some(s => s.src.includes('googletagmanager.com/gtag'));
    },
    /**
     * AdSense 코드 감지
     */
    hasAdSense() {
        const scripts = Array.from(document.querySelectorAll('script'));
        return scripts.some(s => (s.src && s.src.includes('pagead2.googlesyndication.com')) ||
            (s.textContent && s.textContent.includes('adsbygoogle')));
    },
    /**
     * Google Search Console 메타 태그 감지
     */
    hasGSC() {
        const meta = document.querySelector('meta[name="google-site-verification"]');
        return !!meta;
    },
    /**
     * 현재 페이지의 SEO 현황 스냅샷
     */
    seoSnapshot() {
        return {
            hasGA4: this.hasGA4(),
            hasAdSense: this.hasAdSense(),
            hasGSC: this.hasGSC(),
            metaDesc: document.querySelector('meta[name="description"]')?.content || null,
            canonical: document.querySelector('link[rel="canonical"]')?.href || null,
            h1Count: document.querySelectorAll('h1').length,
        };
    },
};
//# sourceMappingURL=extractors.js.map