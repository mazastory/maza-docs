"use strict";
(() => {
  // extension/content/sync_token.ts
  console.log("[MAZA OS] Sync Token Script Active.");
  console.log("[MAZA OS] Extension presence initialized.");
  window.__MAZA_EXTENSION_INSTALLED__ = true;
  var MAZA_VERSION = typeof chrome !== "undefined" && chrome.runtime?.getManifest ? chrome.runtime.getManifest().version : "1.0.0";
  window.__MAZA_EXTENSION_VERSION__ = MAZA_VERSION;
  function isContextValid() {
    return typeof chrome !== "undefined" && !!chrome.runtime && !!chrome.runtime.id;
  }
  var TRUSTED_ORIGINS = [
    "http://localhost:5173",
    "http://localhost:5174",
    "http://localhost:5175",
    "https://mazastudio.kr"
  ];
  var lastSyncedSiteList = null;
  window.addEventListener("message", (event) => {
    if (!isContextValid()) return;
    if (event.data && (event.data.type === "MAZA_PING" || event.data.type === "MAZA_PING_REQUEST")) {
      window.postMessage({ type: "MAZA_PONG_EXTENSION", version: MAZA_VERSION, source: "MAZA_EXTENSION" }, "*");
    }
    if (event.data && (event.data.type === "MAZA_PUBLISH_POST" || event.data.type === "MAZA_INFRA_INJECT" || event.data.type === "MAZA_SYNC_SITE" || event.data.type === "MAZA_AUTOPILOT_SYNC" || event.data.type === "MAZA_FORCE_POLLING")) {
      if (!TRUSTED_ORIGINS.includes(event.origin)) {
        console.warn(`[MAZA OS] Blocked message from untrusted origin: ${event.origin}`);
        return;
      }
      if (event.data.type === "MAZA_SYNC_SITE") {
        const siteList = event.data.allSites || [];
        const siteListJson = JSON.stringify(siteList);
        if (siteListJson === lastSyncedSiteList) {
          return;
        }
        lastSyncedSiteList = siteListJson;
        console.log(`[MAZA OS] Syncing site list from WebApp. count=${siteList.length}`);
        try {
          chrome.storage.local.set({
            mazaSites: siteList
          });
        } catch (e) {
          console.debug("[MAZA OS] Expected exception caught:", e);
        }
        return;
      }
      if (event.data.type === "MAZA_AUTOPILOT_SYNC") {
        try {
          chrome.runtime.sendMessage(event.data);
        } catch (e) {
          console.debug("[MAZA OS] Expected exception caught:", e);
        }
        return;
      }
      if (event.data.type === "MAZA_FORCE_POLLING") {
        console.log("[MAZA OS] Relaying Force Polling command to background.");
        try {
          chrome.runtime.sendMessage({ type: "FORCE_POLLING" });
        } catch (e) {
          console.debug("[MAZA OS] Expected exception caught:", e);
        }
        return;
      }
      console.log(`%c[MAZA OS] Relaying immediate action: ${event.data.type}`, "color: #10b981; font-weight: bold;");
      try {
        chrome.runtime.sendMessage({
          type: "IMMEDIATE_ACTION",
          actionType: event.data.type,
          payload: event.data.payload
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.error("[MAZA OS] Relay failed:", chrome.runtime.lastError.message);
          } else {
            console.log("[MAZA OS] Relay success acknowledged by background.");
          }
        });
      } catch (e) {
        console.warn("[MAZA OS] Extension context invalidated. Please refresh the page.");
      }
    }
  });
  function broadcastPresence() {
    if (!isContextValid()) return;
    window.postMessage({ type: "MAZA_PONG_EXTENSION", version: MAZA_VERSION, source: "MAZA_EXTENSION" }, "*");
  }
  var presenceInterval = setInterval(() => {
    if (!isContextValid()) {
      clearInterval(presenceInterval);
      return;
    }
    broadcastPresence();
  }, 5e3);
  if (isContextValid()) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.type === "MAZA_INFRA_PROGRESS" || msg.type === "MAZA_INFRA_INJECTED") {
        window.postMessage(msg, "*");
      }
    });
  }
  function extractSupabaseSession() {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith("sb-") && key.endsWith("-auth-token")) {
        try {
          const value = localStorage.getItem(key);
          if (value) {
            const parsed = JSON.parse(value);
            return {
              token: parsed.access_token || null,
              email: parsed.user?.email || null
            };
          }
        } catch (e) {
          console.debug("[MAZA OS] Expected exception caught:", e);
        }
      }
    }
    return { token: null, email: null };
  }
  var lastToken = null;
  var isCheckingToken = false;
  function checkAndSyncToken() {
    if (!isContextValid()) return;
    if (isCheckingToken) return;
    isCheckingToken = true;
    try {
      const { token, email } = extractSupabaseSession();
      if (token && token !== lastToken) {
        lastToken = token;
        try {
          chrome.storage.local.set({
            mazaToken: token,
            mazaUserEmail: email,
            mazaOrigin: window.location.origin
          }, () => {
            console.log("[MAZA OS] Token, Email and Origin successfully synced to Extension storage.");
            chrome.runtime.sendMessage({ type: "TOKEN_UPDATED" }).catch(() => {
            });
          });
        } catch (e) {
          console.debug("[MAZA OS] Expected exception caught:", e);
        }
      } else if (!token && lastToken) {
        lastToken = null;
        try {
          chrome.storage.local.remove(["mazaToken", "mazaUserEmail"], () => {
            console.log("[MAZA OS] Auth data removed from Extension storage.");
          });
        } catch (e) {
          console.debug("[MAZA OS] Expected exception caught:", e);
        }
      }
    } finally {
      isCheckingToken = false;
    }
  }
  var syncInterval = setInterval(() => {
    if (!isContextValid()) {
      clearInterval(syncInterval);
      return;
    }
    checkAndSyncToken();
  }, 5e3);
  checkAndSyncToken();
})();
//# sourceMappingURL=sync_token.js.map
