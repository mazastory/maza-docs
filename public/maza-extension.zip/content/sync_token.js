"use strict";
(() => {
  // extension/content/sync_token.ts
  function isAuthRedirectPage() {
    const hostname = window.location.hostname;
    const blockedHosts = [
      "accounts.kakao.com",
      "kauth.kakao.com",
      "kakao.com"
    ];
    return blockedHosts.some((host) => hostname === host || hostname.endsWith(`.${host}`));
  }
  if (isAuthRedirectPage()) {
    console.debug("[MAZA OS] Skipping sync_token on OAuth page:", window.location.hostname);
  } else {
    let isContextValid = function() {
      return typeof chrome !== "undefined" && !!chrome.runtime && !!chrome.runtime.id;
    }, isLocalDevOrigin = function(origin) {
      try {
        const url = new URL(origin);
        return (url.hostname === "localhost" || url.hostname === "127.0.0.1" || url.hostname === "[::1]") && (url.protocol === "http:" || url.protocol === "https:");
      } catch {
        return false;
      }
    }, isTrustedOrigin = function(origin) {
      if (isLocalDevOrigin(origin)) return true;
      try {
        const url = new URL(origin);
        return url.hostname === "mazastudio.kr" || url.hostname.endsWith(".mazastudio.kr");
      } catch {
        return false;
      }
    }, broadcastPresence = function() {
      if (!isContextValid()) return;
      window.postMessage({ type: "MAZA_PONG_EXTENSION", version: MAZA_VERSION, source: "MAZA_EXTENSION" }, "*");
    }, extractSupabaseSession = function() {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith("sb-") && key.endsWith("-auth-token")) {
          try {
            const value = localStorage.getItem(key);
            if (value) {
              const parsed = JSON.parse(value);
              return {
                token: parsed.access_token || null,
                email: parsed.user?.email || null
              };
            }
          } catch (e) {
            console.debug("[MAZA OS] Expected exception caught:", e);
          }
        }
      }
      return { token: null, email: null };
    }, sendTokenUpdatedMessage = function() {
      try {
        chrome.runtime.sendMessage({ type: "TOKEN_UPDATED" });
      } catch {
      }
    }, syncAuthToExtensionStorage = function(token, email, origin) {
      try {
        const payload = {
          mazaToken: token,
          mazaUserEmail: email,
          mazaOrigin: origin
        };
        if (token) payload.lastSignedInAt = Date.now();
        chrome.storage.local.set(payload, () => {
          console.log("[MAZA OS] Auth storage updated.", { token: !!token, email, origin });
          sendTokenUpdatedMessage();
        });
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
    }, clearAuthStorage = function() {
      try {
        chrome.storage.local.remove(["mazaToken", "mazaUserEmail", "mazaOrigin"], () => {
          console.log("[MAZA OS] Auth data removed from Extension storage.");
          sendTokenUpdatedMessage();
        });
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
    }, checkAndSyncToken = function() {
      if (!isContextValid()) return;
      if (isCheckingToken) return;
      isCheckingToken = true;
      try {
        const { token, email } = extractSupabaseSession();
        const origin = window.location.origin;
        if (token && (token !== lastToken || email !== lastEmail || origin !== lastOrigin)) {
          lastToken = token;
          lastEmail = email;
          lastOrigin = origin;
          syncAuthToExtensionStorage(token, email, origin);
        } else if (!token && lastToken) {
          lastToken = null;
          lastEmail = null;
          lastOrigin = null;
          clearAuthStorage();
        }
      } finally {
        isCheckingToken = false;
      }
    };
    isContextValid2 = isContextValid, isLocalDevOrigin2 = isLocalDevOrigin, isTrustedOrigin2 = isTrustedOrigin, broadcastPresence2 = broadcastPresence, extractSupabaseSession2 = extractSupabaseSession, sendTokenUpdatedMessage2 = sendTokenUpdatedMessage, syncAuthToExtensionStorage2 = syncAuthToExtensionStorage, clearAuthStorage2 = clearAuthStorage, checkAndSyncToken2 = checkAndSyncToken;
    console.log("[MAZA OS] Sync Token Script Active.");
    console.log("[MAZA OS] Extension presence initialized.");
    window.__MAZA_EXTENSION_INSTALLED__ = true;
    const MAZA_VERSION = typeof chrome !== "undefined" && chrome.runtime?.getManifest ? chrome.runtime.getManifest().version : "1.0.0";
    window.__MAZA_EXTENSION_VERSION__ = MAZA_VERSION;
    let lastSyncedSiteList = null;
    let lastSyncedToken = null;
    window.addEventListener("message", (event) => {
      if (!isContextValid()) {
        if (event.data?.type === "MAZA_PUBLISH_POST") {
          window.postMessage({ type: "MAZA_PUBLISH_RESULT", ok: false, error: "\uC775\uC2A4\uD150\uC158 \uC5F0\uACB0\uC774 \uB04A\uC5B4\uC84C\uC2B5\uB2C8\uB2E4(\uC5C5\uB370\uC774\uD2B8 \uB4F1). \uD398\uC774\uC9C0\uB97C \uC0C8\uB85C\uACE0\uCE68(F5) \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694." }, "*");
        }
        return;
      }
      if (event.data && (event.data.type === "MAZA_PING" || event.data.type === "MAZA_PING_REQUEST")) {
        console.log("[MAZA OS DEBUG] Received PING in first listener, sending PONG...");
        window.postMessage({ type: "MAZA_PONG_EXTENSION", version: MAZA_VERSION, source: "MAZA_EXTENSION" }, "*");
        return;
      }
      if (event.data && (event.data.type === "MAZA_PUBLISH_POST" || event.data.type === "MAZA_INFRA_INJECT" || event.data.type === "MAZA_SYNC_SITE" || event.data.type === "MAZA_AUTOPILOT_SYNC" || event.data.type === "MAZA_FORCE_POLLING" || event.data.type === "MAZA_SYNC_AUTH")) {
        if (!isTrustedOrigin(event.origin)) {
          console.warn(`[MAZA OS] Blocked message from untrusted origin: ${event.origin}`);
          return;
        }
        if (event.data.type === "MAZA_SYNC_AUTH") {
          const token = event.data.token;
          if (token) {
            if (token === lastSyncedToken) {
              console.debug("[MAZA OS] sync_token: skipping duplicate token (no change)");
              return;
            }
            lastSyncedToken = token;
            console.log(`[MAZA OS] Syncing auth token from WebApp.`);
            try {
              let origin = window.location.origin;
              if (origin.includes("docs.mazastudio.kr")) {
                origin = "https://mazastudio.kr";
              }
              chrome.runtime.sendMessage({
                type: "MAZA_SYNC_TOKEN",
                payload: {
                  token,
                  origin
                }
              });
            } catch (e) {
              console.debug("[MAZA OS] Expected exception caught:", e);
            }
          }
          return;
        }
        if (event.data.type === "MAZA_SYNC_SITE") {
          const siteList = event.data.allSites || [];
          const siteListJson = JSON.stringify(siteList);
          if (siteListJson === lastSyncedSiteList) {
            return;
          }
          lastSyncedSiteList = siteListJson;
          console.log(`[MAZA OS] Syncing site list from WebApp. count=${siteList.length}`);
          try {
            chrome.storage.local.set({
              mazaSites: siteList
            });
          } catch (e) {
            console.debug("[MAZA OS] Expected exception caught:", e);
          }
          return;
        }
        if (event.data.type === "MAZA_AUTOPILOT_SYNC") {
          try {
            chrome.runtime.sendMessage(event.data);
          } catch (e) {
            console.debug("[MAZA OS] Expected exception caught:", e);
          }
          return;
        }
        if (event.data.type === "MAZA_FORCE_POLLING") {
          console.log("[MAZA OS] Relaying Force Polling command to background.");
          try {
            chrome.runtime.sendMessage({ type: "FORCE_POLLING" }, (response) => {
              if (chrome.runtime.lastError) {
                console.error("[MAZA OS] Force Polling relay failed:", chrome.runtime.lastError.message);
                return;
              }
              console.log("[MAZA OS] Force Polling acknowledged by background.", response);
            });
          } catch (e) {
            console.debug("[MAZA OS] Expected exception caught:", e);
          }
          return;
        }
        console.log(`%c[MAZA OS] Relaying immediate action: ${event.data.type}`, "color: #10b981; font-weight: bold;");
        try {
          chrome.runtime.sendMessage({
            type: "IMMEDIATE_ACTION",
            actionType: event.data.type,
            payload: event.data.payload
          }, (response) => {
            if (chrome.runtime.lastError) {
              console.error("[MAZA OS] Relay failed:", chrome.runtime.lastError.message);
              if (event.data.type === "MAZA_PUBLISH_POST") {
                window.postMessage({ type: "MAZA_PUBLISH_RESULT", ok: false, error: "\uC775\uC2A4\uD150\uC158 \uC804\uB2EC \uC2E4\uD328: " + chrome.runtime.lastError.message + " (\uD398\uC774\uC9C0\uB97C \uC0C8\uB85C\uACE0\uCE68\uD574 \uBCF4\uC138\uC694)" }, "*");
              }
            } else {
              console.log("[MAZA OS] Relay success acknowledged by background.");
            }
          });
        } catch (e) {
          console.warn("[MAZA OS] Extension context invalidated. Please refresh the page.");
          if (event.data.type === "MAZA_PUBLISH_POST") {
            window.postMessage({ type: "MAZA_PUBLISH_RESULT", ok: false, error: "\uC775\uC2A4\uD150\uC158 \uCEE8\uD14D\uC2A4\uD2B8\uAC00 \uB9CC\uB8CC\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uD398\uC774\uC9C0\uB97C \uC0C8\uB85C\uACE0\uCE68(F5) \uD574\uC8FC\uC138\uC694." }, "*");
          }
        }
      }
    });
    const presenceInterval = setInterval(() => {
      if (!isContextValid()) return;
      broadcastPresence();
    }, 2e3);
    if (isContextValid()) {
      chrome.runtime.onMessage.addListener((msg) => {
        if (msg.type === "MAZA_INFRA_PROGRESS" || msg.type === "MAZA_INFRA_INJECTED" || msg.type === "MAZA_PUBLISH_RESULT" || msg.type === "TASK_LOG") {
          console.log("[MAZA OS] sync_token relaying message to web app", msg.type, msg.step || "");
          window.postMessage(msg, "*");
        }
        if (msg.type === "MAZA_CONTEXT") {
          window.postMessage({
            type: "MAZA_CONTEXT",
            contextType: msg.contextType,
            data: msg.data
          }, "*");
        }
      });
    }
    window.addEventListener("message", (event) => {
      if (!isTrustedOrigin(event.origin)) return;
      const { type, payload } = event.data || {};
      if (type === "MAZA_PING" || type === "MAZA_PING_REQUEST") {
        if (isContextValid()) {
          window.postMessage({ type: "MAZA_PONG_EXTENSION", version: MAZA_VERSION, source: "MAZA_EXTENSION" }, "*");
        }
        return;
      }
      if (!isContextValid()) return;
      if (type === "MAZA_SYNC_AUTH") {
        return;
      }
      if (type === "MAZA_SAVE_TO_VAULT") {
        chrome.runtime.sendMessage({
          type: "MAZA_SCRAP_IDEA",
          payload: {
            content: payload?.text || payload?.title || "",
            source_url: payload?.url || "",
            source_title: payload?.title || "Captured",
            image_url: payload?.imageUrl || ""
          }
        }).catch(() => {
        });
        return;
      }
      if (type === "MAZA_SET_THUMBNAIL") {
        chrome.runtime.sendMessage({
          type: "MAZA_SET_THUMBNAIL",
          payload: { imageUrl: payload?.imageUrl || "" }
        }).catch(() => {
        });
        return;
      }
      if (type === "MAZA_REQUEST_SITES") {
        chrome.storage.local.get(["mazaSites"]).then((storage) => {
          window.postMessage({ type: "MAZA_SITES_RESPONSE", sites: storage.mazaSites || [] }, "*");
        }).catch(() => {
          window.postMessage({ type: "MAZA_SITES_RESPONSE", sites: [] }, "*");
        });
        return;
      }
    });
    let lastToken = null;
    let lastEmail = null;
    let lastOrigin = null;
    let isCheckingToken = false;
    const syncInterval = setInterval(() => {
      if (!isContextValid()) {
        clearInterval(syncInterval);
        return;
      }
      checkAndSyncToken();
    }, 5e3);
    checkAndSyncToken();
  }
  var isContextValid2;
  var isLocalDevOrigin2;
  var isTrustedOrigin2;
  var broadcastPresence2;
  var extractSupabaseSession2;
  var sendTokenUpdatedMessage2;
  var syncAuthToExtensionStorage2;
  var clearAuthStorage2;
  var checkAndSyncToken2;
})();
//# sourceMappingURL=sync_token.js.map
