import { SemanticFinder } from './semanticFinder.js';
/**
 * Maza Bridge v4 — content/domActions.ts
 * DOM Manipulation Library with Semantic Intelligence
 */
// ── 플랫폼별 셀렉터 ─────────────────────────────────────
/**
 * 100점 구조: Shadow DOM 및 Iframe 내부까지 탐색하는 'All-Seeing' 쿼리 셀렉터
 */
function findAnywhere(selector, root = document) {
    // 1. 기본 검색
    let el = root.querySelector(selector);
    if (el)
        return el;
    // 2. Iframe 내부 검색 (동일 도메인 한정)
    const iframes = root.querySelectorAll('iframe');
    for (const iframe of iframes) {
        try {
            const doc = iframe.contentDocument || (iframe.contentWindow ? iframe.contentWindow.document : null);
            if (doc) {
                el = findAnywhere(selector, doc);
                if (el)
                    return el;
            }
        }
        catch (e) {
            // Cross-origin iframe은 접근 불가
        }
    }
    // 3. Shadow DOM 내부 재귀 검색
    const all = root.querySelectorAll('*');
    for (const node of all) {
        if (node.shadowRoot) {
            el = findAnywhere(selector, node.shadowRoot);
            if (el)
                return el;
        }
    }
    return null;
}
/**
 * Shadow DOM 및 Iframe 내부까지 탐색하여 모든 매칭 요소를 반환
 */
function findAnywhereAll(selector, root = document) {
    let results = Array.from(root.querySelectorAll(selector));
    // Iframe 내부
    const iframes = root.querySelectorAll('iframe');
    for (const iframe of iframes) {
        try {
            const doc = iframe.contentDocument || (iframe.contentWindow ? iframe.contentWindow.document : null);
            if (doc) {
                results = results.concat(findAnywhereAll(selector, doc));
            }
        }
        catch (e) { }
    }
    // Shadow DOM 내부
    const all = root.querySelectorAll('*');
    for (const node of all) {
        if (node.shadowRoot) {
            results = results.concat(findAnywhereAll(selector, node.shadowRoot));
        }
    }
    return results;
}
const PLATFORM_SELECTORS = {
    tistory: {
        title: 'input.tf_g, input[name="title"]',
        editor: [
            '.ProseMirror[contenteditable="true"]',
            '.content_editable',
            '.ke-editable',
            '.ke-content',
            '#editor-content',
            '[contenteditable="true"]'
        ].join(','),
        iframe: '#editor-content-iframe',
        publish: 'button[data-testid="btn-publish"], .btn_publish, button.publish',
    },
    wordpress: {
        title: '#post-title-0, #title, .editor-post-title__input',
        editor: '.wp-block-post-content[contenteditable], #content_ifr',
        publish: '.editor-post-publish-button, #publish',
    },
    blogger: {
        title: 'input[name="postTitle"]',
        editor: '.editable[contenteditable="true"]',
        publish: 'button[id="publish"]',
    },
};
function detectPlatform() {
    const host = window.location.hostname;
    if (host.includes('tistory.com'))
        return 'tistory';
    if (host.includes('wordpress.com') || host.includes('wp-admin'))
        return 'wordpress';
    if (host.includes('blogger.com') || host.includes('blogspot.com'))
        return 'blogger';
    return 'unknown';
}
function getSelectors(overrides = {}) {
    const defaults = PLATFORM_SELECTORS[detectPlatform()] || PLATFORM_SELECTORS.tistory;
    // 100점 구조: 서버에서 내려준 동적 셀렉터가 있으면 우선 적용
    return { ...defaults, ...overrides };
}
async function waitFor(selectorOrFn, timeout = 8000) {
    return new Promise((resolve, reject) => {
        const start = Date.now();
        const check = () => {
            let el = null;
            if (typeof selectorOrFn === 'function') {
                el = selectorOrFn();
            }
            else {
                el = findAnywhere(selectorOrFn);
                // Semantic Fallback if selector fails after half timeout
                if (!el && Date.now() - start > timeout / 2) {
                    if (selectorOrFn.includes('title'))
                        el = SemanticFinder.smartFind('title') || SemanticFinder.smartFind('제목');
                    if (selectorOrFn.includes('publish'))
                        el = SemanticFinder.findButtonByText('발행') || SemanticFinder.findButtonByText('Publish');
                    if (selectorOrFn.includes('editor'))
                        el = SemanticFinder.findEditor();
                }
            }
            if (el)
                return resolve(el);
            if (Date.now() - start > timeout) {
                console.warn(`[Maza Bridge] Timeout for selector: ${selectorOrFn}. Requesting HEAL...`);
                chrome.runtime.sendMessage({
                    type: 'HEAL_REQUEST',
                    selector: typeof selectorOrFn === 'string' ? selectorOrFn : 'function',
                    snapshot: takeSnapshotDOM()
                }).catch(() => { });
                return reject(new Error(`Timeout: ${selectorOrFn}`));
            }
            setTimeout(check, 300);
        };
        check();
    });
}
function takeSnapshotDOM() {
    // Simplified DOM representation for AI to analyze (removes huge scripts/styles)
    const clone = document.documentElement.cloneNode(true);
    const scripts = clone.querySelectorAll('script, style, svg, path');
    scripts.forEach(s => s.remove());
    return clone.innerHTML;
}
function dispatch(el, ...eventNames) {
    eventNames.forEach(name => el.dispatchEvent(new Event(name, { bubbles: true })));
}
// ── 액션 구현 ────────────────────────────────────────────
async function inputTitle(data) {
    const S = getSelectors(data.selectors);
    const title = data.title || data.subject || '';
    console.log('[Maza] Injecting title:', title.substring(0, 20));
    let el = null;
    try {
        el = await waitFor(S.title);
    }
    catch (err) {
        console.log('[Maza] CSS Title find failed, trying Semantic...');
        el = SemanticFinder.smartFind('title') || SemanticFinder.smartFind('제목');
    }
    if (!el)
        throw new Error('Title field not found');
    console.log('[Maza] Found title element:', el.tagName, el.className, el.id);
    el.focus();
    let success = false;
    try {
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.getAttribute('contenteditable') === 'true') {
            el.select && el.select();
            success = document.execCommand('insertText', false, title);
        }
    }
    catch (e) {
        console.warn('[Maza] execCommand failed, falling back to direct assignment');
    }
    if (!success) {
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
            el.value = title;
        }
        else {
            el.innerText = title;
        }
    }
    dispatch(el, 'input', 'change', 'blur');
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: title }));
    return { ok: true };
}
async function inputTags(data) {
    const tags = data.tags || data.hashtags || [];
    if (!tags || tags.length === 0)
        return { ok: true, skipped: true };
    const S = getSelectors(data.selectors);
    if (!S.tags)
        return { ok: true, no_selector: true };
    console.log('[Maza] Injecting tags:', tags.length);
    const el = await waitFor(S.tags, 10000).catch(() => null);
    if (!el) {
        console.warn('[Maza] Tag field not found, skipping');
        return { ok: true, not_found: true };
    }
    // Iterative Tag Injection: 하나씩 넣고 콤마를 쳐야 티스토리에서 인식함
    for (const tag of tags) {
        const cleanTag = tag.replace(/^#/, '').trim();
        if (!cleanTag)
            continue;
        if ('value' in el) {
            el.value = cleanTag;
        }
        dispatch(el, 'input', 'change');
        // 콤마(,) 입력 시뮬레이션
        el.dispatchEvent(new KeyboardEvent('keydown', { key: ',', keyCode: 188, bubbles: true }));
        el.dispatchEvent(new KeyboardEvent('keyup', { key: ',', keyCode: 188, bubbles: true }));
        // 잠깐의 대기 후 다음 태그 (티스토리 엔진 처리 시간)
        await new Promise(r => setTimeout(r, 150));
    }
    return { ok: true };
}
/**
 * 에디터 요소에 직접 HTML 주입
 */
async function injectToElement(el, content) {
    el.focus();
    // 100점 구조: 이미지 썸네일 인식률을 높이기 위한 처리
    // Range API를 이용한 정교한 삽입 (에디터 상태 업데이트 유도)
    const doc = el.ownerDocument;
    const range = doc.createRange();
    range.selectNodeContents(el);
    range.deleteContents();
    const fragment = range.createContextualFragment(content);
    el.appendChild(fragment);
    // 썸네일(대표 이미지) 최적화: 첫 번째 이미지에 포커스 및 대표 설정 시도
    setTimeout(() => {
        const firstImg = el.querySelector('img');
        if (firstImg) {
            console.log('[Maza] Attempting to set first image as representative');
            firstImg.click(); // 에디터 툴바 유도
            // 티스토리 특유의 대표 이미지 속성 주입 시도
            firstImg.setAttribute('data-is-representative', 'true');
            firstImg.classList.add('representative');
        }
    }, 500);
    // 이벤트 디스패치
    el.dispatchEvent(new InputEvent('input', {
        bubbles: true,
        inputType: 'insertText'
    }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    // Tistory ProseMirror: 엔터키 시뮬레이션으로 에디터 동기화 강제
    el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true }));
}
async function inputContent(data) {
    const S = getSelectors(data.selectors);
    const platform = detectPlatform();
    let html = data.html || data.body || '';
    const titleText = (data.title || data.subject || '').trim();
    console.log('[Maza] Injecting content, length:', html.length);
    // 100점 구조: 본문 상단의 중복 제목 제거
    if (titleText) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = html;
        const firstHeading = tempDiv.querySelector('h1, h2');
        if (firstHeading) {
            const headingText = firstHeading.textContent?.trim() || '';
            if (titleText.includes(headingText) || headingText.includes(titleText) || (headingText.length > 5 && titleText.startsWith(headingText.substring(0, 5)))) {
                console.log('[Maza] Removing redundant heading:', headingText);
                firstHeading.remove();
                html = tempDiv.innerHTML;
            }
        }
    }
    // 100점 구조: 본문 하단의 태그 뭉치 제거
    const tagList = data.tags || data.hashtags || [];
    if (tagList.length > 0) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = html;
        const paragraphs = Array.from(tempDiv.querySelectorAll('p, div')).reverse();
        for (const p of paragraphs) {
            const text = p.textContent?.trim() || '';
            if (text.startsWith('#') && text.split(/\s+/).every(word => word.startsWith('#'))) {
                console.log('[Maza] Removing redundant tags from body:', text);
                p.remove();
                html = tempDiv.innerHTML;
                break;
            }
        }
    }
    // Tistory: iframe 에디터 우선 시도
    if (platform === 'tistory') {
        const iframe = document.querySelector(S.iframe);
        if (iframe) {
            try {
                const win = iframe.contentWindow;
                const doc = iframe.contentDocument || (win ? win.document : null);
                const body = doc ? doc.body : null;
                if (body) {
                    await injectToElement(body, html);
                    return { ok: true, method: 'iframe' };
                }
            }
            catch { /* fallback */ }
        }
    }
    // 공통: contenteditable 에디터
    let el = null;
    try {
        el = await waitFor(S.editor, 15000);
    }
    catch (err) {
        console.log('[Maza] CSS Editor find failed, trying Semantic...');
        el = SemanticFinder.findEditor();
    }
    if (!el)
        throw new Error('Editor not found');
    await injectToElement(el, html);
    return { ok: true, method: 'contenteditable' };
}
async function clickPublish(data = {}) {
    const S = getSelectors(data.selectors);
    let el = null;
    try {
        el = await waitFor(S.publish, 10000);
    }
    catch (err) {
        console.log('[Maza] CSS Publish find failed, trying Semantic...');
        el = SemanticFinder.findButtonByText('발행') || SemanticFinder.findButtonByText('완료') || SemanticFinder.findButtonByText('Publish');
    }
    if (!el)
        throw new Error('Publish button not found');
    el.click();
    return { ok: true };
}
async function extractHtml() {
    const S = getSelectors();
    const platform = detectPlatform();
    const titleEl = findAnywhere(S.title);
    const editorEl = findAnywhere(S.editor);
    let html = '';
    if (platform === 'tistory') {
        const iframe = findAnywhere(S.iframe);
        if (iframe) {
            try {
                const win = iframe.contentWindow;
                const doc = iframe.contentDocument || (win ? win.document : null);
                const body = doc ? doc.body : null;
                html = body ? body.innerHTML : '';
            }
            catch { }
        }
    }
    if (!html && editorEl) {
        html = editorEl.innerHTML || editorEl.value || '';
    }
    // 가장 내용이 긴 요소를 제목으로 채택 (숨겨진 빈 필드 방지)
    const allTitles = findAnywhereAll(S.title);
    let title = '';
    let bestTitleEl = null;
    allTitles.forEach(el => {
        const val = (el.value || el.innerText || el.textContent || '').trim();
        if (val.length >= title.length) {
            title = val;
            bestTitleEl = el;
        }
    });
    if (bestTitleEl) {
        const tel = bestTitleEl;
        console.log(`[Maza Extract] Using title from: ${tel.tagName}.${tel.className}`, title.substring(0, 20));
    }
    return {
        ok: true,
        html,
        title,
        url: window.location.href,
        documentTitle: document.title,
    };
}
function detectPlatformAction() {
    return {
        ok: true,
        platform: detectPlatform(),
        url: window.location.href,
        title: document.title,
    };
}
async function injectInfra(data) {
    let editor;
    try {
        editor = await waitFor('.CodeMirror, .monaco-editor, #content', 8000);
    }
    catch (err) {
        const htmlBtn = document.querySelector('a[href="#/source/html"]') ||
            Array.from(document.querySelectorAll('button, a, span')).find(b => b.textContent && b.textContent.toLowerCase().includes('html'));
        if (htmlBtn) {
            htmlBtn.click();
            try {
                editor = await waitFor('.CodeMirror, .monaco-editor, #content', 5000);
            }
            catch {
                throw new Error("티스토리 HTML 에디터를 띄울 수 없습니다.");
            }
        }
        else {
            throw new Error("티스토리 HTML 에디터를 찾을 수 없습니다.");
        }
    }
    return new Promise((resolve, reject) => {
        if (document.getElementById('maza-monaco-inject')) {
            triggerInject();
            return;
        }
        const script = document.createElement('script');
        script.id = 'maza-monaco-inject';
        script.src = chrome.runtime.getURL('content/monacoInject.js');
        script.onload = () => {
            triggerInject();
        };
        script.onerror = () => reject(new Error("주입용 스크립트 로드 실패"));
        function triggerInject() {
            document.addEventListener('MAZA_INJECT_SUCCESS', () => {
                chrome.runtime.sendMessage({ type: 'MAZA_INFRA_PROGRESS', step: 'SUCCESS' }).catch(() => { });
                resolve({ ok: true });
            }, { once: true });
            document.addEventListener('MAZA_INJECT_ERROR', (e) => reject(new Error(e.detail)), { once: true });
            document.addEventListener('MAZA_INJECT_PROGRESS', (e) => {
                chrome.runtime.sendMessage({ type: 'MAZA_INFRA_PROGRESS', step: e.detail }).catch(() => { });
            });
            document.dispatchEvent(new CustomEvent('MAZA_INJECT_START', { detail: { html: data.html } }));
        }
        document.head.appendChild(script);
    });
}
async function publishContent(data) {
    await inputTitle(data);
    await inputContent(data);
    await inputTags(data);
    return { ok: true };
}
async function clickDashboardWrite() {
    const platform = detectPlatform();
    if (platform !== 'tistory')
        return { ok: false, message: 'Not Tistory' };
    const selectors = [
        'a[href*="/manage/post/write"]',
        'a.btn_tistory.btn_write',
        'a.link_edit',
        '.sidebar-menu a[href$="/write"]'
    ];
    for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) {
            el.click();
            return { ok: true };
        }
    }
    const links = document.querySelectorAll('a');
    for (const link of links) {
        if (link.textContent.includes('글쓰기')) {
            link.click();
            return { ok: true };
        }
    }
    throw new Error("글쓰기 버튼을 찾을 수 없습니다.");
}
async function verifyContent(data) {
    const { minTitleLength = 2, minBodyLength = 100 } = data;
    const extracted = await extractHtml();
    const titleText = extracted.title || '';
    const bodyText = extracted.html.replace(/<[^>]*>/g, '').trim();
    const titleOk = titleText.length >= minTitleLength;
    const bodyOk = bodyText.length >= minBodyLength;
    console.log(`[Maza Verify] Title: "${titleText}" (${titleText.length}), Body: ${bodyText.length}`);
    if (!titleOk)
        throw new Error(`제목이 너무 짧습니다 (현재: ${titleText.length}자)`);
    if (!bodyOk)
        throw new Error(`본문이 너무 짧거나 주입되지 않았습니다 (현재: ${bodyText.length}자)`);
    return { ok: true, titleLength: titleText.length, bodyLength: bodyText.length };
}
window.MAZA_DOM = {
    async run(action, data) {
        switch (action) {
            case 'PUBLISH_CONTENT_DOM': return publishContent(data);
            case 'INJECT_INFRA_DOM': return injectInfra(data);
            case 'INPUT_TITLE': return inputTitle(data);
            case 'INPUT_CONTENT': return inputContent(data);
            case 'INPUT_TAGS': return inputTags(data);
            case 'CLICK_PUBLISH': return clickPublish(data);
            case 'EXTRACT_HTML': return extractHtml();
            case 'DETECT_PLATFORM': return detectPlatformAction();
            case 'CLICK_DASHBOARD_WRITE': return clickDashboardWrite();
            case 'VERIFY_CONTENT_DOM': return verifyContent(data);
            case 'TAKE_SNAPSHOT_DOM': return { ok: true, html: takeSnapshotDOM() };
            default: throw new Error(`[Maza] Unknown action: ${action}`);
        }
    }
};
//# sourceMappingURL=domActions.js.map