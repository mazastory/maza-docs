"use strict";
(() => {
  // extension/content/mainWorld.ts
  (function() {
    if (window.__MAZA_RUNTIME__) {
      console.log("[MAZA OS Runtime] Singleton active. Skipping re-initialization.");
      return;
    }
    window.__MAZA_RUNTIME__ = true;
    function findAnywhere(selector, root = document) {
      const el = root.querySelector(selector);
      if (el) return el;
      const iframes = root.querySelectorAll("iframe, frame");
      for (const iframe of Array.from(iframes)) {
        try {
          const doc = iframe.contentDocument || iframe.contentWindow?.document;
          if (doc) {
            const found = findAnywhere(selector, doc);
            if (found) return found;
          }
        } catch (e) {
          console.debug("[MAZA OS] Expected exception caught:", e);
        }
      }
      const allElements = root.querySelectorAll("*");
      for (const node of Array.from(allElements)) {
        if (node.shadowRoot) {
          const found = findAnywhere(selector, node.shadowRoot);
          if (found) return found;
        }
      }
      return null;
    }
    const _origConfirm = window.confirm;
    window.confirm = (msg) => {
      if (msg) {
        if (msg.includes("\uC800\uC7A5\uB41C \uAE00\uC774 \uC788\uC2B5\uB2C8\uB2E4") || msg.includes("\uC774\uC5B4\uC11C \uC791\uC131")) {
          console.log("[MAZA OS Runtime] Auto-canceling draft recovery dialog");
          return false;
        }
        if (msg.includes("\uC791\uC131 \uBAA8\uB4DC\uB97C \uBCC0\uACBD") || msg.includes("\uC11C\uC2DD\uC774 \uC720\uC9C0\uB418\uC9C0")) {
          console.log("[MAZA OS Runtime] Auto-confirming mode change dialog");
          return true;
        }
      }
      console.log("[MAZA OS Runtime] Auto-confirming unknown dialog:", msg);
      return true;
    };
    const _origAlert = window.alert;
    window.alert = (msg) => {
      console.log("[MAZA OS Runtime] Auto-dismissing native alert:", msg);
    };
    const channel = new BroadcastChannel("maza-runtime");
    const originalFetch = window.fetch;
    window.fetch = async function(input, init) {
      const url = typeof input === "string" ? input : input.url || "";
      const method = (init?.method || "GET").toUpperCase();
      const response = await originalFetch.apply(this, arguments);
      const isTistoryPublishUrl = url.includes("/publish") || url.includes("/post/write") || url.includes("/entry/post") || url.includes("/manage/entry") || url.includes("/apis/post");
      const isTistoryManagePost = method === "POST" && (url.includes("tistory.com/manage") || url.includes("tistory.com/apis"));
      if ((isTistoryPublishUrl || isTistoryManagePost) && response.ok) {
        console.log("[MAZA OS Runtime] \u2705 Intercepted successful publish API response!", url);
        channel.postMessage({ type: "MAZA_PUBLISH_API_SUCCESS", url });
      }
      return response;
    };
    const originalXHR = window.XMLHttpRequest.prototype.open;
    window.XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
      const targetUrl = url instanceof URL ? url.href : typeof url === "string" ? url : "";
      this.addEventListener("readystatechange", () => {
        if (this.readyState === 4 && this.status >= 200 && this.status < 300) {
          if (targetUrl.includes("/publish") || targetUrl.includes("/post/write")) {
            console.log("[MAZA OS Runtime] Intercepted successful XHR publish API response!");
            channel.postMessage({ type: "MAZA_PUBLISH_API_SUCCESS", url: targetUrl });
          }
        }
      });
      return originalXHR.apply(this, [method, url, async, user, password]);
    };
    function isPMView(v) {
      return v != null && typeof v === "object" && typeof v.dispatch === "function" && v.state != null && v.state.doc != null;
    }
    function findProseMirrorView(el) {
      if (!el) return null;
      const directProps = ["pmView", "__proseMirrorView", "editorView", "view", "editor", "_view", "__editorView", "_editor"];
      for (const prop of directProps) {
        if (isPMView(el[prop])) return el[prop];
      }
      const searchFiber = (startEl) => {
        try {
          const keys = Object.keys(startEl);
          const fiberKey = keys.find((k) => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$"));
          if (!fiberKey) return null;
          let fiber = startEl[fiberKey];
          let depth = 0;
          while (fiber && depth < 60) {
            const memoizedProps = fiber.memoizedProps;
            if (memoizedProps && typeof memoizedProps === "object") {
              for (const key of Object.keys(memoizedProps)) {
                if (isPMView(memoizedProps[key])) return memoizedProps[key];
              }
            }
            let hookState = fiber.memoizedState;
            let hookDepth = 0;
            while (hookState && hookDepth < 40) {
              if (isPMView(hookState.memoizedState?.current)) return hookState.memoizedState.current;
              if (isPMView(hookState.memoizedState)) return hookState.memoizedState;
              if (isPMView(hookState.queue?.lastRenderedState)) return hookState.queue.lastRenderedState;
              hookState = hookState.next;
              hookDepth++;
            }
            if (fiber.stateNode && typeof fiber.stateNode === "object" && fiber.stateNode !== startEl) {
              const node = fiber.stateNode;
              for (const key of Object.keys(node)) {
                if (isPMView(node[key])) return node[key];
              }
            }
            fiber = fiber.return;
            depth++;
          }
        } catch (e) {
          console.debug("[MAZA OS] Expected exception caught:", e);
        }
        return null;
      };
      let current = el;
      let parentDepth = 0;
      while (current && parentDepth < 10) {
        const found = searchFiber(current);
        if (found) return found;
        current = current.parentElement;
        parentDepth++;
      }
      try {
        const descendants = el.querySelectorAll("*");
        for (let i = 0; i < Math.min(descendants.length, 15); i++) {
          const found = searchFiber(descendants[i]);
          if (found) return found;
        }
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      return null;
    }
    async function simulatePasteInMainWorld(el, html) {
      try {
        el.focus();
        const doc = el.ownerDocument || document;
        const sel = doc.getSelection();
        if (sel) {
          const range = doc.createRange();
          range.selectNodeContents(el);
          range.collapse(false);
          sel.removeAllRanges();
          sel.addRange(range);
        }
        const dt = new DataTransfer();
        dt.setData("text/html", html);
        dt.setData("text/plain", html.replace(/<[^>]+>/g, ""));
        const pasteEvent = new ClipboardEvent("paste", {
          bubbles: true,
          cancelable: true,
          clipboardData: dt
        });
        el.dispatchEvent(pasteEvent);
        el.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, inputType: "insertFromPaste" }));
        el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText" }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      } catch (e) {
        return false;
      }
    }
    async function injectProseMirror(el, html) {
      try {
        const view = findProseMirrorView(el);
        if (view?.state && view?.dispatch) {
          const state = view.state;
          const schema = state.schema;
          const pmParser = window.ProseMirror?.model?.DOMParser || window.pm?.model?.DOMParser || view.constructor?.DOMParser || (schema?.markupDOMParser ? schema.markupDOMParser.constructor : null);
          if (pmParser) {
            const parserInstance = typeof pmParser.fromSchema === "function" ? pmParser.fromSchema(schema) : new pmParser(schema);
            const div = document.createElement("div");
            div.innerHTML = html;
            const parsed = parserInstance.parseSlice ? parserInstance.parseSlice(div) : parserInstance.parse(div);
            const fragment = parsed.content || parsed;
            const tr = state.tr.replaceWith(0, state.doc.content.size, fragment);
            view.dispatch(tr);
            view.focus();
            console.log("[MAZA OS Runtime] \u2705 ProseMirror Native Transaction injection success!");
            return true;
          }
          try {
            const plainText = html.replace(/<[^>]+>/g, "");
            const textNode = schema.text ? schema.text(plainText) : null;
            if (textNode) {
              const tr2 = state.tr.replaceWith(0, state.doc.content.size, textNode);
              view.dispatch(tr2);
              view.focus();
              console.log("[MAZA OS Runtime] \u2705 ProseMirror text-only injection success!");
              return true;
            }
          } catch (e2) {
          }
        }
      } catch (e) {
        console.warn("[MAZA OS Runtime] ProseMirror native transaction failed:", e);
      }
      try {
        el.focus();
        const sel = document.getSelection();
        if (sel) {
          const range = document.createRange();
          range.selectNodeContents(el);
          sel.removeAllRanges();
          sel.addRange(range);
        }
        const ok = document.execCommand("insertHTML", false, html);
        if (ok) {
          el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertFromPaste" }));
          console.log("[MAZA OS Runtime] \u2705 MainWorld execCommand insertHTML success!");
          return true;
        }
      } catch (e) {
        console.warn("[MAZA OS Runtime] execCommand failed:", e);
      }
      console.log("[MAZA OS Runtime] Fallback: Triggering paste simulation.");
      return await simulatePasteInMainWorld(el, html);
    }
    async function injectCodeMirror(html) {
      const el = findAnywhere(".CodeMirror");
      if (el?.CodeMirror) {
        el.CodeMirror.setValue(html);
        return el.CodeMirror.getValue() === html;
      }
      const cm6 = findAnywhere(".cm-editor .cm-content");
      if (cm6) {
        return await simulatePasteInMainWorld(cm6, html);
      }
      return false;
    }
    function injectMonaco(html) {
      const monaco = window.monaco;
      if (!monaco?.editor) return false;
      try {
        const editors = monaco.editor.getEditors();
        const active = editors.find((ed) => {
          if (!ed || ed.isDisposed()) return false;
          const dom = ed.getDomNode();
          return dom && dom.offsetWidth > 0 && dom.offsetHeight > 0;
        });
        if (active && active.getModel() && !active.getModel().isDisposed()) {
          const model = active.getModel();
          active.focus();
          active.executeEdits("maza-autopilot", [
            {
              range: model.getFullModelRange(),
              text: html,
              forceMoveMarkers: true
            }
          ]);
          if (model.getValue() !== html) {
            model.setValue(html);
          }
          const domNode = active.getDomNode();
          if (domNode) {
            domNode.dispatchEvent(new Event("input", { bubbles: true }));
            domNode.dispatchEvent(new Event("change", { bubbles: true }));
            const textArea = domNode.querySelector("textarea");
            if (textArea) {
              textArea.focus();
              textArea.dispatchEvent(new Event("input", { bubbles: true }));
              textArea.dispatchEvent(new Event("change", { bubbles: true }));
              textArea.blur();
            }
          }
          document.body.focus();
          console.log("[MAZA OS Runtime] Monaco Editor successfully injected via executeEdits with change dispatch.");
          return true;
        }
      } catch (e) {
        console.warn("[MAZA OS Runtime] Monaco injection failed:", e);
      }
      return false;
    }
    function performQuery() {
      const proseMirrorEl = findAnywhere(".ProseMirror") || findAnywhere('#editor-root div[contenteditable="true"]');
      if (proseMirrorEl) {
        const view = findProseMirrorView(proseMirrorEl);
        if (view?.state) return view.state.doc.textContent || "";
        return proseMirrorEl.innerText || proseMirrorEl.textContent || "";
      }
      const cm = findAnywhere(".CodeMirror");
      if (cm?.CodeMirror) return cm.CodeMirror.getValue() || "";
      const monaco = window.monaco;
      if (monaco?.editor) {
        const editors = monaco.editor.getEditors();
        const active = editors.find((e) => e && !e.isDisposed());
        if (active?.getModel()) return active.getModel().getValue() || "";
      }
      const rawTextarea = findAnywhere("textarea#tx_canvas_source, textarea.tf_source, textarea.editor-source");
      if (rawTextarea) return rawTextarea.value || "";
      return "";
    }
    async function performInjection(html) {
      const proseMirrorEl = findAnywhere('.ke-content[contenteditable="true"]') || findAnywhere(".ProseMirror[contenteditable]") || findAnywhere('[data-ke-editor="true"]') || findAnywhere('#editor-root div[contenteditable="true"]') || findAnywhere('[role="textbox"][contenteditable="true"]') || findAnywhere('div[contenteditable="true"]');
      if (proseMirrorEl) {
        console.log("[MAZA OS Runtime] Editor found:", proseMirrorEl.className || proseMirrorEl.tagName);
        if (await injectProseMirror(proseMirrorEl, html)) {
          return true;
        }
      } else {
        console.warn("[MAZA OS Runtime] No ProseMirror editor element found.");
      }
      if (await injectCodeMirror(html)) {
        return true;
      }
      if (injectMonaco(html)) {
        return true;
      }
      const rawTextarea = findAnywhere("textarea#tx_canvas_source, textarea.tf_source, textarea.editor-source");
      if (rawTextarea) {
        rawTextarea.value = html;
        rawTextarea.dispatchEvent(new Event("input", { bubbles: true }));
        rawTextarea.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }
      return false;
    }
    channel.onmessage = async (event) => {
      const { action, requestId, html } = event.data || {};
      if (!requestId) return;
      if (action === "PING") {
        channel.postMessage({ type: "MAZA_PONG_RESULT", requestId, ok: true });
        return;
      }
      if (action === "QUERY") {
        const value = performQuery();
        channel.postMessage({ type: "MAZA_QUERY_RESULT", requestId, ok: true, value });
      } else if (action === "INJECT") {
        const ok = await performInjection(html);
        channel.postMessage({ type: "MAZA_INJECT_POST_RESULT", requestId, ok });
      } else if (action === "REACT_CLICK") {
        try {
          const { selector, textContent } = event.data;
          let el = null;
          if (selector) {
            el = findAnywhere(selector);
          }
          if (!el && textContent) {
            const all = document.querySelectorAll('button, a, li, span, div, [role="button"], [role="menuitem"]');
            el = Array.from(all).find((e) => e.textContent?.trim() === textContent);
          }
          if (el) {
            el.click();
            el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
            el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
            let currentEl = el;
            let handlerFired = false;
            let depth = 0;
            while (currentEl && depth < 3 && !handlerFired) {
              const fiberKey = Object.keys(currentEl).find((k) => k.startsWith("__reactProps$") || k.startsWith("__reactEventHandlers$"));
              if (fiberKey) {
                const props = currentEl[fiberKey];
                const syntheticEvent = {
                  preventDefault: () => {
                  },
                  stopPropagation: () => {
                  },
                  target: el,
                  currentTarget: el,
                  bubbles: true,
                  nativeEvent: { isTrusted: true }
                };
                if (typeof props.onClick === "function") {
                  console.log(`[MAZA React] Fired onClick at depth ${depth} on ${currentEl.tagName}`);
                  props.onClick(syntheticEvent);
                  handlerFired = true;
                } else if (typeof props.onMouseDown === "function") {
                  console.log(`[MAZA React] Fired onMouseDown at depth ${depth} on ${currentEl.tagName}`);
                  props.onMouseDown(syntheticEvent);
                  handlerFired = true;
                } else if (typeof props.onPointerDown === "function") {
                  console.log(`[MAZA React] Fired onPointerDown at depth ${depth} on ${currentEl.tagName}`);
                  props.onPointerDown(syntheticEvent);
                  handlerFired = true;
                }
              }
              currentEl = currentEl.parentElement;
              depth++;
            }
            channel.postMessage({ type: "MAZA_REACT_CLICK_RESULT", requestId, ok: true });
          } else {
            channel.postMessage({ type: "MAZA_REACT_CLICK_RESULT", requestId, ok: false });
          }
        } catch (e) {
          channel.postMessage({ type: "MAZA_REACT_CLICK_RESULT", requestId, ok: false });
        }
      }
    };
    console.log("[MAZA OS Runtime] BroadcastChannel MainWorld Core successfully mounted.");
  })();
})();
//# sourceMappingURL=mainWorld.js.map
