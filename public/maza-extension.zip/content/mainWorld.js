"use strict";
(() => {
  // extension/content/mainWorld/broadcast.ts
  function createBroadcastChannel() {
    return new BroadcastChannel("maza-runtime");
  }

  // extension/content/mainWorld/dialogs.ts
  function overrideNativeDialogs() {
    const originalConfirm = window.confirm;
    window.confirm = (msg) => {
      if (msg) {
        if (msg.includes("\uC800\uC7A5\uB41C \uAE00\uC774 \uC788\uC2B5\uB2C8\uB2E4") || msg.includes("\uC774\uC5B4\uC11C \uC791\uC131")) {
          console.log("[MAZA OS Runtime] Auto-canceling draft recovery dialog");
          return false;
        }
        if (msg.includes("\uC791\uC131 \uBAA8\uB4DC\uB97C \uBCC0\uACBD") || msg.includes("\uC11C\uC2DD\uC774 \uC720\uC9C0\uB418\uC9C0") || msg.includes("html \uBC0F CSS \uD3B8\uC9D1")) {
          console.log("[MAZA OS Runtime] Auto-confirming mode change / skin edit dialog");
          return true;
        }
      }
      if (window.location.href.includes("/manage/posts") || msg && msg.includes("\uC0AD\uC81C")) {
        console.log("[MAZA OS Runtime] Allowing native dialog for user action:", msg);
        return originalConfirm(msg);
      }
      console.log("[MAZA OS Runtime] Passing through unknown dialog to original confirm:", msg);
      return originalConfirm(msg);
    };
    const originalAlert = window.alert;
    window.alert = (msg) => {
      if (typeof msg === "string" && msg.includes("\uCD5C\uB300 15\uAC1C")) {
        console.log("[MAZA OS Runtime] Handling daily limit alert automatically:", msg);
        document.documentElement.setAttribute("data-maza-error", "DAILY_LIMIT_EXCEEDED");
        return;
      }
      console.log("[MAZA OS Runtime] Passing through native alert:", msg);
      return originalAlert(msg);
    };
  }

  // extension/content/mainWorld/networkInterceptor.ts
  function setupFetchInterceptor(channel) {
    const originalFetch = window.fetch;
    window.fetch = async function(input, init) {
      const url = typeof input === "string" ? input : "url" in input && typeof input.url === "string" ? input.url : "";
      const method = init?.method ? String(init.method).toUpperCase() : "GET";
      const response = await originalFetch.call(this, input, init);
      const isTistoryPublishUrl = url.includes("/publish") || url.includes("/post/write") || url.includes("/entry/post") || url.includes("/manage/entry/post") || url.includes("/apis/post") || url.includes("/manage/api/") && !url.includes("/upload") && !url.includes("/image") && !url.includes("/attachment");
      const isUploadOrTempSave = url.includes("/upload") || url.includes("/image") || url.includes("/attachment") || url.includes("/tempSave") || url.includes("/temp-save") || url.includes("/autosave") || url.includes("/draft");
      if (isTistoryPublishUrl && !isUploadOrTempSave && method === "POST" && response.ok) {
        console.log("[MAZA OS Runtime] \u2705 Intercepted successful publish API response!", url);
        channel.postMessage({ type: "MAZA_PUBLISH_API_SUCCESS", url });
      }
      return response;
    };
  }
  function setupXHRInterceptor(channel) {
    const originalXHR = window.XMLHttpRequest.prototype.open;
    window.XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
      const targetUrl = url instanceof URL ? url.href : typeof url === "string" ? url : "";
      this.addEventListener("readystatechange", () => {
        if (this.readyState === 4 && this.status >= 200 && this.status < 300) {
          const isXhrPost = (method || "").toUpperCase() === "POST";
          const isXhrPublishUrl = targetUrl.includes("/publish") || targetUrl.includes("/post/write") || targetUrl.includes("/entry/post") || targetUrl.includes("/manage/entry/post") || targetUrl.includes("/apis/post");
          const isXhrUpload = targetUrl.includes("/upload") || targetUrl.includes("/image") || targetUrl.includes("/attachment") || targetUrl.includes("/tempSave") || targetUrl.includes("/autosave") || targetUrl.includes("/draft");
          if (isXhrPost && isXhrPublishUrl && !isXhrUpload) {
            console.log("[MAZA OS Runtime] Intercepted successful XHR publish API response!", targetUrl);
            channel.postMessage({ type: "MAZA_PUBLISH_API_SUCCESS", url: targetUrl });
          }
        }
      });
      return originalXHR.apply(this, [method, url, async, user, password]);
    };
  }

  // extension/utils/dom.ts
  function isObject(value) {
    return typeof value === "object" && value !== null;
  }
  function findAnywhere(selector, root = document) {
    if (Array.isArray(selector)) {
      for (const s of selector) {
        const found = findAnywhere(s, root);
        if (found) return found;
      }
      return null;
    }
    const el = root.querySelector(selector);
    if (el) return el;
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          const found = findAnywhere(selector, doc);
          if (found) return found;
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        const found = findAnywhere(selector, node.shadowRoot);
        if (found) return found;
      }
    }
    return null;
  }
  function findAnywhereAll(selector, root = document) {
    const elements = [];
    const seen = /* @__PURE__ */ new Set();
    const pushUnique = (items) => {
      for (const item of items) {
        if (!seen.has(item)) {
          seen.add(item);
          elements.push(item);
        }
      }
    };
    if (Array.isArray(selector)) {
      for (const s of selector) {
        pushUnique(findAnywhereAll(s, root));
      }
      return elements;
    }
    pushUnique(Array.from(root.querySelectorAll(selector)));
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          pushUnique(findAnywhereAll(selector, doc));
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        pushUnique(findAnywhereAll(selector, node.shadowRoot));
      }
    }
    return elements;
  }

  // extension/content/mainWorld/platforms.ts
  function getPlatformRoot() {
    return document.body || document;
  }

  // extension/content/mainWorld/editorBridge.ts
  var mazaWindow = window;
  function findWithinPlatform(selector) {
    const root = getPlatformRoot();
    return findAnywhere(selector, root);
  }
  function isPMView(value) {
    return isObject(value) && typeof value.dispatch === "function" && isObject(value.state) && value.state.doc != null;
  }
  function findProseMirrorView(el) {
    if (!el) return null;
    const directProps = ["pmView", "__proseMirrorView", "editorView", "view", "editor", "_view", "__editorView", "_editor"];
    const elRecord = el;
    for (const prop of directProps) {
      const candidate = elRecord[prop];
      if (isPMView(candidate)) return candidate;
    }
    const searchFiber = (startEl) => {
      try {
        const keys = Object.keys(startEl);
        const fiberKey = keys.find((k) => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$"));
        if (!fiberKey) return null;
        let fiber = startEl[fiberKey];
        let depth = 0;
        while (fiber && depth < 60) {
          const memoizedProps = fiber.memoizedProps;
          if (memoizedProps && isObject(memoizedProps)) {
            for (const key of Object.keys(memoizedProps)) {
              if (isPMView(memoizedProps[key])) return memoizedProps[key];
            }
          }
          let hookState = fiber.memoizedState;
          let hookDepth = 0;
          while (hookState && hookDepth < 40) {
            if (isPMView(hookState.memoizedState?.current)) return hookState.memoizedState.current;
            if (isPMView(hookState.memoizedState)) return hookState.memoizedState;
            if (isPMView(hookState.queue?.lastRenderedState)) return hookState.queue.lastRenderedState;
            hookState = hookState.next;
            hookDepth++;
          }
          if (fiber.stateNode && typeof fiber.stateNode === "object" && fiber.stateNode !== startEl) {
            const node = fiber.stateNode;
            for (const key of Object.keys(node)) {
              if (isPMView(node[key])) return node[key];
            }
          }
          fiber = fiber.return;
          depth++;
        }
      } catch (e) {
        console.debug("[MAZA OS] Expected exception caught:", e);
      }
      return null;
    };
    let current = el;
    let parentDepth = 0;
    while (current && parentDepth < 10) {
      const found = searchFiber(current);
      if (found) return found;
      current = current.parentElement;
      parentDepth++;
    }
    try {
      const descendants = findAnywhereAll("*", el);
      for (let i = 0; i < Math.min(descendants.length, 15); i++) {
        const found = searchFiber(descendants[i]);
        if (found) return found;
      }
    } catch (e) {
      console.debug("[MAZA OS] Expected exception caught:", e);
    }
    return null;
  }
  async function simulatePasteInMainWorld(el, html) {
    try {
      el.focus();
      const doc = el.ownerDocument || document;
      el.innerHTML = "";
      const sel = doc.getSelection();
      if (sel) {
        const range = doc.createRange();
        range.selectNodeContents(el);
        sel.removeAllRanges();
        sel.addRange(range);
      }
      const dt = new DataTransfer();
      dt.setData("text/html", html);
      dt.setData("text/plain", html.replace(/<[^>]+>/g, ""));
      const pasteEvent = new ClipboardEvent("paste", {
        bubbles: true,
        cancelable: true,
        clipboardData: dt
      });
      el.dispatchEvent(pasteEvent);
      el.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, inputType: "insertFromPaste" }));
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText" }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    } catch (e) {
      return false;
    }
  }
  async function simulatePasteForCodeEditor(el, html) {
    try {
      el.focus();
      const doc = el.ownerDocument || document;
      const sel = doc.getSelection();
      if (sel) {
        const range = doc.createRange();
        range.selectNodeContents(el);
        sel.removeAllRanges();
        sel.addRange(range);
      }
      const dt = new DataTransfer();
      dt.setData("text/plain", html);
      const pasteEvent = new ClipboardEvent("paste", {
        bubbles: true,
        cancelable: true,
        clipboardData: dt
      });
      el.dispatchEvent(pasteEvent);
      el.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, cancelable: true, inputType: "insertFromPaste" }));
      el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText" }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    } catch (e) {
      return false;
    }
  }
  async function injectProseMirror(el, html) {
    const view = findProseMirrorView(el);
    if (view?.state && view?.dispatch) {
      const state = view.state;
      const schema = state.schema;
      try {
        const pmParser = mazaWindow.ProseMirror?.model?.DOMParser || mazaWindow.pm?.model?.DOMParser || view.constructor?.DOMParser || (schema?.markupDOMParser ? schema.markupDOMParser.constructor : null);
        if (pmParser) {
          const parserInstance = typeof pmParser.fromSchema === "function" ? pmParser.fromSchema(schema) : new pmParser(schema);
          const div = document.createElement("div");
          div.innerHTML = html;
          const parsed = parserInstance.parseSlice ? parserInstance.parseSlice(div) : parserInstance.parse(div);
          const fragment = parsed.content || parsed;
          const tr = state.tr.replaceWith(0, state.doc.content.size, fragment);
          view.dispatch(tr);
          view.focus?.();
          console.log("[MAZA OS Runtime] \u2705 ProseMirror Native Transaction injection success!");
          return true;
        }
      } catch (e) {
        console.warn("[MAZA OS Runtime] ProseMirror native transaction failed:", e);
      }
      try {
        const clearTr = state.tr.delete(0, state.doc.content.size);
        view.dispatch(clearTr);
        console.log("[MAZA OS Runtime] ProseMirror cleared natively.");
      } catch (e) {
        console.warn("[MAZA OS Runtime] Failed to clear ProseMirror natively:", e);
      }
    }
    console.log("[MAZA OS Runtime] Triggering paste simulation fallback for ProseMirror.");
    const pasted = await simulatePasteInMainWorld(el, html);
    if (pasted) {
      console.log("[MAZA OS Runtime] \u2705 Paste simulation reports success.");
      return true;
    }
    try {
      el.focus();
      const sel = document.getSelection();
      if (sel) {
        const range = document.createRange();
        range.selectNodeContents(el);
        sel.removeAllRanges();
        sel.addRange(range);
      }
      document.execCommand("delete", false, void 0);
      const ok = document.execCommand("insertHTML", false, html);
      if (ok) {
        el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertFromPaste" }));
        console.log("[MAZA OS Runtime] \u2705 MainWorld execCommand insertHTML success!");
        return true;
      }
    } catch (e) {
      console.warn("[MAZA OS Runtime] execCommand failed:", e);
    }
    if (view?.state && view?.dispatch) {
      try {
        const schema = view.state.schema;
        const plainText = html.replace(/<[^>]+>/g, "");
        const textNode = schema.text ? schema.text(plainText) : null;
        if (textNode) {
          const tr2 = view.state.tr.replaceWith(0, view.state.doc.content.size, textNode);
          view.dispatch(tr2);
          view.focus?.();
          console.log("[MAZA OS Runtime] \u2705 ProseMirror text-only injection success!");
          return true;
        }
      } catch (e) {
      }
    }
    return false;
  }
  function isCodeMirrorInstance(value) {
    return isObject(value) && typeof value.setValue === "function" && typeof value.getValue === "function";
  }
  async function injectCodeMirror(html) {
    const cmHost = findWithinPlatform(".CodeMirror");
    const cm = cmHost ? cmHost.CodeMirror : void 0;
    const cm6 = findWithinPlatform(".cm-editor .cm-content");
    const target = cmHost || cm6;
    if (target) {
      console.log("[MAZA OS Runtime] CodeMirror element found. Triggering raw text paste simulation.");
      try {
        let inputTarget = target;
        if (cm && typeof cm.getInputField === "function") {
          inputTarget = cm.getInputField();
        } else if (target.querySelector(".CodeMirror-scroll")) {
          inputTarget = target.querySelector(".CodeMirror-scroll");
        }
        inputTarget.focus();
        const ok = document.execCommand("insertText", false, html);
        if (ok) {
          inputTarget.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertFromPaste" }));
          console.log("[MAZA OS Runtime] \u2705 CodeMirror insertText success!");
          return true;
        }
        console.log("[MAZA OS Runtime] Falling back to simulatePasteForCodeEditor");
        const pasted = await simulatePasteForCodeEditor(inputTarget, html);
        if (pasted) {
          console.log("[MAZA OS Runtime] \u2705 simulatePasteForCodeEditor success!");
          return true;
        }
      } catch (e) {
        console.warn("[MAZA OS Runtime] CodeMirror raw paste failed:", e);
      }
    }
    if (isCodeMirrorInstance(cm)) {
      cm.setValue(html);
      cmHost.dispatchEvent(new Event("input", { bubbles: true }));
      cmHost.dispatchEvent(new Event("change", { bubbles: true }));
      console.log("[MAZA OS Runtime] \u2705 CodeMirror setValue injection success!");
      return true;
    }
    return false;
  }
  function isMonacoEditorInstance(value) {
    return isObject(value) && typeof value.getModel === "function";
  }
  function injectMonaco(html) {
    const monaco = mazaWindow.monaco;
    if (!isObject(monaco) || !isObject(monaco.editor)) return false;
    const monacoEditor = monaco.editor;
    const tryInjectModel = (model) => {
      try {
        if (typeof model.setValue !== "function") return false;
        model.setValue(html);
        console.log("[MAZA OS Runtime] \u2705 Monaco model.setValue injection success!");
        return true;
      } catch (e) {
        return false;
      }
    };
    try {
      if (typeof monacoEditor.getEditors === "function") {
        const editors = monacoEditor.getEditors();
        const active = editors.find((ed) => isMonacoEditorInstance(ed) && !ed.isDisposed?.());
        if (active?.getModel) {
          const model = active.getModel();
          if (isObject(model)) {
            active.focus?.();
            const range = typeof model.getFullModelRange === "function" ? model.getFullModelRange() : void 0;
            if (typeof active.executeEdits === "function") {
              const executeEdits = active.executeEdits;
              executeEdits("maza-autopilot", [
                { range, text: html, forceMoveMarkers: true }
              ]);
            }
            if (typeof model.getValue === "function" && model.getValue() !== html) {
              tryInjectModel(model);
            }
            const domNode = active.getDomNode?.();
            domNode?.dispatchEvent(new Event("change", { bubbles: true }));
            console.log("[MAZA OS Runtime] \u2705 Monaco Editor injected via getEditors.");
            return true;
          }
        }
      }
      if (typeof monacoEditor.getModels === "function") {
        const models = monacoEditor.getModels();
        const htmlModel = models.find((m) => {
          if (typeof m.getValue !== "function") return false;
          const val = String(m.getValue());
          return val.includes("<!DOCTYPE") || val.includes("<html") || val.includes("<head");
        }) || models[0];
        if (htmlModel && tryInjectModel(htmlModel)) {
          const container = findAnywhere(".monaco-editor");
          container?.dispatchEvent(new Event("change", { bubbles: true }));
          return true;
        }
      }
    } catch (e) {
      console.warn("[MAZA OS Runtime] Monaco injection failed:", e);
    }
    return false;
  }
  function isElementActuallyVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
  function performQuery() {
    const cmHost = findWithinPlatform(".CodeMirror");
    const cm = cmHost ? cmHost.CodeMirror : void 0;
    if (isElementActuallyVisible(cmHost) && isCodeMirrorInstance(cm)) {
      return cm.getValue() || "";
    }
    const proseMirrorEl = findWithinPlatform(".ProseMirror") || findWithinPlatform('#editor-root div[contenteditable="true"]');
    if (proseMirrorEl) {
      const view = findProseMirrorView(proseMirrorEl);
      if (view?.state?.doc) {
        const pmText = view.state.doc.textContent || "";
        const docSize = view.state.doc.content?.size || 0;
        console.log("[MAZA OS Runtime] performQuery: ProseMirror view found. doc textContent length:", pmText.length, "docSize:", docSize);
        if (pmText.trim().length === 0 && docSize <= 4) {
          return "";
        }
        return proseMirrorEl.innerHTML || proseMirrorEl.innerText || proseMirrorEl.textContent || "";
      }
      const htmlContent = (proseMirrorEl.innerHTML || "").trim();
      if (htmlContent === "<p><br></p>" || htmlContent === "<p></p>" || htmlContent === "<div><br></div>") {
        return "";
      }
      return htmlContent || proseMirrorEl.innerText || proseMirrorEl.textContent || "";
    }
    if (isCodeMirrorInstance(cm)) return cm.getValue() || "";
    const monaco = mazaWindow.monaco;
    if (isObject(monaco) && isObject(monaco.editor)) {
      const monacoEditor = monaco.editor;
      if (typeof monacoEditor.getEditors === "function") {
        const editors = monacoEditor.getEditors();
        const active = editors.find((e) => isMonacoEditorInstance(e) && !e.isDisposed?.());
        if (active?.getModel) {
          const val = active.getModel().getValue();
          if (val) return val;
        }
      }
      if (typeof monacoEditor.getModels === "function") {
        const models = monacoEditor.getModels();
        const htmlModel = models.find((m) => {
          if (typeof m.getValue !== "function") return false;
          const val = String(m.getValue());
          return val.includes("<!DOCTYPE") || val.includes("<html") || val.includes("<head");
        }) || models[0];
        if (htmlModel && typeof htmlModel.getValue === "function") {
          return String(htmlModel.getValue()) || "";
        }
      }
    }
    const rawTextarea = findWithinPlatform("textarea#tx_canvas_source, textarea.tf_source, textarea.editor-source");
    if (rawTextarea) return rawTextarea.value || "";
    return "";
  }
  async function performInjection(html) {
    const isElementVisible = (el) => {
      if (!el) return false;
      const style = window.getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
    };
    const verify = async () => {
      await new Promise((resolve) => setTimeout(resolve, 150));
      const content = performQuery().trim();
      return content.length > 0;
    };
    const cmEl = findWithinPlatform(".CodeMirror") || findWithinPlatform(".cm-editor");
    const rawHTMLTextarea = findWithinPlatform("textarea#tx_canvas_source, textarea.tf_source, #htmlEditor");
    const isHtmlModeActive = isElementVisible(cmEl) || isElementVisible(rawHTMLTextarea);
    if (!isHtmlModeActive) {
      const proseMirrorEl = findWithinPlatform('.ke-content[contenteditable="true"]') || findWithinPlatform(".ProseMirror[contenteditable]") || findWithinPlatform('[data-ke-editor="true"]') || findWithinPlatform('#editor-root div[contenteditable="true"]') || findWithinPlatform(".editor_area [contenteditable]") || findWithinPlatform(".tt-editor [contenteditable]") || findWithinPlatform(".tx-content-body") || findWithinPlatform(".tx-editor") || findWithinPlatform(".tx-content") || findWithinPlatform('[role="textbox"][contenteditable="true"]') || (() => {
        const candidate = findWithinPlatform('div[contenteditable="true"]:not(.mce-content-body)');
        return candidate && isElementVisible(candidate) ? candidate : null;
      })();
      if (proseMirrorEl) {
        console.log("[MAZA OS Runtime] WYSIWYG mode \u2014 injecting via ProseMirror:", proseMirrorEl.className || proseMirrorEl.tagName);
        if (await injectProseMirror(proseMirrorEl, html)) {
          if (await verify()) return true;
          console.warn("[MAZA OS Runtime] ProseMirror injection reported success but verification failed. Falling back...");
        }
      }
    } else {
      console.log("[MAZA OS Runtime] HTML mode detected \u2014 skipping ProseMirror to preserve inline styles.");
    }
    if (await injectCodeMirror(html)) {
      if (await verify()) return true;
      console.warn("[MAZA OS Runtime] CodeMirror injection reported success but verification failed. Falling back...");
    }
    if (injectMonaco(html)) {
      if (await verify()) return true;
      console.warn("[MAZA OS Runtime] Monaco injection reported success but verification failed. Falling back...");
    }
    const rawTextarea = findWithinPlatform('textarea#tx_canvas_source, textarea.tf_source, textarea.editor-source, textarea[name="source"]');
    if (rawTextarea) {
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
      if (nativeSetter) {
        nativeSetter.call(rawTextarea, html);
      } else {
        rawTextarea.value = html;
      }
      rawTextarea.dispatchEvent(new Event("input", { bubbles: true }));
      rawTextarea.dispatchEvent(new Event("change", { bubbles: true }));
      if (await verify()) return true;
      console.warn("[MAZA OS Runtime] Raw textarea injection reported success but verification failed. Falling back...");
    }
    const allTextareas = findAnywhereAll("textarea").filter(
      (ta) => !ta.classList.contains("inputarea") && !ta.classList.contains("monaco-mouse-cursor-text")
    );
    const codeTextarea = allTextareas.find((ta) => ta.value.includes("<html") || ta.value.includes("<head") || ta.value.includes("<!DOCTYPE")) || allTextareas.find((ta) => ta.value.length > 0) || allTextareas[0];
    if (codeTextarea) {
      console.log("[MAZA OS Runtime] Using aggressive textarea fallback:", codeTextarea.className || codeTextarea.id);
      codeTextarea.value = html;
      codeTextarea.dispatchEvent(new Event("input", { bubbles: true }));
      codeTextarea.dispatchEvent(new Event("change", { bubbles: true }));
      if (await verify()) return true;
    }
    return false;
  }

  // extension/content/mainWorld/infraBridge.ts
  async function processInfraHtml(html, currentValue) {
    if (!currentValue || currentValue.length < 20) {
      return currentValue.includes("<head>") ? currentValue.replace("<head>", "<head>\n" + html) : html;
    }
    const regexNew = /<!-- Maza Infra -->[\s\S]*?<!-- End Maza Infra -->\n?/g;
    const withoutMaza = currentValue.replace(regexNew, "");
    const alreadyHasSc = /google-site-verification/i.test(withoutMaza);
    const alreadyHasGa = new RegExp("googletagmanager\\.com\\/gtag", "i").test(withoutMaza);
    if (alreadyHasSc && alreadyHasGa && currentValue.includes(html.trim().slice(0, 40))) {
      return null;
    }
    const cleaned = withoutMaza;
    return cleaned.includes("<head>") ? cleaned.replace("<head>", "<head>\n" + html) : html + "\n" + cleaned;
  }
  async function performInfraInjection(html) {
    try {
      const hasPayload = html && html !== "null" && html !== "undefined" && (html.includes("google-site-verification") || html.includes("googletagmanager.com/gtag"));
      if (!hasPayload) {
        return { ok: false, error: "EMPTY_INFRA_HTML" };
      }
      const cmEls = findAnywhereAll(".CodeMirror");
      for (const el of cmEls) {
        if (el.CodeMirror) {
          const cm = el.CodeMirror;
          const newVal = await processInfraHtml(html, cm.getValue());
          if (newVal === null) return { ok: true, step: "ALREADY_INJECTED" };
          cm.setValue(newVal);
          return { ok: true, step: "SUCCESS" };
        }
      }
      if (window.monaco?.editor) {
        const models = window.monaco.editor.getModels();
        if (models && models.length > 0) {
          const newVal = await processInfraHtml(html, models[0].getValue());
          if (newVal === null) return { ok: true, step: "ALREADY_INJECTED" };
          models[0].setValue(newVal);
          return { ok: true, step: "SUCCESS" };
        }
      }
      const htmlTextarea = findAnywhere("textarea");
      if (htmlTextarea && (htmlTextarea.value.includes("<html") || htmlTextarea.value.includes("<!doctype"))) {
        const newVal = await processInfraHtml(html, htmlTextarea.value);
        if (newVal === null) return { ok: true, step: "ALREADY_INJECTED" };
        const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
        if (setter) setter.call(htmlTextarea, newVal);
        else htmlTextarea.value = newVal;
        htmlTextarea.dispatchEvent(new Event("input", { bubbles: true }));
        htmlTextarea.dispatchEvent(new Event("change", { bubbles: true }));
        return { ok: true, step: "SUCCESS" };
      }
      return { ok: false, error: "NO_EDITOR_FOUND" };
    } catch (err) {
      return { ok: false, error: err?.message || "MAIN_WORLD_INJECT_INFRA_FAILED" };
    }
  }

  // extension/content/mainWorld/reactClick.ts
  async function handleReactClick(eventData) {
    const data = eventData;
    const { selector, textContent } = data;
    let el = null;
    if (selector) {
      el = findAnywhere(selector);
    }
    if (!el && textContent) {
      const all = findAnywhereAll('button, a, li, span, div, [role="button"], [role="menuitem"]');
      el = all.find((e) => e.textContent?.trim() === textContent);
    }
    if (!el) return false;
    el.click();
    el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
    el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
    return true;
  }

  // extension/content/mainWorld/runtime.ts
  function initMainWorldRuntime() {
    const mazaWindow2 = window;
    if (mazaWindow2.__MAZA_RUNTIME__) {
      console.log("[MAZA OS Runtime] Singleton active. Skipping re-initialization.");
      return;
    }
    mazaWindow2.__MAZA_RUNTIME__ = true;
    overrideNativeDialogs();
    const channel = createBroadcastChannel();
    setupFetchInterceptor(channel);
    setupXHRInterceptor(channel);
    channel.onmessage = async (event) => {
      if (!event?.data || typeof event.data !== "object") {
        return;
      }
      const { action, requestId, html } = event.data;
      if (!requestId || typeof requestId !== "string") return;
      if (action === "PING") {
        channel.postMessage({ type: "MAZA_PONG_RESULT", requestId, ok: true });
        return;
      }
      if (action === "QUERY") {
        const value = performQuery();
        channel.postMessage({ type: "MAZA_QUERY_RESULT", requestId, ok: true, value });
        return;
      }
      if (action === "INJECT") {
        const ok = await performInjection(typeof html === "string" ? html : "");
        channel.postMessage({ type: "MAZA_INJECT_POST_RESULT", requestId, ok });
        return;
      }
      if (action === "INJECT_INFRA") {
        const result = await performInfraInjection(typeof html === "string" ? html : "");
        channel.postMessage({
          type: "MAZA_INJECT_INFRA_RESULT",
          requestId,
          ok: result.ok,
          step: result.step,
          error: result.error
        });
        return;
      }
      if (action === "REACT_CLICK") {
        const ok = await handleReactClick(event.data);
        channel.postMessage({ type: "MAZA_REACT_CLICK_RESULT", requestId, ok });
        return;
      }
    };
    console.log("[MAZA OS Runtime] BroadcastChannel MainWorld Core successfully mounted.");
  }

  // extension/content/mainWorld.ts
  initMainWorldRuntime();
})();
//# sourceMappingURL=mainWorld.js.map
