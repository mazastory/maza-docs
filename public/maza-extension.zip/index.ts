/**
 * Maza Bridge vNext — platforms/index.js
 * 
 * 모든 플랫폼 어댑터를 관리하고 매칭하는 중앙 허브
 */

import { TistoryAdapter } from './tistory.js';

export interface PlatformAdapter {
  name: string;
  selectors: {
    title: string | string[];
    tags?: string | string[];
    editor: string | string[];
    iframe?: string;
    publish: string | string[];
  };
  preAction: (tabId: number, url: string) => Promise<{ action: string } | null>;
  verify: (tabId: number) => Promise<boolean>;
}

const ADAPTERS: PlatformAdapter[] = [
  TistoryAdapter,
];

export function getPlatformAdapter(url: string): PlatformAdapter {
  if (!url) return TistoryAdapter; // Fallback

  const match = ADAPTERS.find(adapter => {
    if (adapter.name === 'tistory' && url.includes('tistory.com')) return true;
    if (adapter.name === 'wordpress' && url.includes('wordpress.com')) return true;
    return false;
  });

  return match || TistoryAdapter;
}
