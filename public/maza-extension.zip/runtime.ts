/**
 * Maza Bridge v5 — shared/runtime.ts
 * Centralized Initialization & Lifecycle Manager
 * Handles API availability checks, deterministic bootstrapping, and singleton enforcement.
 */

export enum RuntimeContext {
  BACKGROUND = 'BACKGROUND',
  OFFSCREEN = 'OFFSCREEN',
  POPUP = 'POPUP',
  CONTENT = 'CONTENT',
  UNKNOWN = 'UNKNOWN'
}

class MazaRuntime {
  private context: RuntimeContext = RuntimeContext.UNKNOWN;
  private isInitialized = false;
  private initPromise: Promise<void> | null = null;

  constructor() {
    this.detectContext();
  }

  private detectContext() {
    if (typeof window === 'undefined') {
      this.context = RuntimeContext.BACKGROUND;
    } else if (window.location.pathname.includes('offscreen')) {
      this.context = RuntimeContext.OFFSCREEN;
    } else if (window.location.pathname.includes('popup')) {
      this.context = RuntimeContext.POPUP;
    } else {
      this.context = RuntimeContext.CONTENT;
    }
  }

  /**
   * Deterministic Bootstrap Barrier
   * Ensures all required Chrome APIs are injected and ready before proceeding.
   */
  async bootstrap(): Promise<void> {
    if (this.isInitialized) return;
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      console.log(`[Runtime:${this.context}] 🚀 Bootstrapping...`);
      
      // 1. Wait for Chrome API Availability (The core fix for 'local' of undefined)
      await this.waitForChromeApi();

      // 2. Clear stale states if necessary
      if (this.context === RuntimeContext.OFFSCREEN) {
        console.log(`[Runtime:${this.context}] ✅ API Ready. Initializing Core Services...`);
      }

      this.isInitialized = true;
      console.log(`[Runtime:${this.context}] ✨ Bootstrap Complete.`);
    })();

    return this.initPromise;
  }

  private async waitForChromeApi(): Promise<void> {
    const MAX_RETRIES = 50; // Max 5 seconds
    for (let i = 0; i < MAX_RETRIES; i++) {
      // 1. Core API check
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        // 2. Context-specific availability
        if (this.context === RuntimeContext.CONTENT) {
          // Content Scripts MUST have storage access for auth/state
          if (chrome.storage && chrome.storage.local) return;
        } else {
          // Background/Offscreen/Popup are native; if 'chrome.runtime' exists, they are ready
          return;
        }
      }
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    throw new Error(`[Runtime:${this.context}] ❌ Critical Failure: Chrome APIs failed to inject.`);
  }

  getContext(): RuntimeContext {
    return this.context;
  }

  async ready(): Promise<void> {
    if (!this.isInitialized) {
      await this.bootstrap();
    }
  }
}

export const runtime = new MazaRuntime();
