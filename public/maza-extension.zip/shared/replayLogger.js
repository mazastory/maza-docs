/**
 * Maza Bridge v5 — shared/replayLogger.js
 * Session Replay & Blackbox Recorder
 */
import { runtime } from './runtime.js';
class ReplayLogger {
    currentSession = null;
    async startSession(jobId, initialPayload) {
        this.currentSession = {
            jobId,
            startTime: Date.now(),
            payload: initialPayload,
            events: [],
            error: null,
            snapshot: null
        };
        console.log(`[ReplayLogger] 🔴 Started recording session: ${jobId}`);
        await this.persistCurrent();
    }
    async logTransition(fromState, toState, meta = {}) {
        if (!this.currentSession)
            return;
        this.currentSession.events.push({
            type: 'TRANSITION',
            timestamp: Date.now(),
            from: fromState,
            to: toState,
            meta
        });
        await this.persistCurrent();
    }
    async logAction(actionName, data = {}) {
        if (!this.currentSession)
            return;
        this.currentSession.events.push({
            type: 'ACTION',
            timestamp: Date.now(),
            action: actionName,
            data
        });
        await this.persistCurrent();
    }
    async logError(error, snapshotHtml = null) {
        if (!this.currentSession)
            return;
        this.currentSession.events.push({
            type: 'ERROR',
            timestamp: Date.now(),
            message: error.message || error,
            stack: error.stack
        });
        this.currentSession.error = error.message || error;
        if (snapshotHtml) {
            this.currentSession.snapshot = snapshotHtml;
        }
        await this.persistCurrent();
    }
    async persistCurrent() {
        if (!this.currentSession)
            return;
        await runtime.ready();
        if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local)
            return;
        // Store current active session separately for crash recovery
        return new Promise(resolve => {
            chrome.runtime.sendMessage({
                type: 'RPC_CALL',
                method: 'STORAGE_SET',
                params: { data: { 'MAZA_ACTIVE_REPLAY': this.currentSession } }
            }, () => {
                if (chrome.runtime.lastError)
                    console.warn('[ReplayLogger] RPC Error:', chrome.runtime.lastError);
                resolve(undefined);
            });
        });
    }
    async saveSession() {
        if (!this.currentSession)
            return;
        this.currentSession.endTime = Date.now();
        await runtime.ready();
        if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
            this.currentSession = null;
            return;
        }
        // Save to local storage for the DevTools UI to pick up
        return new Promise((resolve) => {
            chrome.runtime.sendMessage({
                type: 'RPC_CALL',
                method: 'STORAGE_GET',
                params: { keys: ['MAZA_REPLAYS'] }
            }, (response) => {
                if (chrome.runtime.lastError)
                    console.warn('[ReplayLogger] RPC Error:', chrome.runtime.lastError);
                let replays = (response?.result?.MAZA_REPLAYS) || [];
                if (this.currentSession)
                    replays.unshift(this.currentSession);
                // Keep only last 10 replays to save space
                if (replays.length > 10)
                    replays = replays.slice(0, 10);
                chrome.runtime.sendMessage({
                    type: 'RPC_CALL',
                    method: 'STORAGE_SET',
                    params: { data: { MAZA_REPLAYS: replays } }
                }, () => {
                    if (chrome.runtime.lastError)
                        console.warn('[ReplayLogger] RPC Error:', chrome.runtime.lastError);
                    chrome.runtime.sendMessage({
                        type: 'RPC_CALL',
                        method: 'STORAGE_SET', // Not ideal but we can just set to null, or add a STORAGE_REMOVE
                        params: { data: { MAZA_ACTIVE_REPLAY: null } }
                    }, () => {
                        if (chrome.runtime.lastError)
                            console.warn('[ReplayLogger] RPC Error:', chrome.runtime.lastError);
                        console.log(`[ReplayLogger] 💾 Saved session replay: ${this.currentSession?.jobId || 'unknown'}`);
                        this.currentSession = null;
                        resolve(undefined);
                    });
                });
            });
        });
    }
    async getSessionData() {
        return this.currentSession;
    }
}
export const replayLogger = new ReplayLogger();
//# sourceMappingURL=replayLogger.js.map