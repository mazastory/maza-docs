/**
 * Maza Bridge vNext — shared/config.js
 * 
 * 모든 환경 설정을 중앙에서 관리합니다.
 */

export const CONFIG = {
  // 개발 환경
  API_BASE_URL: 'http://localhost:3001/api',
  WS_URL: 'ws://localhost:3001/ws',
  STUDIO_URL: 'http://localhost:5174',

  /* 
  // 프로덕션 환경 (예시)
  API_BASE_URL: 'https://api.mazastudio.ai/api',
  WS_URL: 'wss://api.mazastudio.ai/ws',
  STUDIO_URL: 'https://app.mazastudio.ai',
  */

  // 안전 규칙
  W05_SAFETY_COOLDOWN: 10800, // 3시간 (초)
  MAX_RETRY_COUNT: 3
};
