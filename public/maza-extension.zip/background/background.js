// extension/shared/config.ts
var CONFIG = {
  API_BASE_URL: "https://mazastudio.kr/api",
  STUDIO_URL: "https://mazastudio.kr",
  POLLING_INTERVAL_MS: 5e3
};

// extension/shared/infraHtml.ts
function cleanScVerification(raw) {
  let clean = (raw || "").trim();
  const d = clean.match(/content="([^"]+)"/);
  const s = clean.match(/content='([^']+)'/);
  if (d) clean = d[1];
  else if (s) clean = s[1];
  if (clean.startsWith("google-site-verification=")) {
    clean = clean.replace("google-site-verification=", "");
  }
  return clean.trim();
}
function cleanGaMeasurementId(raw) {
  let clean = (raw || "").trim();
  if (clean.includes("id=")) {
    const m = clean.match(/id=(G-[A-Z0-9]+)/);
    if (m) clean = m[1];
  }
  if (clean && !clean.startsWith("G-")) return "";
  return clean;
}
function buildInfraInjectionHtml(sc_verification, ga_measurement_id) {
  const clean_sc = cleanScVerification(sc_verification);
  const clean_ga = cleanGaMeasurementId(ga_measurement_id);
  const scHtml = clean_sc ? `<meta name="google-site-verification" content="${clean_sc}" />` : "";
  const gaHtml = clean_ga ? `<!-- Global site tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=${clean_ga}"><\/script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${clean_ga}');<\/script>` : "";
  if (!scHtml && !gaHtml) return null;
  const parts = [scHtml, gaHtml].filter(Boolean);
  return `<!-- Maza Infra -->
${parts.join("\n")}
<!-- End Maza Infra -->`;
}
function isValidInfraHtml(html) {
  if (!html || html === "null" || html === "undefined") return false;
  return html.includes("google-site-verification") || html.includes("googletagmanager.com/gtag");
}

// extension/utils/logger.ts
function log(scope, message, data) {
  const timestamp = (/* @__PURE__ */ new Date()).toISOString().split("T")[1].split("Z")[0];
  const formattedMsg = `[${timestamp}] [${scope}] ${message}`;
  console.log(formattedMsg, data || "");
  try {
    chrome.runtime.sendMessage({
      type: "TASK_LOG",
      scope,
      message: formattedMsg,
      data
    }).catch(() => {
    });
  } catch (e) {
    console.debug("[MAZA OS] Expected exception caught:", e);
  }
}
function error(scope, message, data) {
  console.error(`[${scope}] \u274C ${message}`, data || "");
}

// extension/utils/screenshot.ts
async function captureErrorState() {
  try {
    return await chrome.tabs.captureVisibleTab({ format: "png" });
  } catch (e) {
    return null;
  }
}

// extension/background/background.ts
log("SYSTEM", "MAZA OS Phoenix Engine Started.");
var infraInjectInFlight = false;
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error2) => console.error(error2));
chrome.action.onClicked.addListener((tab) => {
  if (tab.windowId) {
    chrome.sidePanel.open({ windowId: tab.windowId });
  }
});
async function pollingLoop() {
  try {
    if (globalThis.taskExecutionInProgress) {
      return;
    }
    const storage = await chrome.storage.local.get(["mazaToken", "mazaOrigin"]);
    if (!storage.mazaToken) return;
    const origin = storage.mazaOrigin?.replace(/\/$/, "") || "";
    const apiBase = origin ? `${origin}/api` : CONFIG.API_BASE_URL;
    const res = await fetch(`${apiBase}/tasks/next`, {
      headers: { "Authorization": `Bearer ${storage.mazaToken}` }
    });
    if (res.status === 401 || res.status === 403) {
      log("POLLING", `Auth error ${res.status} \u2014 token may be expired. Skipping.`);
      return;
    }
    if (res.status === 200) {
      const contentType = res.headers.get("content-type") || "";
      if (!contentType.includes("application/json")) {
        const preview = (await res.text()).substring(0, 80);
        log("POLLING", `Non-JSON response ignored (${contentType}): ${preview}`);
        return;
      }
      const text = await res.text();
      let result;
      try {
        result = JSON.parse(text);
      } catch (e) {
        log("POLLING", `JSON parse failed. Preview: ${text.substring(0, 80)}`);
        return;
      }
      if (result.success && result.command === "EXECUTE") {
        const task = result.data;
        log("POLLING", `Task Found: ${task.type}`, task.id);
        await executeTask(task);
      }
    }
  } catch (err) {
    if (err.message?.includes("Failed to fetch") || err.message?.includes("Load failed")) {
      return;
    }
    error("POLLING", `Polling loop error: ${err.message}`);
  }
}
function isLoginOrAuthUrl(url) {
  return url.includes("/auth/login") || url.includes("accounts.kakao.com") || url.includes("auth.kakao.com") || url.includes("kauth.kakao.com");
}
async function waitForTistoryManagePage(tabId, task) {
  const skinUrl = task.url;
  const deadline = Date.now() + 12e4;
  while (Date.now() < deadline) {
    let tab;
    try {
      tab = await chrome.tabs.get(tabId);
    } catch (e) {
      throw new Error(`\uC791\uC131 \uC911\uC778 \uD0ED(ID: ${tabId})\uC774 \uC0AC\uC6A9\uC790\uC5D0 \uC758\uD574 \uB2EB\uD614\uAC70\uB098 \uC720\uC2E4\uB418\uC5C8\uC2B5\uB2C8\uB2E4.`);
    }
    const url = tab?.url || "";
    if (isLoginOrAuthUrl(url)) {
      relayToWebApp({
        type: "MAZA_INFRA_PROGRESS",
        step: "WAITING_LOGIN",
        detail: "\uCE74\uCE74\uC624/\uD2F0\uC2A4\uD1A0\uB9AC \uB85C\uADF8\uC778\uC744 \uC644\uB8CC\uD574 \uC8FC\uC138\uC694. \uC644\uB8CC \uD6C4 \uC790\uB3D9\uC73C\uB85C HTML \uD3B8\uC9D1 \uD654\uBA74\uC73C\uB85C \uC774\uB3D9\uD569\uB2C8\uB2E4."
      });
      await new Promise((r) => setTimeout(r, 2e3));
      continue;
    }
    if (url.includes("tistory.com") && !url.includes("/manage/")) {
      await chrome.tabs.update(tabId, { url: skinUrl });
      await waitForTabComplete(tabId);
      await new Promise((r) => setTimeout(r, 2500));
      continue;
    }
    if (url.includes("/manage/")) {
      if (task.type === "INFRA_INJECT" && !url.includes("skin/edit")) {
        await chrome.tabs.update(tabId, { url: skinUrl });
        await waitForTabComplete(tabId);
        await new Promise((r) => setTimeout(r, 4500));
      } else if (task.type === "PUBLISH_POST") {
        try {
          const expectedPath = new URL(skinUrl).pathname.replace(/\/$/, "");
          const currentPath = new URL(url).pathname.replace(/\/$/, "");
          if (expectedPath && !currentPath.includes(expectedPath)) {
            log("EXEC", `Tab is on ${currentPath} but expected ${expectedPath}. Forcing navigation...`);
            await chrome.tabs.update(tabId, { url: skinUrl });
            await waitForTabComplete(tabId);
            await new Promise((r) => setTimeout(r, 2e3));
            continue;
          }
        } catch (e) {
        }
      }
      return;
    }
    await chrome.tabs.update(tabId, { url: skinUrl });
    await waitForTabComplete(tabId);
    await new Promise((r) => setTimeout(r, 2e3));
  }
  throw new Error(
    "\uD2F0\uC2A4\uD1A0\uB9AC \uB85C\uADF8\uC778 \uB610\uB294 \uC2A4\uD0A8 HTML \uD3B8\uC9D1 \uD654\uBA74 \uC9C4\uC785 \uC2DC\uAC04\uC774 \uCD08\uACFC\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uB85C\uADF8\uC778 \uD6C4 \uB2E4\uC2DC [\uC790\uB3D9 \uC8FC\uC785 \uC2DC\uC791]\uC744 \uB20C\uB7EC\uC8FC\uC138\uC694."
  );
}
async function ensureInjectorOnTab(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "MAZA_PING" });
    return;
  } catch {
  }
  await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    files: ["content/injector.js"]
  });
  await new Promise((r) => setTimeout(r, 800));
}
async function runTaskOnTab(tabId, task) {
  await ensureInjectorOnTab(tabId);
  try {
    return await chrome.tabs.sendMessage(tabId, { type: "RUN_TASK", task });
  } catch (msgErr) {
    log("EXEC", "Content script not ready, retrying...", tabId);
    await new Promise((r) => setTimeout(r, 2e3));
    await ensureInjectorOnTab(tabId);
    return await chrome.tabs.sendMessage(tabId, { type: "RUN_TASK", task });
  }
}
var isExecutingTask = false;
async function executeTask(task) {
  if (isExecutingTask) {
    log("EXEC", "Task executor is currently busy. Ignoring concurrent task:", task.id);
    if (task.type === "INFRA_INJECT") {
      relayToWebApp({ type: "MAZA_INFRA_PROGRESS", step: "ERROR", detail: "\uC774\uBBF8 \uB2E4\uB978 \uC624\uD1A0\uD30C\uC77C\uB7FF \uC791\uC5C5\uC774 \uC2E4\uD589 \uC911\uC785\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694." });
    }
    if (globalThis.lastImmediateTask?.id === task.id) {
      globalThis.lastImmediateTask = null;
      chrome.storage.local.remove("lastImmediateTask");
    }
    return;
  }
  isExecutingTask = true;
  try {
    globalThis.taskExecutionInProgress = task.id;
    if (task.id && task.id.toString().startsWith("immediate-")) {
      globalThis.lastImmediateTask = task;
      await chrome.storage.local.set({ lastImmediateTask: task });
    } else {
      globalThis.lastImmediateTask = null;
      await chrome.storage.local.remove("lastImmediateTask");
    }
    if (task.type === "INFRA_INJECT") {
      if (infraInjectInFlight) {
        log("EXEC", "Skipping duplicate INFRA_INJECT task", task.id);
        return;
      }
      infraInjectInFlight = true;
    }
    if (task.type === "INFRA_INJECT" && !isValidInfraHtml(task.payload?.html)) {
      const built = buildInfraInjectionHtml(
        task.payload?.sc_verification,
        task.payload?.ga_measurement_id
      );
      if (built) task.payload.html = built;
      else throw new Error("\uC8FC\uC785\uD560 \uC11C\uCE58\uCF58\uC194/GA4 \uCF54\uB4DC\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. \uB3D9\uAE30\uD654 \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");
    }
    let tabId = null;
    try {
      log("EXEC", `Creating or finding tab for task: ${task.url}`);
      const tistoryTabs = await chrome.tabs.query({ url: "*://*.tistory.com/manage/*" });
      if (tistoryTabs.length > 0 && tistoryTabs[0].id) {
        tabId = tistoryTabs[0].id;
        await chrome.tabs.update(tabId, { url: task.url, active: true });
      } else {
        const newTab = await chrome.tabs.create({ url: task.url, active: true });
        tabId = newTab.id;
      }
      await waitForTabComplete(tabId);
      await new Promise((r) => setTimeout(r, 3e3));
      await waitForTistoryManagePage(tabId, task);
      chrome.runtime.sendMessage({ type: "TASK_STARTED", taskType: task.type }).catch(() => {
      });
      const result = await runTaskOnTab(tabId, task);
      if (task.type === "INFRA_INJECT") {
        relayToWebApp({
          type: "MAZA_INFRA_PROGRESS",
          step: result?.ok ? result.step || "SUCCESS" : "ERROR",
          detail: result?.error || ""
        });
        if (result?.ok) {
          await focusWebAppTab();
        }
      }
      if (result && result.status === "NAVIGATING_TO_EDITOR") {
        console.warn("[MAZA EXEC] NAVIGATING_TO_EDITOR detected \u2014 stopping retry loop for this task.");
        return;
      }
      await reportResult(task.id, result);
      log("EXEC", "Task Completed Successfully", task.id);
    } catch (err) {
      const errMsg = err.message || "";
      const isConnectionError = errMsg.includes("message channel closed") || errMsg.includes("asynchronous response") || errMsg.includes("Could not establish connection") || errMsg.includes("Receiving end does not exist") || errMsg.includes("No tab with id");
      if (isConnectionError && task.type === "PUBLISH_POST") {
        log("EXEC", `\uD37C\uC9C0 \uC774\uB3D9\uC73C\uB85C \uC5F0\uACB0 \uC885\uB8CC. \uD0D0 URL \uD655\uC778 \uD6C4 \uACB0\uACFC \uBCF4\uACE0\uC2DC\uB3C4...`, task.id);
        try {
          if (tabId !== null) {
            await new Promise((r) => setTimeout(r, 2e3));
            const currentTab = await chrome.tabs.get(tabId).catch(() => null);
            const tabUrl = currentTab?.url || "";
            const isSuccessUrl = tabUrl.includes("/manage/posts") || /\/entry\//.test(tabUrl) || /\/\d+/.test(tabUrl) && !tabUrl.includes("/manage/newpost");
            if (isSuccessUrl) {
              log("EXEC", `\uD0ED URL(${tabUrl})\uC774 \uC131\uACF5\uC744 \uB098\uD0C0\uB0C4. \uC131\uACF5\uC73C\uB85C \uBCF4\uACE0.`, task.id);
              await reportResult(task.id, { ok: true, published_url: tabUrl });
            } else {
              log("EXEC", `\uD0ED URL(${tabUrl})\uC774 \uB300\uAE30 \uC911. \uC2E4\uD328\uB85C \uBCF4\uACE0.`, task.id);
              await reportResult(task.id, { ok: false, error: `\uD37C\uC9C0 \uC774\uB3D9 \uD6C4 URL \uD655\uC778 \uC2E4\uD328: ${tabUrl || "(unknown)"}` });
            }
          } else {
            log("EXEC", `tabId \uCC38\uC870 \uC2E4\uD328. \uC5F0\uACB0 \uC5D0\uB7EC \uBCF4\uACE0.`, task.id);
            await reportResult(task.id, { ok: false, error: errMsg });
          }
        } catch (reportErr) {
          log("EXEC", `\uC5F0\uACB0 \uC5D0\uB7EC \uD6C4 reportResult \uC2E4\uD328: ${reportErr.message}`, task.id);
        }
        return;
      }
      if (isConnectionError) {
        log("EXEC", `Connection/tab error during execution \u2014 likely a successful navigation or tab close. Ignoring.`, task.id);
        return;
      }
      const screenshot = await captureErrorState();
      if (task.type === "INFRA_INJECT") {
        relayToWebApp({ type: "MAZA_INFRA_PROGRESS", step: "ERROR", detail: err.message });
      }
      await reportResult(task.id, { ok: false, error: err.message, screenshot });
      throw err;
    } finally {
      if (task.type === "INFRA_INJECT") {
        infraInjectInFlight = false;
      }
      globalThis.taskExecutionInProgress = null;
      globalThis.lastImmediateTask = null;
      chrome.storage.local.remove("lastImmediateTask");
    }
  } finally {
    isExecutingTask = false;
    globalThis.taskExecutionInProgress = null;
    globalThis.lastImmediateTask = null;
    chrome.storage.local.remove("lastImmediateTask");
  }
}
async function waitForTabComplete(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (tab?.status === "complete") return;
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, 3e4);
    const listener = (id, info) => {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}
async function reportResult(taskId, result) {
  const storage = await chrome.storage.local.get(["mazaToken", "mazaOrigin"]);
  const origin = storage.mazaOrigin?.replace(/\/$/, "") || "";
  const apiBase = origin ? `${origin}/api` : CONFIG.API_BASE_URL;
  let postId = result.post_id || null;
  if (!postId && result.published_url) {
    const match = result.published_url.match(/\/(\d+)\/?$/);
    if (match) postId = match[1];
  }
  await fetch(`${apiBase}/tasks/report`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${storage.mazaToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ taskId, postId, status: result.ok ? "success" : "failed", result })
  });
}
chrome.alarms.clear("maza-polling", () => {
  chrome.alarms.create("maza-polling", { periodInMinutes: 1 });
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "maza-polling") {
    pollingLoop();
  }
});
async function handleImmediateAction(msg, sendResponse) {
  const { actionType, payload } = msg;
  log("SYSTEM", `Immediate Action: ${actionType}, domain: "${payload.domain}", title: "${payload.title?.substring(0, 20)}"`);
  if (!payload.domain) {
    error("SYSTEM", "\u274C No domain in payload. Trying storage recovery...");
    const storage = await chrome.storage.local.get(["mazaSites"]);
    const sites = storage["mazaSites"] || [];
    if (sites.length > 0 && sites[0].domain) {
      payload.domain = sites[0].domain;
      log("SYSTEM", `[Recovery] Auto-recovered domain: ${payload.domain}`);
    } else {
      sendResponse({ ok: false, error: "\uC5F0\uACB0\uB41C \uBE14\uB85C\uADF8\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. \uB0B4 \uC0AC\uC774\uD2B8 \uBA54\uB274\uC5D0\uC11C \uBE14\uB85C\uADF8\uB97C \uB4F1\uB85D\uD574 \uC8FC\uC138\uC694." });
      return;
    }
  }
  let html = payload.content || payload.html || payload.body;
  if (actionType === "MAZA_INFRA_INJECT") {
    if (!isValidInfraHtml(html)) {
      html = buildInfraInjectionHtml(payload.sc_verification, payload.ga_measurement_id) || "";
    }
    if (!isValidInfraHtml(html)) {
      sendResponse({
        ok: false,
        error: "\uC8FC\uC785\uD560 \uC11C\uCE58\uCF58\uC194 \uB610\uB294 GA4 \uCF54\uB4DC\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. [\uAD6C\uAE00 \uC778\uD504\uB77C \uB3D9\uAE30\uD654] \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694."
      });
      return;
    }
  }
  const task = {
    id: payload.id || `immediate-${Date.now()}`,
    type: actionType === "MAZA_INFRA_INJECT" ? "INFRA_INJECT" : "PUBLISH_POST",
    platform: "tistory",
    url: actionType === "MAZA_INFRA_INJECT" ? `https://${payload.domain.split(".")[0]}.tistory.com/manage/design/skin/edit#/source/html` : payload.type === "page" ? `https://${payload.domain.split(".")[0]}.tistory.com/manage/page/write` : `https://${payload.domain.split(".")[0]}.tistory.com/manage/newpost`,
    domain: payload.domain,
    payload: {
      title: payload.title,
      html,
      type: payload.type,
      sc_verification: payload.sc_verification,
      ga_measurement_id: payload.ga_measurement_id
    }
  };
  globalThis.lastImmediateTask = task;
  chrome.storage.local.set({ lastImmediateTask: task });
  log("SYSTEM", `Task created: ${task.type} \u2192 ${task.domain}`);
  executeTask(task).catch((err) => {
    error("EXEC", `Immediate Task Failed: ${err.message}`);
  });
  sendResponse({ ok: true });
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "MAZA_SYNC_TOKEN") {
    const { token, origin } = msg.payload;
    log("SYSTEM", `Token synced from ${origin}.`);
    chrome.storage.local.set({
      "mazaToken": token,
      "mazaOrigin": origin,
      "last_sync": (/* @__PURE__ */ new Date()).toISOString()
    }).then(() => pollingLoop());
    sendResponse({ ok: true });
    return false;
  }
  if (msg.type === "TOKEN_UPDATED") {
    log("SYSTEM", "Token updated. Triggering immediate poll...");
    pollingLoop();
    return false;
  }
  if (msg.type === "MAZA_DOM_LOAD_FAILED") {
    error("SYSTEM", `Content script DOM module failed to load: ${msg.error} @ ${msg.url}`);
    relayToWebApp({
      type: "MAZA_CONTENT_ERROR",
      detail: "\uC5D0\uB514\uD130 \uBAA8\uB4C8 \uB85C\uB4DC \uC2E4\uD328 \u2014 \uD398\uC774\uC9C0\uB97C \uC0C8\uB85C\uACE0\uCE68 \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574\uC8FC\uC138\uC694.",
      error: msg.error
    });
    return false;
  }
  if (msg.type === "CAPTURE_SCREENSHOT") {
    captureErrorState().then((screenshot) => sendResponse({ ok: true, screenshot })).catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
  if (msg.type === "FORCE_POLLING") {
    log("SYSTEM", "Force Polling requested.");
    pollingLoop();
    return false;
  }
  if (msg.type === "MAZA_AUTOPILOT_SYNC") {
    chrome.runtime.sendMessage(msg).catch(() => {
    });
    return false;
  }
  if (msg.type === "FETCH_IMAGE") {
    fetch(msg.url).then((res) => res.blob()).then((blob) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        sendResponse({ ok: true, dataUrl: reader.result });
      };
      reader.readAsDataURL(blob);
    }).catch((err) => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }
  if (msg.type === "TASK_CONFIRMED_PUBLISHING") {
    const taskId = globalThis.taskExecutionInProgress;
    if (taskId) {
      log("SYSTEM", `Received TASK_CONFIRMED_PUBLISHING for task ${taskId}. Reporting success immediately.`);
      reportResult(taskId, { ok: true, status: "PUBLISHED", published_url: msg.publishedUrl }).catch(() => {
      });
    }
    return false;
  }
  if (msg.type === "IMMEDIATE_ACTION") {
    handleImmediateAction(msg, sendResponse).catch((err) => {
      error("SYSTEM", `handleImmediateAction failed: ${err.message}`);
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }
  if (msg.type === "CONTENT_SCRIPT_READY") {
    sendResponse({ received: true });
    if (globalThis.taskExecutionInProgress) {
      log("SYSTEM", `[Duplicate Guard] executeTask is in progress (${globalThis.taskExecutionInProgress}). Skipping reactive delivery.`);
      return true;
    }
    let task = globalThis.lastImmediateTask;
    if (!task) {
      chrome.storage.local.get("lastImmediateTask").then((storage) => {
        task = storage.lastImmediateTask;
        if (task && sender.tab?.id) {
          if (globalThis.taskExecutionInProgress) {
            log("SYSTEM", `[Duplicate Guard] executeTask started during async fetch. Skipping reactive delivery.`);
            return;
          }
          deliverTask(task, sender.tab.id);
        } else {
          log("SYSTEM", `READY received but NO TASK for tab ${sender.tab?.id}.`);
        }
      });
    } else if (sender.tab?.id) {
      deliverTask(task, sender.tab.id);
    }
    return true;
  }
  if (msg.type === "MAZA_INFRA_PROGRESS") {
    relayToWebApp(msg);
    return false;
  }
  if (msg.type === "MANUAL_INJECT_REQUEST") {
    const task = globalThis.lastImmediateTask;
    if (task) {
      chrome.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
        if (tabs[0]?.id) deliverTask(task, tabs[0].id, true);
      });
    }
    return false;
  }
  if (msg.type === "LOAD_MAIN_WORLD_SCRIPT") {
    if (sender.tab?.id) {
      chrome.scripting.executeScript({
        target: { tabId: sender.tab.id, allFrames: true },
        world: "MAIN",
        files: ["content/mainWorld.js"]
      }).then(() => {
        sendResponse({ ok: true });
      }).catch((err) => {
        sendResponse({ ok: false, error: err.message });
      });
      return true;
    }
    return false;
  }
  if (msg.type === "EXECUTE_MAIN_WORLD") {
    if (sender.tab?.id) {
      const func = msg.funcId === "autoAcceptDialog" ? () => {
        const _origConfirm = window.confirm;
        window.confirm = () => true;
        setTimeout(() => {
          window.confirm = _origConfirm;
        }, 3e3);
        return { ok: true };
      } : msg.funcId === "injectInfra" ? (html) => {
        try {
          const hasPayload = html && html !== "null" && html !== "undefined" && (html.includes("google-site-verification") || html.includes("googletagmanager.com/gtag"));
          if (!hasPayload) {
            return { ok: false, error: "EMPTY_INFRA_HTML" };
          }
          const processVal = (val) => {
            if (!val || val.length < 20) {
              return val.includes("<head>") ? val.replace("<head>", "<head>\n" + html) : html;
            }
            const regexNew = /<!-- Maza Infra -->[\s\S]*?<!-- End Maza Infra -->\n?/g;
            const withoutMaza = val.replace(regexNew, "");
            const alreadyHasSc = /google-site-verification/i.test(withoutMaza);
            const alreadyHasGa = /googletagmanager\.com\/gtag/i.test(withoutMaza);
            if (alreadyHasSc && alreadyHasGa && val.includes(html.trim().slice(0, 40))) {
              return null;
            }
            let cleaned = withoutMaza;
            return cleaned.includes("<head>") ? cleaned.replace("<head>", "<head>\n" + html) : html + "\n" + cleaned;
          };
          const cmEls = document.querySelectorAll(".CodeMirror");
          for (const el of Array.from(cmEls)) {
            if (el.CodeMirror) {
              const cm = el.CodeMirror;
              const newVal = processVal(cm.getValue());
              if (newVal === null) return { ok: true, step: "ALREADY_INJECTED" };
              cm.setValue(newVal);
              return { ok: true, step: "SUCCESS" };
            }
          }
          if (window.monaco?.editor) {
            const models = window.monaco.editor.getModels();
            if (models && models.length > 0) {
              const newVal = processVal(models[0].getValue());
              if (newVal === null) return { ok: true, step: "ALREADY_INJECTED" };
              models[0].setValue(newVal);
              return { ok: true, step: "SUCCESS" };
            }
          }
          const htmlTextarea = Array.from(document.querySelectorAll("textarea")).find(
            (t) => t.value.includes("<html") || t.value.includes("<!doctype")
          );
          if (htmlTextarea) {
            const newVal = processVal(htmlTextarea.value);
            if (newVal === null) return { ok: true, step: "ALREADY_INJECTED" };
            const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
            if (setter) setter.call(htmlTextarea, newVal);
            else htmlTextarea.value = newVal;
            htmlTextarea.dispatchEvent(new Event("input", { bubbles: true }));
            htmlTextarea.dispatchEvent(new Event("change", { bubbles: true }));
            return { ok: true, step: "SUCCESS" };
          }
          return { ok: false, error: "NO_EDITOR_FOUND" };
        } catch (err) {
          return { ok: false, error: err.message };
        }
      } : msg.funcId === "injectPostContent" ? (html) => {
        try {
          let injected = false;
          if (window.monaco?.editor) {
            const models = window.monaco.editor.getModels();
            if (models && models.length > 0) {
              models[0].setValue(html);
              injected = true;
            }
          } else if (document.querySelector(".CodeMirror")) {
            const el = document.querySelector(".CodeMirror");
            if (el && el.CodeMirror) {
              el.CodeMirror.setValue(html);
              injected = true;
            }
          }
          return { ok: injected, step: injected ? "SUCCESS" : "NO_EDITOR_FOUND" };
        } catch (err) {
          return { ok: false, error: err.message };
        }
      } : msg.funcId === "autoCancelDraftDialog" ? () => {
        const _origConfirm = window.confirm;
        window.confirm = (msg2) => {
          if (msg2) {
            if (msg2.includes("\uC800\uC7A5\uB41C \uAE00\uC774 \uC788\uC2B5\uB2C8\uB2E4") || msg2.includes("\uC774\uC5B4\uC11C \uC791\uC131")) {
              console.log("[MAZA Tistory] Auto-canceling native draft recovery dialog");
              return false;
            }
            if (msg2.includes("\uC791\uC131 \uBAA8\uB4DC\uB97C \uBCC0\uACBD") || msg2.includes("\uC11C\uC2DD\uC774 \uC720\uC9C0\uB418\uC9C0")) {
              console.log("[MAZA Tistory] Auto-confirming mode change dialog");
              return true;
            }
          }
          console.log("[MAZA Tistory] Auto-confirming unknown dialog:", msg2);
          return true;
        };
        return { ok: true };
      } : void 0;
      if (func) {
        chrome.scripting.executeScript({
          target: { tabId: sender.tab.id, allFrames: true },
          world: "MAIN",
          args: msg.args || [],
          func
        }).then((results) => {
          const validResult = results.find((r) => r.result)?.result;
          sendResponse(validResult || { ok: false, error: "No valid result from frames" });
        }).catch((err) => {
          sendResponse({ ok: false, error: err.message });
        });
        return true;
      }
    }
  }
  return false;
});
function deliverTask(task, tabId, proactive = false) {
  if (globalThis.taskExecutionInProgress && String(globalThis.taskExecutionInProgress) === String(task.id)) {
    log("SYSTEM", `[Duplicate Guard] Task ${task.id} already being executed by executeTask. Skipping deliverTask.`);
    return;
  }
  log("SYSTEM", `${proactive ? "[Proactive]" : "[Reactive]"} Delivering task ${task.id} to tab ${tabId}...`);
  chrome.runtime.sendMessage({ type: "TASK_PENDING", task }).catch(() => {
  });
  chrome.tabs.sendMessage(tabId, { type: "RUN_TASK", task }).then((response) => {
    if (!response) {
      log("SYSTEM", `No response from tab ${tabId}. Keeping task in memory.`);
      return;
    }
    const isFinished = response.status === "PUBLISHED" || response.status === "INJECTED" || response.status === "INJECTED_ONLY" || response.ok === false;
    if (isFinished) {
      log("SYSTEM", `Task ${task.id} finished: ${response.status || "ERROR"}. Clearing.`);
      reportResult(task.id, response).catch(() => {
      });
      globalThis.lastImmediateTask = null;
      chrome.storage.local.remove("lastImmediateTask");
      chrome.runtime.sendMessage({ type: "TASK_CLEARED" }).catch(() => {
      });
    } else if (response.status === "NAVIGATING_TO_EDITOR") {
      log("SYSTEM", `Tab ${tabId} navigating to editor. Preserving task.`);
    }
  }).catch((err) => {
    log("SYSTEM", `Delivery to tab ${tabId} failed: ${err.message}. Task kept in memory.`);
  });
}
async function relayToWebApp(message) {
  const tabs = await chrome.tabs.query({});
  const webAppTabs = tabs.filter(
    (t) => t.url?.includes("localhost") || t.url?.includes("mazastudio.kr")
  );
  for (const tab of webAppTabs) {
    if (tab.id) {
      chrome.tabs.sendMessage(tab.id, message).catch(() => {
      });
    }
  }
}
async function focusWebAppTab() {
  const tabs = await chrome.tabs.query({});
  const webAppTab = tabs.find(
    (t) => t.url?.includes("localhost") || t.url?.includes("mazastudio.kr")
  );
  if (webAppTab && webAppTab.id) {
    chrome.tabs.update(webAppTab.id, { active: true }).catch(() => {
    });
    if (webAppTab.windowId) {
      chrome.windows.update(webAppTab.windowId, { focused: true }).catch(() => {
      });
    }
  }
}
//# sourceMappingURL=background.js.map
