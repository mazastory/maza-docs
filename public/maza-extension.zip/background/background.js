var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// extension/shared/config.ts
var config_exports = {};
__export(config_exports, {
  CONFIG: () => CONFIG
});
var CONFIG;
var init_config = __esm({
  "extension/shared/config.ts"() {
    "use strict";
    CONFIG = {
      API_BASE_URL: "https://mazastudio.kr/api",
      STUDIO_URL: "https://mazastudio.kr",
      POLLING_INTERVAL_MS: 5e3,
      STUCK_TASK_THRESHOLD_MS: 15 * 60 * 1e3,
      FORCE_RESET_STUCK_TASK_THRESHOLD_MS: 2 * 60 * 1e3
    };
  }
});

// extension/core/logger.ts
var Logger, logger, log, error;
var init_logger = __esm({
  "extension/core/logger.ts"() {
    "use strict";
    Logger = class {
      logs = [];
      maxLogs = 500;
      // 메모리 제한
      isDev = true;
      // 개발 환경인 경우 콘솔 출력
      info(module, message, data) {
        this.log("info", module, message, data);
      }
      warn(module, message, data) {
        this.log("warn", module, message, data);
      }
      error(module, message, data) {
        this.log("error", module, message, data);
      }
      debug(module, message, data) {
        this.log("debug", module, message, data);
      }
      log(level, module, message, data) {
        const timestamp = (/* @__PURE__ */ new Date()).toISOString().split("T")[1].split("Z")[0];
        const formattedMsg = `[${timestamp}] [${module}] ${message}`;
        const entry = {
          timestamp: Date.now(),
          level,
          module,
          message,
          data
        };
        this.logs.push(entry);
        if (this.logs.length > this.maxLogs) {
          this.logs = this.logs.slice(-this.maxLogs);
        }
        const prefix = `[${module}]`;
        const styles = {
          "info": "color: #0ea5e9; font-weight: bold;",
          "warn": "color: #f59e0b; font-weight: bold;",
          "error": "color: #ef4444; font-weight: bold;",
          "debug": "color: #888; font-style: italic;"
        };
        if (this.isDev) {
          console.log(`%c${prefix} ${message}`, styles[level], data ?? "");
        }
        if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
          try {
            chrome.runtime.sendMessage(
              {
                type: "TASK_LOG",
                level,
                scope: module,
                message: formattedMsg,
                data
              },
              () => {
                void chrome.runtime.lastError;
              }
            );
          } catch (e) {
          }
        }
      }
      getLogs(filter) {
        return this.logs.filter((entry) => {
          if (filter?.module && entry.module !== filter.module) return false;
          if (filter?.level && entry.level !== filter.level) return false;
          return true;
        });
      }
      clearLogs() {
        this.logs = [];
      }
      exportLogs() {
        return JSON.stringify(this.logs, null, 2);
      }
    };
    logger = new Logger();
    log = Object.assign(
      ((module, msg, data) => logger.info(module, msg, data)),
      {
        info: (module, msg, data) => logger.info(module, msg, data),
        warn: (module, msg, data) => logger.warn(module, msg, data),
        error: (module, msg, data) => logger.error(module, msg, data),
        debug: (module, msg, data) => logger.debug(module, msg, data)
      }
    );
    error = (module, msg, data) => logger.error(module, msg, data);
  }
});

// extension/shared/types.ts
function isRecord(v) {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}
function isMazaTask(v) {
  if (!isRecord(v)) return false;
  const maybe = v;
  return typeof maybe.id === "string" && typeof maybe.type === "string" && typeof maybe.platform === "string" && typeof maybe.url === "string";
}
var init_types = __esm({
  "extension/shared/types.ts"() {
    "use strict";
  }
});

// extension/background/execution/taskStore.ts
var taskStore_exports = {};
__export(taskStore_exports, {
  TaskExecutionState: () => TaskExecutionState,
  clearLastImmediateTask: () => clearLastImmediateTask,
  clearTaskExecution: () => clearTaskExecution,
  getExecutingTaskId: () => getExecutingTaskId,
  getExecutingTaskStartTime: () => getExecutingTaskStartTime,
  getExecutingTaskTabId: () => getExecutingTaskTabId,
  getLastImmediateTask: () => getLastImmediateTask,
  hydrateLastImmediateTask: () => hydrateLastImmediateTask,
  isInfraInjectInFlight: () => isInfraInjectInFlight,
  isTaskExecutionInProgress: () => isTaskExecutionInProgress,
  resolveLastImmediateTask: () => resolveLastImmediateTask,
  setExecutingTaskTabId: () => setExecutingTaskTabId,
  setInfraInjectInFlight: () => setInfraInjectInFlight,
  setLastImmediateTask: () => setLastImmediateTask,
  startTaskExecution: () => startTaskExecution,
  taskExecutionState: () => taskExecutionState,
  tryStartTaskExecution: () => tryStartTaskExecution
});
function isTaskExecutionInProgress() {
  return taskExecutionState.isTaskExecutionInProgress();
}
function getExecutingTaskId() {
  return taskExecutionState.getExecutingTaskId();
}
function getExecutingTaskTabId() {
  return taskExecutionState.getExecutingTaskTabId();
}
function getExecutingTaskStartTime() {
  return taskExecutionState.getExecutingTaskStartTime();
}
function startTaskExecution(taskId) {
  taskExecutionState.startTaskExecution(taskId);
}
function tryStartTaskExecution(taskId) {
  return taskExecutionState.tryStartTaskExecution(taskId);
}
function setExecutingTaskTabId(tabId) {
  taskExecutionState.setExecutingTaskTabId(tabId);
}
function clearTaskExecution(taskId) {
  taskExecutionState.clearTaskExecution(taskId);
}
async function setLastImmediateTask(task) {
  await taskExecutionState.setLastImmediateTask(task);
}
async function clearLastImmediateTask() {
  await taskExecutionState.clearLastImmediateTask();
}
function getLastImmediateTask() {
  return taskExecutionState.getLastImmediateTask();
}
async function hydrateLastImmediateTask() {
  return taskExecutionState.hydrateLastImmediateTask();
}
async function resolveLastImmediateTask() {
  return taskExecutionState.resolveLastImmediateTask();
}
function isInfraInjectInFlight() {
  return taskExecutionState.isInfraInjectInFlight();
}
function setInfraInjectInFlight(value) {
  taskExecutionState.setInfraInjectInFlight(value);
}
var TaskExecutionState, taskExecutionState;
var init_taskStore = __esm({
  "extension/background/execution/taskStore.ts"() {
    "use strict";
    init_types();
    TaskExecutionState = class {
      executingTaskId = null;
      executingTaskTabId = null;
      executingTaskStartTime = null;
      lastImmediateTask = null;
      infraInjectInFlight = false;
      isTaskExecutionInProgress() {
        return this.executingTaskId !== null;
      }
      getExecutingTaskId() {
        return this.executingTaskId;
      }
      getExecutingTaskTabId() {
        return this.executingTaskTabId;
      }
      getExecutingTaskStartTime() {
        return this.executingTaskStartTime;
      }
      startTaskExecution(taskId) {
        this.executingTaskId = taskId;
        this.executingTaskStartTime = Date.now();
      }
      tryStartTaskExecution(taskId) {
        if (this.executingTaskId !== null) return false;
        this.startTaskExecution(taskId);
        return true;
      }
      setExecutingTaskTabId(tabId) {
        this.executingTaskTabId = tabId;
      }
      clearTaskExecution(taskId) {
        if (!taskId || this.executingTaskId === taskId) {
          this.executingTaskId = null;
          this.executingTaskTabId = null;
          this.executingTaskStartTime = null;
        }
      }
      async setLastImmediateTask(task) {
        this.lastImmediateTask = task;
        await chrome.storage.local.set({ lastImmediateTask: task });
      }
      async clearLastImmediateTask() {
        this.lastImmediateTask = null;
        await chrome.storage.local.remove("lastImmediateTask");
      }
      getLastImmediateTask() {
        return this.lastImmediateTask;
      }
      async hydrateLastImmediateTask() {
        const storage = await chrome.storage.local.get("lastImmediateTask");
        this.lastImmediateTask = isMazaTask(storage.lastImmediateTask) ? storage.lastImmediateTask : null;
        return this.lastImmediateTask;
      }
      async resolveLastImmediateTask() {
        if (this.lastImmediateTask) return this.lastImmediateTask;
        const storage = await chrome.storage.local.get("lastImmediateTask");
        return isMazaTask(storage.lastImmediateTask) ? storage.lastImmediateTask : null;
      }
      isInfraInjectInFlight() {
        return this.infraInjectInFlight;
      }
      setInfraInjectInFlight(value) {
        this.infraInjectInFlight = value;
      }
    };
    taskExecutionState = new TaskExecutionState();
  }
});

// extension/background/tabManager.ts
function isLoginOrAuthUrl(url) {
  return url.includes("/auth/login") || url.includes("accounts.kakao.com") || url.includes("auth.kakao.com") || url.includes("kauth.kakao.com");
}
async function waitForTabComplete(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (tab?.status === "complete") return;
  return new Promise((resolve) => {
    const alarmName = `maza-wait-tab-complete-${tabId}`;
    let settled = false;
    const cleanup = () => {
      if (settled) return;
      settled = true;
      chrome.tabs.onUpdated.removeListener(listener);
      chrome.alarms.onAlarm.removeListener(alarmListener);
      chrome.alarms.clear(alarmName);
    };
    const finish = () => {
      cleanup();
      resolve();
    };
    const listener = (id, info) => {
      if (id === tabId && info.status === "complete") {
        finish();
      }
    };
    const alarmListener = (alarm) => {
      if (alarm.name === alarmName) {
        finish();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
    chrome.alarms.onAlarm.addListener(alarmListener);
    chrome.alarms.create(alarmName, { delayInMinutes: 0.05 });
  });
}
async function getManagePageShellStatus(tabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    func: () => {
      const blockedMarkers = [
        "\uC798\uBABB\uB41C \uC694\uCCAD\uC785\uB2C8\uB2E4",
        "\uC798\uBABB\uB41C \uC811\uADFC",
        "\uC11C\uBE44\uC2A4 \uC774\uC6A9\uC5D0 \uBD88\uD3B8",
        "\uACFC\uB3C4\uD55C \uC811\uADFC \uC694\uCCAD\uC73C\uB85C",
        "\uC774 \uD398\uC774\uC9C0\uB294 \uC0AC\uC6A9\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4",
        "\uC624\uB958\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4",
        "\uC790\uB3D9\uD654\uB41C \uC811\uADFC",
        "\uC790\uB3D9\uD654\uB41C \uC811\uADFC \uC694\uCCAD",
        "IP \uC8FC\uC18C",
        "\uBE14\uB85C\uADF8 \uC0AC\uC6A9\uC774 \uC7A0\uC2DC \uC911\uB2E8\uB418\uC5C8\uC2B5\uB2C8\uB2E4",
        "Too Many Requests",
        "429"
      ];
      const collectFrame = (root) => {
        const body = root.body || null;
        const text = root instanceof Document ? root.documentElement?.innerText || body?.innerText || "" : "";
        const markerText = text.trim();
        const hasEditable = !!root.querySelector("[contenteditable], textarea, iframe");
        const blocked = blockedMarkers.some((marker) => markerText.includes(marker));
        return {
          readyState: root instanceof Document ? document.readyState : "complete",
          bodyChildCount: body?.childElementCount ?? 0,
          bodyLength: markerText.length,
          hasEditable,
          titleLength: document.title?.trim().length ?? 0,
          blocked,
          markerText
        };
      };
      const frames = Array.from(document.querySelectorAll("iframe"));
      const frameResults = [collectFrame(document)];
      for (const iframe of frames) {
        try {
          const doc = iframe.contentDocument || iframe.contentWindow?.document;
          if (doc) frameResults.push(collectFrame(doc));
        } catch {
        }
      }
      return frameResults;
    }
  });
  return Array.isArray(results) ? results.flatMap((r) => (Array.isArray(r.result) ? r.result : [r.result]).filter((x) => Boolean(x))) : [];
}
async function ensureInjectorOnTab(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "MAZA_PING" });
    return;
  } catch {
  }
  await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    files: ["content/injector.js"]
  });
  await new Promise((resolve) => setTimeout(resolve, 800));
}
async function runTaskOnTab(tabId, task) {
  await ensureInjectorOnTab(tabId);
  try {
    return await chrome.tabs.sendMessage(tabId, { type: "DELIVER", task });
  } catch (msgErr) {
    const errMsg = msgErr instanceof Error ? msgErr.message : String(msgErr);
    if (errMsg.includes("establish connection") || errMsg.includes("Receiving end")) {
      await ensureInjectorOnTab(tabId);
      return await chrome.tabs.sendMessage(tabId, { type: "DELIVER", task });
    }
    throw msgErr;
  }
}
async function waitForTistoryManagePage(tabId, task) {
  const skinUrl = task.url;
  const deadline = Date.now() + 35e3;
  let initialBlockedCheckDone = false;
  let emptyShellFirstSeenAt = 0;
  let emptyShellReloaded = false;
  let loginAuthFirstSeenAt = 0;
  let loginWaitNotified = false;
  while (Date.now() < deadline) {
    let tab;
    try {
      tab = await chrome.tabs.get(tabId);
    } catch (e) {
      throw new Error(`\uC791\uC131 \uC911\uC778 \uD0ED(ID: ${tabId})\uC774 \uC0AC\uC6A9\uC790\uC5D0 \uC758\uD574 \uB2EB\uD614\uAC70\uB098 \uC720\uC2E4\uB418\uC5C8\uC2B5\uB2C8\uB2E4.`);
    }
    const url = tab?.url || "";
    console.debug("[MAZA BG] waitForTistoryManagePage tick", {
      tabId,
      url,
      taskType: task.type
    });
    if (!initialBlockedCheckDone && url.includes("/manage/")) {
      initialBlockedCheckDone = true;
      const statuses = await getManagePageShellStatus(tabId);
      const blocked = statuses.some((s) => s.blocked);
      if (blocked) {
        throw new Error("Tistory \uC811\uADFC \uCC28\uB2E8 \uD398\uC774\uC9C0\uAC00 \uAC10\uC9C0\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");
      }
    }
    if (isLoginOrAuthUrl(url)) {
      const now = Date.now();
      if (!loginAuthFirstSeenAt) {
        loginAuthFirstSeenAt = now;
      }
      try {
        const storage = await chrome.storage.local.get(["mazaToken", "lastSignedInAt"]);
        const token = storage.mazaToken;
        const lastSigned = typeof storage.lastSignedInAt === "number" ? storage.lastSignedInAt : typeof storage.lastSignedInAt === "string" ? Number(storage.lastSignedInAt) : 0;
        if (token || lastSigned && now - lastSigned < 3e4) {
          console.debug("[MAZA BG] login page seen but token/lastSignedInAt present; waiting for redirect instead of spamming WAITING_LOGIN", { token: !!token, lastSignedAgoMs: token ? 0 : now - lastSigned });
          await waitForTabComplete(tabId);
          continue;
        }
      } catch (e) {
        console.debug("[MAZA BG] storage check failed while handling login URL", e);
      }
      if (now - loginAuthFirstSeenAt < 3e4) {
        await waitForTabComplete(tabId);
        continue;
      }
      if (!loginWaitNotified) {
        relayToWebApp({
          type: "MAZA_INFRA_PROGRESS",
          step: "WAITING_LOGIN",
          detail: "\uCE74\uCE74\uC624/\uD2F0\uC2A4\uD1A0\uB9AC \uB85C\uADF8\uC778\uC744 \uC644\uB8CC\uD574 \uC8FC\uC138\uC694. \uC644\uB8CC \uD6C4 \uC790\uB3D9\uC73C\uB85C HTML \uD3B8\uC9D1 \uD654\uBA74\uC73C\uB85C \uC774\uB3D9\uD569\uB2C8\uB2E4."
        });
        loginWaitNotified = true;
      }
      await waitForTabComplete(tabId);
      continue;
    }
    loginAuthFirstSeenAt = 0;
    loginWaitNotified = false;
    if (url.includes("tistory.com") && !url.includes("/manage/")) {
      await chrome.tabs.update(tabId, { url: skinUrl });
      await waitForTabComplete(tabId);
      continue;
    }
    if (url.includes("/manage/")) {
      if (task.type === "INFRA_INJECT" && !url.includes("skin/edit")) {
        await chrome.tabs.update(tabId, { url: skinUrl });
        await waitForTabComplete(tabId);
      } else if (task.type === "PUBLISH_POST") {
        try {
          const expectedPath = new URL(skinUrl).pathname.replace(/\/$/, "");
          const currentPath = new URL(url).pathname.replace(/\/$/, "");
          const isEditorRedirectForNewPost = expectedPath.includes("/manage/newpost") && /\/manage\/post\/(write|\d+\/edit)/.test(currentPath);
          const isPageRedirect = /\/manage\/pages?$/.test(expectedPath) && /\/manage\/pages?(?:\/(?:write|\d+\/edit))?$/.test(currentPath) || /\/manage\/page$/.test(expectedPath);
          if (isEditorRedirectForNewPost || isPageRedirect) {
            const statuses2 = await getManagePageShellStatus(tabId);
            const blocked2 = statuses2.some((s) => s.blocked);
            const emptyShell2 = statuses2.every((s) => s.bodyLength === 0 && s.bodyChildCount === 0 && !s.hasEditable);
            console.debug("[MAZA BG] publish redirect shell status", {
              tabId,
              url,
              blocked: blocked2,
              emptyShell: emptyShell2,
              statuses: statuses2
            });
            if (blocked2) {
              throw new Error("Tistory \uC811\uADFC \uCC28\uB2E8 \uD398\uC774\uC9C0\uAC00 \uAC10\uC9C0\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");
            }
            if (emptyShell2) {
              const now = Date.now();
              if (!emptyShellFirstSeenAt) {
                emptyShellFirstSeenAt = now;
              }
              if (!emptyShellReloaded && now - emptyShellFirstSeenAt > 4e3) {
                emptyShellReloaded = true;
                await chrome.tabs.reload(tabId);
                await waitForTabComplete(tabId);
                continue;
              }
              if (emptyShellReloaded && now - emptyShellFirstSeenAt > 1e4) {
                throw new Error("Tistory \uD398\uC774\uC9C0\uAC00 \uB85C\uB4DC\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4 (\uBE48 \uD654\uBA74). \uC77C\uC2DC\uC801\uC778 IP \uCC28\uB2E8(429)\uC774\uAC70\uB098 \uC11C\uBC84 \uC624\uB958\uC77C \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");
              }
              await new Promise((resolve) => setTimeout(resolve, 500));
              continue;
            }
            return;
          }
          if (!currentPath.includes(expectedPath)) {
            await chrome.tabs.update(tabId, { url: skinUrl });
            await waitForTabComplete(tabId);
            continue;
          }
        } catch (e) {
        }
      }
      const statuses = await getManagePageShellStatus(tabId);
      const blocked = statuses.some((s) => s.blocked);
      const emptyShell = statuses.every((s) => s.bodyLength === 0 && s.bodyChildCount === 0 && !s.hasEditable);
      console.debug("[MAZA BG] manage page shell status", {
        tabId,
        url,
        blocked,
        emptyShell,
        statuses
      });
      if (blocked) {
        throw new Error("Tistory \uC811\uADFC \uCC28\uB2E8 \uD398\uC774\uC9C0\uAC00 \uAC10\uC9C0\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");
      }
      if (emptyShell) {
        const now = Date.now();
        if (!emptyShellFirstSeenAt) {
          emptyShellFirstSeenAt = now;
        }
        if (!emptyShellReloaded && now - emptyShellFirstSeenAt > 4e3) {
          emptyShellReloaded = true;
          await chrome.tabs.reload(tabId);
          await waitForTabComplete(tabId);
          continue;
        }
        if (emptyShellReloaded && now - emptyShellFirstSeenAt > 1e4) {
          throw new Error("Tistory \uD398\uC774\uC9C0\uAC00 \uB85C\uB4DC\uB418\uC9C0 \uC54A\uC2B5\uB2C8\uB2E4 (\uBE48 \uD654\uBA74). \uC77C\uC2DC\uC801\uC778 IP \uCC28\uB2E8(429)\uC774\uAC70\uB098 \uC11C\uBC84 \uC624\uB958\uC77C \uC218 \uC788\uC2B5\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");
        }
        await new Promise((resolve) => setTimeout(resolve, 500));
        continue;
      }
      return;
    }
    await chrome.tabs.update(tabId, { url: skinUrl });
    await waitForTabComplete(tabId);
  }
  throw new Error("\uD2F0\uC2A4\uD1A0\uB9AC \uB85C\uADF8\uC778 \uB610\uB294 \uC2A4\uD0A8 HTML \uD3B8\uC9D1 \uD654\uBA74 \uC9C4\uC785 \uC2DC\uAC04\uC774 \uCD08\uACFC\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uB85C\uADF8\uC778 \uD6C4 \uB2E4\uC2DC [\uC790\uB3D9 \uC8FC\uC785 \uC2DC\uC791]\uC744 \uB20C\uB7EC\uC8FC\uC138\uC694.");
}
async function relayToWebApp(message) {
  const staticAny = relayToWebApp;
  if (!staticAny._lastProgressSent) staticAny._lastProgressSent = /* @__PURE__ */ new Map();
  const lastProgressSent = staticAny._lastProgressSent;
  const storage = await chrome.storage.local.get(["mazaOrigin"]);
  const storedOrigin = storage.mazaOrigin || "";
  const storedHostname = storedOrigin ? new URL(storedOrigin.startsWith("http") ? storedOrigin : `https://${storedOrigin}`).hostname : "";
  const tabs = await chrome.tabs.query({});
  const webAppTabs = tabs.filter((t) => {
    if (!t.url) return false;
    if (t.url.includes("localhost") || t.url.includes("127.0.0.1")) return true;
    if (t.url.includes("mazastudio.kr")) return true;
    if (storedHostname && t.url.includes(storedHostname)) return true;
    return false;
  });
  const maybeType = typeof message.type === "string" ? message.type : "";
  const maybeStep = typeof message.step === "string" ? message.step : "";
  if (maybeType === "MAZA_INFRA_PROGRESS" && maybeStep === "WAITING_LOGIN") {
    const key = `${maybeType}:${maybeStep}`;
    const now = Date.now();
    const prev = lastProgressSent.get(key) || 0;
    if (now - prev < 8e3) {
      console.debug("[MAZA BG] Skipping duplicate WAITING_LOGIN relay (debounced).");
      return;
    }
    lastProgressSent.set(key, now);
  }
  console.debug("[MAZA BG] relayToWebApp", { message, webAppTabCount: webAppTabs.length, storedHostname });
  for (const tab of webAppTabs) {
    if (tab.id) {
      try {
        chrome.tabs.sendMessage(tab.id, message, () => {
          void chrome.runtime.lastError;
        });
      } catch {
      }
    }
  }
}
async function focusWebAppTab() {
  const storage = await chrome.storage.local.get(["mazaOrigin"]);
  const storedOrigin = storage.mazaOrigin || "";
  const storedHostname = storedOrigin ? new URL(storedOrigin.startsWith("http") ? storedOrigin : `https://${storedOrigin}`).hostname : "";
  const tabs = await chrome.tabs.query({});
  const webAppTab = tabs.find((t) => {
    if (!t.url) return false;
    if (t.url.includes("localhost") || t.url.includes("127.0.0.1")) return true;
    if (t.url.includes("mazastudio.kr")) return true;
    if (storedHostname && t.url.includes(storedHostname)) return true;
    return false;
  });
  if (webAppTab?.id) {
    chrome.tabs.update(webAppTab.id, { active: true }).catch(() => {
    });
    if (webAppTab.windowId) {
      chrome.windows.update(webAppTab.windowId, { focused: true }).catch(() => {
      });
    }
  }
}
var init_tabManager = __esm({
  "extension/background/tabManager.ts"() {
    "use strict";
  }
});

// extension/background/fallback/pollingFallback.ts
var pollingFallback_exports = {};
__export(pollingFallback_exports, {
  initPollingAlarmListener: () => initPollingAlarmListener,
  pollingLoop: () => pollingLoop,
  registerPollingAlarm: () => registerPollingAlarm,
  registerTaskExecutor: () => registerTaskExecutor,
  resetPollingState: () => resetPollingState,
  setWebSocketConnectedProvider: () => setWebSocketConnectedProvider,
  updatePollingInterval: () => updatePollingInterval
});
function setWebSocketConnectedProvider(provider) {
  isWebSocketConnectedProvider = provider;
}
function registerTaskExecutor(executor) {
  taskExecutor = executor;
}
function resetPollingState() {
  idleCount = 0;
  updatePollingInterval(1);
}
function initPollingAlarmListener() {
  if (!chrome?.alarms?.onAlarm) {
    console.warn("[pollingFallback] chrome.alarms not available \u2014 polling alarm listener skipped.");
    return;
  }
  if (pollingAlarmRegistered) return;
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === POLLING_ALARM_NAME) {
      pollingLoop();
    }
  });
  pollingAlarmRegistered = true;
}
function registerPollingAlarm() {
  chrome.alarms.clear(POLLING_ALARM_NAME, () => {
    updatePollingInterval(1);
    chrome.alarms.create(POLLING_ALARM_NAME, { periodInMinutes: 1 });
  });
}
function updatePollingInterval(minutes) {
  if (currentPollingInterval === minutes) return;
  currentPollingInterval = minutes;
  chrome.alarms.create(POLLING_ALARM_NAME, { periodInMinutes: minutes });
  log("SYSTEM", `[Cost Optimization] Polling interval changed to ${minutes} min`);
}
async function pollingLoop(force = false, _forceRetryCount = 0) {
  if (_isPollingActive) {
    if (force && _forceRetryCount < 3) {
      log("POLLING", `\u26A1 Force poll requested but polling active. Retrying in 3s... (attempt ${_forceRetryCount + 1}/3)`);
      setTimeout(() => pollingLoop(true, _forceRetryCount + 1), 3e3);
    } else if (force) {
      log("POLLING", "\u26A1 Force poll: max retries reached. Giving up.");
    }
    return;
  }
  const now = Date.now();
  const sessionState = await chrome.storage.session.get([LAST_POLL_TIME_KEY]).catch(() => ({}));
  const persistedLastPollTime = typeof sessionState[LAST_POLL_TIME_KEY] === "number" ? sessionState[LAST_POLL_TIME_KEY] : 0;
  const effectiveLastPollTime = Math.max(_lastPollTime, persistedLastPollTime);
  if (!force && now - effectiveLastPollTime < 5e3) {
    log("POLLING", "Skipping polling: throttled (5s cooldown)");
    return;
  }
  const { getLastImmediateTask: getLastImmediateTask2 } = await Promise.resolve().then(() => (init_taskStore(), taskStore_exports));
  const lastImmediate = await getLastImmediateTask2();
  if (isTaskExecutionInProgress() || lastImmediate) {
    const startTime = getExecutingTaskStartTime() || 0;
    const stuckMs = startTime > 0 ? Date.now() - startTime : Number.POSITIVE_INFINITY;
    const stuckMinutes = stuckMs === Number.POSITIVE_INFINITY ? Number.POSITIVE_INFINITY : stuckMs / 6e4;
    const staleExecutionThresholdMs = force ? CONFIG.FORCE_RESET_STUCK_TASK_THRESHOLD_MS : CONFIG.STUCK_TASK_THRESHOLD_MS;
    if (stuckMs >= staleExecutionThresholdMs) {
      log("POLLING", `\u26A0\uFE0F Task flag stuck for ${Number.isFinite(stuckMinutes) ? Math.round(stuckMinutes) : "unknown"} minutes. Force resetting...`);
      clearTaskExecution();
      const { clearLastImmediateTask: clearLastImmediateTask2 } = await Promise.resolve().then(() => (init_taskStore(), taskStore_exports));
      await clearLastImmediateTask2();
    } else {
      log("POLLING", `\u23F8\uFE0F Task or Immediate action executing (${Number.isFinite(stuckMinutes) ? Math.round(stuckMinutes) : "unknown"} min), skipping poll`);
      return;
    }
  }
  _isPollingActive = true;
  _lastPollTime = now;
  chrome.storage.session.set({ [LAST_POLL_TIME_KEY]: now }).catch(() => {
  });
  try {
    const storage = await chrome.storage.local.get(["mazaToken", "mazaOrigin"]);
    if (!storage.mazaToken) {
      log("POLLING", "\u26A0\uFE0F No token available");
      return;
    }
    const origin = storage.mazaOrigin?.replace(/\/$/, "") || "";
    const apiBase = origin ? `${origin}/api` : CONFIG.API_BASE_URL;
    if (!force && isWebSocketConnectedProvider?.()) {
      log("POLLING", "WS connected; skipping HTTP polling.");
      return;
    }
    if (force) {
      log("POLLING", "\u26A1 Force poll: bypassing WS check, doing HTTP fetch.");
    }
    log("POLLING", `Fetching next task from ${apiBase}/tasks/next`);
    const res = await fetch(`${apiBase}/tasks/next`, {
      cache: "no-store",
      headers: { "Authorization": `Bearer ${storage.mazaToken}` }
    });
    if (res.status === 401 || res.status === 403) {
      log("POLLING", `\u274C Auth error ${res.status} \u2014 token may be expired. Skipping.`);
      return;
    }
    if (res.status === 200) {
      const contentType = res.headers.get("content-type") || "";
      if (!contentType.includes("application/json")) {
        const preview = (await res.text()).substring(0, 80);
        log("POLLING", `\u26A0\uFE0F Non-JSON response ignored (${contentType}): ${preview}`);
        return;
      }
      const text = await res.text();
      let result;
      try {
        result = JSON.parse(text);
      } catch (e) {
        log("POLLING", `\u274C JSON parse failed. Preview: ${text.substring(0, 80)}`);
        return;
      }
      if (result.success && result.command === "EXECUTE") {
        idleCount = 0;
        updatePollingInterval(1);
        const task = result.data;
        log("POLLING", `\u2705 Task Found: ${task.type}`, task.id);
        if (taskExecutor) {
          await taskExecutor(task);
        }
      } else if (result.success && result.command === "IDLE") {
        idleCount++;
        log("POLLING", `\u23F8\uFE0F IDLE: ${result.message || "No ready tasks"} (Idle count: ${idleCount})`);
        if (idleCount >= 3) {
          updatePollingInterval(5);
        }
      } else {
        log("POLLING", `\u26A0\uFE0F Unexpected response: ${JSON.stringify(result).substring(0, 80)}`);
      }
    } else if (res.status === 429) {
      log("POLLING", `\u26A0\uFE0F HTTP 429 Too Many Requests \u2014 backing off polling for this client`);
      try {
        relayToWebApp({ type: "MAZA_INFRA_PROGRESS", step: "ERROR", detail: "Remote host returned 429 Too Many Requests" });
      } catch (e) {
      }
      updatePollingInterval(60);
    } else {
      log("POLLING", `\u26A0\uFE0F HTTP ${res.status}`);
    }
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : String(err);
    if (errorMessage.includes("Failed to fetch") || errorMessage.includes("Load failed")) {
      log("POLLING", "\u{1F50C} Network error (expected for offline mode)");
      return;
    }
    error("POLLING", `\u274C Polling loop error: ${errorMessage}`);
  } finally {
    _isPollingActive = false;
  }
}
var taskExecutor, idleCount, currentPollingInterval, LAST_POLL_TIME_KEY, POLLING_ALARM_NAME, isWebSocketConnectedProvider, pollingAlarmRegistered, _isPollingActive, _lastPollTime;
var init_pollingFallback = __esm({
  "extension/background/fallback/pollingFallback.ts"() {
    "use strict";
    init_config();
    init_logger();
    init_tabManager();
    init_taskStore();
    taskExecutor = null;
    idleCount = 0;
    currentPollingInterval = 1;
    LAST_POLL_TIME_KEY = "mazaLastPollTime";
    POLLING_ALARM_NAME = "maza-polling";
    isWebSocketConnectedProvider = null;
    pollingAlarmRegistered = false;
    _isPollingActive = false;
    _lastPollTime = 0;
  }
});

// extension/background/background.ts
init_config();
init_logger();

// extension/utils/screenshot.ts
async function captureErrorState() {
  try {
    return await chrome.tabs.captureVisibleTab({ format: "png" });
  } catch (e) {
    return null;
  }
}

// extension/background/connection/wsClient.ts
init_config();
init_logger();
init_types();
init_taskStore();
var WS_RECONNECT_MS = 15e3;
var WS_RECONNECT_ALARM = "maza-ws-reconnect";
var ConnectionManager = class {
  wsConnection = null;
  wsConnected = false;
  wsConnecting = false;
  reset() {
    this.wsConnected = false;
    this.wsConnecting = false;
    this.wsConnection = null;
  }
  isConnected() {
    return this.wsConnection !== null && this.wsConnection.readyState === WebSocket.OPEN && this.wsConnected;
  }
  isConnecting() {
    return this.wsConnecting;
  }
  canConnect() {
    return (this.wsConnection === null || this.wsConnection.readyState !== WebSocket.OPEN) && !this.wsConnecting;
  }
  getConnection() {
    return this.wsConnection;
  }
  setConnection(connection) {
    this.wsConnection = connection;
  }
  setConnected(value) {
    this.wsConnected = value;
  }
  setConnecting(value) {
    this.wsConnecting = value;
  }
};
var connectionManager = new ConnectionManager();
var taskHandler = null;
var resetPollingStateHandler = null;
function resetWebSocketState() {
  connectionManager.reset();
}
function setResetPollingStateHandler(handler) {
  resetPollingStateHandler = handler;
}
function isLocalDevHost(hostname) {
  return hostname === "localhost" || hostname === "127.0.0.1" || hostname === "::1";
}
function getWebSocketUrl(origin) {
  try {
    const baseOrigin = origin ? origin.replace(/\/$/, "") : CONFIG.API_BASE_URL.replace(/\/api$/, "");
    const url = new URL(baseOrigin);
    if (isLocalDevHost(url.hostname) && (!url.port || ["5173", "5174", "5175"].includes(url.port))) {
      url.protocol = "ws:";
      url.hostname = "127.0.0.1";
      url.port = "3001";
      url.pathname = "/ws";
      url.search = "";
      return url.toString();
    }
    url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
    url.pathname = "/ws";
    url.search = "";
    return url.toString();
  } catch {
    const fallback = CONFIG.API_BASE_URL.replace(/^https?/, "wss").replace(/\/api$/, "/ws");
    if (fallback.includes("localhost") || fallback.includes("127.0.0.1")) {
      return fallback.replace(/:\d+/, ":3001");
    }
    return fallback;
  }
}
function sendWebSocketMessage(message) {
  const connection = connectionManager.getConnection();
  if (connection?.readyState === WebSocket.OPEN) {
    connection.send(JSON.stringify(message));
  }
}
function clearWebSocketReconnectAlarm() {
  chrome.alarms.clear(WS_RECONNECT_ALARM);
}
function scheduleWebSocketReconnect() {
  clearWebSocketReconnectAlarm();
  chrome.alarms.create(WS_RECONNECT_ALARM, {
    delayInMinutes: WS_RECONNECT_MS / 6e4
  });
}
function initWebSocketAlarmListener() {
  if (!chrome?.alarms?.onAlarm) {
    console.warn("[wsClient] chrome.alarms not available \u2014 WS reconnect alarm skipped.");
    return;
  }
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name !== WS_RECONNECT_ALARM) return;
    connectWebSocket().catch(() => {
    });
  });
}
function handleWebSocketMessage(raw) {
  let message;
  try {
    message = JSON.parse(raw);
  } catch {
    return;
  }
  if (!isRecord(message) || typeof message.type !== "string") return;
  if (message.type === "PING") {
    sendWebSocketMessage({ type: "PONG" });
    return;
  }
  if ((message.type === "DELIVER" || message.type === "RUN_TASK") && isRecord(message.task) && taskHandler) {
    if (isTaskExecutionInProgress()) {
      log("WS", `Skipping WS task delivery while another task is active: ${String(message.task.id)}`);
      return;
    }
    if (isMazaTask(message.task)) {
      log("WS", `Received WS task: ${message.task.id}`);
      taskHandler(message.task).catch((err) => log("WS", `WebSocket task execution failed: ${err instanceof Error ? err.message : String(err)}`));
    }
    return;
  }
  if (message.type === "SYSTEM_HEALTH_UPDATE") {
    return;
  }
  if (message.type === "TASK_AVAILABLE") {
    log("WS", "\u26A1 TASK_AVAILABLE signal received. Triggering immediate force poll...");
    Promise.resolve().then(() => (init_pollingFallback(), pollingFallback_exports)).then(({ pollingLoop: pollingLoop2 }) => {
      pollingLoop2(true).catch((err) => log("WS", `Force poll failed: ${err instanceof Error ? err.message : String(err)}`));
    }).catch(() => {
    });
    return;
  }
  log("WS", `Received unknown WS message type: ${message.type}`);
}
async function connectWebSocket() {
  if (!connectionManager.canConnect()) return;
  const storage = await chrome.storage.local.get(["mazaToken", "mazaOrigin"]);
  const token = storage.mazaToken;
  const origin = storage.mazaOrigin || "";
  if (!token) {
    log("WS", "No auth token available. WebSocket connection skipped.");
    return;
  }
  if (connectionManager.isConnected()) {
    log("WS", "WebSocket already connected, refreshing extension registration.");
    sendWebSocketMessage({ type: "EXTENSION_CONNECTED", token });
    return;
  }
  const wsUrl = getWebSocketUrl(origin);
  log("WS", `Connecting to WebSocket: ${wsUrl}`);
  connectionManager.setConnecting(true);
  const wsConnection = new WebSocket(wsUrl);
  connectionManager.setConnection(wsConnection);
  wsConnection.onopen = () => {
    connectionManager.setConnected(true);
    connectionManager.setConnecting(false);
    log("WS", "WebSocket connected");
    sendWebSocketMessage({ type: "EXTENSION_CONNECTED", token });
  };
  wsConnection.onmessage = (event) => {
    handleWebSocketMessage(event.data);
  };
  wsConnection.onclose = () => {
    if (connectionManager.isConnected() || connectionManager.isConnecting()) {
      log("WS", "WebSocket disconnected. Scheduling reconnect.");
    }
    resetWebSocketState();
    resetPollingStateHandler?.();
    scheduleWebSocketReconnect();
  };
  wsConnection.onerror = () => {
    log("WS", "WebSocket error occurred.");
    connectionManager.setConnected(false);
    if (wsConnection.readyState !== WebSocket.OPEN) {
      connectionManager.setConnecting(false);
    }
    resetPollingStateHandler?.();
  };
}
function registerTaskHandler(handler) {
  taskHandler = handler;
}
function isWebSocketConnected() {
  return connectionManager.isConnected();
}

// extension/background/execution/taskRouter.ts
init_logger();
init_types();
init_tabManager();
init_pollingFallback();
init_taskStore();
function normalizeTistoryDomain(domain) {
  const trimmed = domain.trim();
  if (!trimmed) return "";
  try {
    const url = new URL(trimmed.includes("://") ? trimmed : `https://${trimmed}`);
    return url.hostname.replace(/^www\./, "");
  } catch {
    return trimmed.replace(/^https?:\/\//, "").replace(/\/.*$/, "").replace(/^www\./, "");
  }
}
async function reportResult(taskId, result) {
  const storage = await chrome.storage.local.get(["mazaToken", "mazaOrigin"]);
  const origin = storage.mazaOrigin?.replace(/\/$/, "") || "";
  const apiBase = origin ? `${origin}/api` : (await Promise.resolve().then(() => (init_config(), config_exports))).CONFIG.API_BASE_URL;
  let postId = null;
  if (typeof result.post_id === "string") {
    postId = result.post_id;
  } else if (typeof result.published_url === "string") {
    const match = result.published_url.match(/\/(\d+)\/?$/);
    if (match) postId = match[1];
  }
  const res = await fetch(`${apiBase}/tasks/report`, {
    method: "POST",
    cache: "no-store",
    headers: {
      "Authorization": `Bearer ${storage.mazaToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ taskId, postId, status: result.ok ? "success" : "failed", result })
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "Unable to read response body");
    error("EXEC", `Report failed: HTTP ${res.status} - ${text}`);
  }
}
async function executeTask(task) {
  if (!tryStartTaskExecution(task.id)) {
    log("EXEC", "Task executor is currently busy. Ignoring concurrent task:", task.id);
    if (task.type === "INFRA_INJECT") {
      relayToWebApp({ type: "MAZA_INFRA_PROGRESS", step: "ERROR", detail: "\uC774\uBBF8 \uB2E4\uB978 \uC624\uD1A0\uD30C\uC77C\uB7FF \uC791\uC5C5\uC774 \uC2E4\uD589 \uC911\uC785\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694." });
    } else if (task.type === "PUBLISH_POST") {
      relayToWebApp({
        type: "MAZA_PUBLISH_RESULT",
        ok: false,
        taskId: task.id,
        error: "\uB2E4\uB978 \uC791\uC5C5\uC774 \uC9C4\uD589 \uC911\uC785\uB2C8\uB2E4. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uBC1C\uD589 \uBC84\uD2BC\uC744 \uB20C\uB7EC\uC8FC\uC138\uC694."
      });
    }
    return;
  }
  if (task.id) {
    await setLastImmediateTask(task);
  } else {
    await clearLastImmediateTask();
  }
  if (task.type === "INFRA_INJECT") {
    if (isInfraInjectInFlight()) {
      log("EXEC", "Skipping duplicate INFRA_INJECT task", task.id);
      return;
    }
    setInfraInjectInFlight(true);
  }
  if (task.type === "INFRA_INJECT" && !task.payload?.html) {
    throw new Error("\uC8FC\uC785\uD560 \uC11C\uCE58\uCF58\uC194/GA4 HTML \uCF54\uB4DC\uAC00 \uC804\uB2EC\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4. \uC571\uC5D0\uC11C \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694.");
  }
  let tabId = null;
  let shouldPreserveTask = false;
  try {
    log("EXEC", `Creating or finding tab for task: ${task.url}`);
    const tistoryTabs = await chrome.tabs.query({ url: "*://*.tistory.com/manage/*" });
    log("EXEC", `[TAB QUERY] task=${task.id} count=${tistoryTabs.length} tabs=${tistoryTabs.map((tab) => tab.id).filter((id) => typeof id === "number").join(",") || "none"}`);
    const isPublishTask = task.type === "PUBLISH_POST";
    const reusableTab = tistoryTabs.find((t) => {
      if (!t.id || !t.url) return false;
      if (isPublishTask && t.url.includes("skin/edit")) return false;
      return true;
    });
    if (reusableTab && reusableTab.id && reusableTab.windowId) {
      tabId = reusableTab.id;
      await chrome.tabs.update(tabId, { url: task.url, active: true });
      await chrome.windows.update(reusableTab.windowId, { focused: true });
    } else {
      const newTab = await chrome.tabs.create({ url: task.url, active: true });
      log("EXEC", `[TAB CREATED] task=${task.id} tab=${newTab.id ?? "unknown"} window=${newTab.windowId ?? "unknown"}`);
      tabId = newTab.id;
      if (newTab.windowId) {
        await chrome.windows.update(newTab.windowId, { focused: true });
      }
    }
    if (tabId !== null) {
      setExecutingTaskTabId(tabId);
    }
    await waitForTabComplete(tabId);
    await waitForTistoryManagePage(tabId, task);
    const result = await runTaskOnTab(tabId, task);
    if (result && result.status === "NAVIGATING_TO_EDITOR") {
      shouldPreserveTask = true;
    }
    if (result && result.status === "ALREADY_RUNNING") {
      shouldPreserveTask = true;
      log("EXEC", `Tab ${tabId} already running task ${task.id}. Preserving task, skipping report.`);
      return;
    }
    if (task.type === "INFRA_INJECT") {
      relayToWebApp({
        type: "MAZA_INFRA_PROGRESS",
        step: result?.ok ? result.step || "SUCCESS" : "ERROR",
        detail: result?.error || ""
      });
      if (result?.ok) {
        console.debug("[MAZA BG] INFRA_INJECT succeeded, sending MAZA_INFRA_INJECTED", { taskId: task.id, step: result.step });
        relayToWebApp({
          type: "MAZA_INFRA_INJECTED",
          step: result.step || "SUCCESS",
          detail: result.error || ""
        });
        await focusWebAppTab();
      }
    }
    if (result && result.status === "NAVIGATING_TO_EDITOR") {
      console.warn("[MAZA EXEC] NAVIGATING_TO_EDITOR detected \u2014 stopping retry loop for this task.");
      return;
    }
    await reportResult(task.id, result);
    log("EXEC", "Task Completed Successfully", task.id);
    if (task.type === "PUBLISH_POST") {
      relayToWebApp({
        type: "MAZA_PUBLISH_RESULT",
        ok: result?.ok ?? false,
        taskId: task.id,
        publishedUrl: result?.published_url ?? null,
        error: result?.ok ? null : result?.error ?? "\uC54C \uC218 \uC5C6\uB294 \uC624\uB958"
      });
    }
    if (task.type === "PUBLISH_POST" && result?.ok && tabId !== null) {
      try {
        await clearLastImmediateTask();
        clearTaskExecution(task.id);
        const host = task.domain || "";
        if (host) {
          const isPage = task.payload?.type === "page";
          const finalHost = host.includes(".") ? host : `${host}.tistory.com`;
          const targetUrl = isPage ? `https://${finalHost}/manage/page` : `https://${finalHost}/manage/posts`;
          log("EXEC", `[UX] Navigating tab to ${isPage ? "page list" : "posts list"}: ${targetUrl}`, task.id);
          await chrome.tabs.update(tabId, { url: targetUrl });
        }
      } catch (navErr) {
        const errorMessage = navErr instanceof Error ? navErr.message : String(navErr);
        log("EXEC", `[UX] Tab navigation to post list failed (non-critical): ${errorMessage}`, task.id);
      }
    }
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    const isTistoryBlockError = /Tistory 접근 차단 페이지가 감지되었습니다|Tistory blocked page detected|Too Many Requests|429|자동화된 접근/.test(errMsg);
    if (isTistoryBlockError) {
      log("EXEC", "Tistory block detected; backing off polling and ending task.", task.id);
      updatePollingInterval(60);
      relayToWebApp({
        type: "MAZA_INFRA_PROGRESS",
        step: "ERROR",
        detail: "Tistory \uC811\uADFC \uCC28\uB2E8\uC774 \uAC10\uC9C0\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uC790\uB3D9\uD654 \uC694\uCCAD\uC744 1\uC2DC\uAC04 \uB3D9\uC548 \uC77C\uC2DC \uC911\uB2E8\uD569\uB2C8\uB2E4."
      });
      await reportResult(task.id, { ok: false, error: errMsg });
      return;
    }
    const isConnectionError = [
      "message channel closed",
      "asynchronous response",
      "Could not establish connection",
      "Receiving end does not exist",
      "No tab with id"
    ].some((needle) => errMsg.includes(needle));
    if (isConnectionError && task.type === "PUBLISH_POST") {
      log("EXEC", "\uD37C\uC9C0 \uC774\uB3D9\uC73C\uB85C \uC5F0\uACB0 \uC885\uB8CC. \uD0ED URL \uD655\uC778 \uD6C4 \uACB0\uACFC \uBCF4\uACE0 \uC2DC\uB3C4...", task.id);
      try {
        if (tabId !== null) {
          await waitForTabComplete(tabId);
          const currentTab = await chrome.tabs.get(tabId).catch(() => null);
          const tabUrl = currentTab?.url || "";
          const isTistoryPostUrl = /\.tistory\.com\/\d+$/.test(tabUrl) || /\.tistory\.com\/entry\//.test(tabUrl);
          const isPostsListAfterPublish = (tabUrl.includes("/manage/posts") || tabUrl.includes("/manage/post")) && !tabUrl.includes("/manage/newpost");
          const isPageListAfterPublish = (tabUrl.includes("/manage/page") || tabUrl.includes("/manage/pages")) && !tabUrl.includes("/write");
          const isPageSlugUrl = tabUrl.includes("/pages/");
          const isEditorUrl = tabUrl.includes("/manage/newpost") || tabUrl.includes("/manage/page/write") || tabUrl.includes("/manage/pages/write");
          const isSuccessUrl = isTistoryPostUrl || isPostsListAfterPublish || isPageListAfterPublish || isPageSlugUrl;
          if (isSuccessUrl) {
            log("EXEC", `\uD0ED URL(${tabUrl})\uC774 \uC131\uACF5\uC744 \uB098\uD0C0\uB0C4. \uC131\uACF5\uC73C\uB85C \uBCF4\uACE0.`, task.id);
            await reportResult(task.id, { ok: true, published_url: tabUrl });
          } else if (isEditorUrl) {
            log("EXEC", `\uD0ED URL(${tabUrl})\uC774 \uC5D0\uB514\uD130\uC784. Task \uC720\uC9C0.`, task.id);
            shouldPreserveTask = true;
          } else {
            log("EXEC", `\uD0ED URL(${tabUrl})\uC774 \uB300\uAE30 \uC911. \uC2E4\uD328\uB85C \uBCF4\uACE0.`, task.id);
            await reportResult(task.id, { ok: false, error: `\uD37C\uC9C0 \uC774\uB3D9 \uD6C4 URL \uD655\uC778 \uC2E4\uD328: ${tabUrl || "(unknown)"}` });
          }
        } else {
          log("EXEC", "tabId \uCC38\uC870 \uC2E4\uD328. \uC5F0\uACB0 \uC5D0\uB7EC \uBCF4\uACE0.", task.id);
          await reportResult(task.id, { ok: false, error: errMsg });
        }
      } catch (reportErr) {
        const errorMessage = reportErr instanceof Error ? reportErr.message : String(reportErr);
        log("EXEC", `\uC5F0\uACB0 \uC5D0\uB7EC \uD6C4 reportResult \uC2E4\uD328: ${errorMessage}`, task.id);
      }
      return;
    }
    if (isConnectionError) {
      const connectionErrorMessage = `Task channel unavailable: ${errMsg}`;
      log("EXEC", `Connection/tab error during execution \u2014 reporting failure: ${connectionErrorMessage}`, task.id);
      if (task.type === "INFRA_INJECT") {
        relayToWebApp({ type: "MAZA_INFRA_PROGRESS", step: "ERROR", detail: connectionErrorMessage });
      }
      await reportResult(task.id, { ok: false, error: connectionErrorMessage });
      return;
    }
    const screenshot = await captureErrorState();
    if (task.type === "INFRA_INJECT") {
      relayToWebApp({ type: "MAZA_INFRA_PROGRESS", step: "ERROR", detail: errMsg });
    }
    await reportResult(task.id, { ok: false, error: errMsg, screenshot });
    throw err;
  } finally {
    clearTaskExecution(task.id);
    if (!shouldPreserveTask) {
      await clearLastImmediateTask();
    } else {
      log("EXEC", `Preserving lastImmediateTask across navigation.`, task.id);
    }
    if (task.type === "INFRA_INJECT") {
      setInfraInjectInFlight(false);
    }
  }
}
async function deliverTask(task, tabId, proactive = false) {
  if (isTaskExecutionInProgress() && getExecutingTaskTabId() !== tabId) {
    log("SYSTEM", `[Duplicate Guard] Task execution already in progress on a different tab. Skipping deliverTask for ${task.id}.`);
    return;
  }
  log("SYSTEM", `${proactive ? "[Proactive]" : "[Reactive]"} Delivering task ${task.id} to tab ${tabId}...`);
  let success = false;
  let response = null;
  const maxRetries = 5;
  for (let i = 0; i < maxRetries; i++) {
    try {
      const tab = await chrome.tabs.get(tabId).catch(() => null);
      if (tab && tab.status !== "complete") {
        log("SYSTEM", `Tab ${tabId} still loading (attempt ${i + 1}). Waiting for complete...`);
        await waitForTabComplete(tabId);
      }
    } catch {
    }
    try {
      response = await chrome.tabs.sendMessage(tabId, { type: "DELIVER", task });
      if (response) {
        success = true;
        break;
      }
    } catch (e) {
      const backoffMs = Math.min(300 * Math.pow(2, i), 3e3);
      log("SYSTEM", `Delivery to tab ${tabId} failed (attempt ${i + 1}/${maxRetries}): ${e}. Retrying in ${backoffMs}ms`);
      await new Promise((r) => setTimeout(r, backoffMs));
    }
  }
  if (!success || !response) {
    log("SYSTEM", `No response from tab ${tabId} after ${maxRetries} retries. Keeping task in memory.`);
    const deliveredSet = globalThis._deliveredTasks;
    if (deliveredSet) {
      deliveredSet.delete(task.id);
    }
    const errMsg = "\uD0ED \uC804\uB2EC \uC2E4\uD328 (\uC7AC\uC2DC\uB3C4 \uCD08\uACFC)";
    reportResult(task.id, { ok: false, error: errMsg }).catch(console.error);
    relayToWebApp({ type: "MAZA_PUBLISH_RESULT", ok: false, taskId: task.id, error: errMsg });
    return;
  }
  if (response.status === "ALREADY_RUNNING") {
    log("SYSTEM", `Tab ${tabId} already running task. Ignoring duplicate delivery.`);
    return;
  }
  const isFinished = typeof response.status === "string" && response.status.includes("PUBLISHED") || response.status === "INJECTED" || response.status === "INJECTED_ONLY" || response.ok === false;
  if (isFinished) {
    log("SYSTEM", `Task ${task.id} finished: ${response.status || "ERROR"}. Clearing.`);
    reportResult(task.id, response).catch((err) => {
      const message = err instanceof Error ? err.message : String(err);
      log("SYSTEM", `Failed to report finished task ${task.id}: ${message}`);
      relayToWebApp({ type: "MAZA_PUBLISH_RESULT", ok: false, taskId: task.id, error: `\uACB0\uACFC \uBCF4\uACE0 \uC2E4\uD328: ${message}` });
    });
    clearLastImmediateTask();
    return response;
  } else if (response.status === "NAVIGATING_TO_EDITOR") {
    log("SYSTEM", `Tab ${tabId} navigating to editor. Preserving task.`);
    return response;
  }
  return response;
}
async function handleImmediateAction(msg, sendResponse) {
  if (!isRecord(msg)) {
    sendResponse({ ok: false, error: "Invalid action payload." });
    return;
  }
  const actionType = typeof msg.actionType === "string" ? msg.actionType : "";
  const payload = isRecord(msg.payload) ? msg.payload : {};
  const domain = typeof payload.domain === "string" ? payload.domain : "";
  const title = typeof payload.title === "string" ? payload.title : "";
  log("SYSTEM", `Immediate Action: ${actionType}, domain: "${domain}", title: "${title.substring(0, 20)}"`);
  let finalDomain = domain;
  if (!finalDomain) {
    error("SYSTEM", "\u274C No domain in payload. Trying storage recovery...");
    const storage = await chrome.storage.local.get(["mazaSites"]);
    const sites = Array.isArray(storage["mazaSites"]) ? storage["mazaSites"] : [];
    if (sites.length > 0 && typeof sites[0]?.domain === "string") {
      finalDomain = sites[0].domain;
      log("SYSTEM", `[Recovery] Auto-recovered domain: ${finalDomain}`);
    } else {
      sendResponse({ ok: false, error: "\uC5F0\uACB0\uB41C \uBE14\uB85C\uADF8\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. \uB0B4 \uC0AC\uC774\uD2B8 \uBA54\uB274\uC5D0\uC11C \uBE14\uB85C\uADF8\uB97C \uB4F1\uB85D\uD574 \uC8FC\uC138\uC694." });
      return;
    }
  }
  finalDomain = normalizeTistoryDomain(finalDomain);
  if (!finalDomain) {
    sendResponse({ ok: false, error: "\uD2F0\uC2A4\uD1A0\uB9AC \uB3C4\uBA54\uC778\uC744 \uD655\uC778\uD560 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4. \uC0AC\uC774\uD2B8 \uC124\uC815\uC744 \uB2E4\uC2DC \uD655\uC778\uD574 \uC8FC\uC138\uC694." });
    return;
  }
  const tistoryHost = finalDomain.includes(".") ? finalDomain : `${finalDomain}.tistory.com`;
  let html = typeof payload.content === "string" ? payload.content : typeof payload.html === "string" ? payload.html : typeof payload.body === "string" ? payload.body : "";
  if (actionType === "MAZA_INFRA_INJECT") {
    if (!html) {
      sendResponse({ ok: false, error: "\uC8FC\uC785\uD560 \uC11C\uCE58\uCF58\uC194 \uB610\uB294 GA4 HTML \uCF54\uB4DC\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4. [\uAD6C\uAE00 \uC778\uD504\uB77C \uB3D9\uAE30\uD654] \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574 \uC8FC\uC138\uC694." });
      return;
    }
  }
  const taskPayload = {
    title: title || void 0,
    html,
    type: typeof payload.type === "string" ? payload.type : void 0,
    category: typeof payload.category === "string" ? payload.category : void 0,
    categoryId: typeof payload.categoryId === "string" ? payload.categoryId : void 0,
    tags: Array.isArray(payload.tags) ? payload.tags : void 0,
    thumbnailUrl: typeof payload.thumbnailUrl === "string" ? payload.thumbnailUrl : void 0,
    sc_verification: typeof payload.sc_verification === "string" ? payload.sc_verification : void 0,
    ga_measurement_id: typeof payload.ga_measurement_id === "string" ? payload.ga_measurement_id : void 0
  };
  if (!taskPayload.thumbnailUrl) {
    const storage = await chrome.storage.local.get(["pendingThumbnailUrl"]);
    const pendingUrl = typeof storage.pendingThumbnailUrl === "string" ? storage.pendingThumbnailUrl : "";
    if (pendingUrl) {
      taskPayload.thumbnailUrl = pendingUrl;
      await chrome.storage.local.remove("pendingThumbnailUrl");
      log("SYSTEM", "Applied pending thumbnail URL to publish payload.");
    }
  }
  const task = {
    id: typeof payload.id === "string" ? payload.id : `immediate-${Date.now()}`,
    type: actionType === "MAZA_INFRA_INJECT" ? "INFRA_INJECT" : "PUBLISH_POST",
    platform: "tistory",
    url: actionType === "MAZA_INFRA_INJECT" ? `https://${tistoryHost}/manage/design/skin/edit#/source/html` : payload.type === "page" ? `https://${tistoryHost}/manage/page` : `https://${tistoryHost}/manage/newpost/?type=post&returnURL=%2Fmanage%2Fposts%2F`,
    domain: finalDomain,
    payload: taskPayload
  };
  await setLastImmediateTask(task);
  log("SYSTEM", `Task created: ${task.type} \u2192 ${task.domain}`);
  executeTask(task).catch((err) => {
    const errorMessage = err instanceof Error ? err.message : String(err);
    error("EXEC", `Immediate Task Failed: ${errorMessage}`);
    relayToWebApp({ type: "MAZA_PUBLISH_RESULT", ok: false, taskId: task.id, error: `\uBC1C\uD589 \uC2E4\uD589 \uC2E4\uD328: ${errorMessage}` });
  });
  sendResponse({ ok: true });
}
async function handleSetThumbnail(msg, sendResponse) {
  if (!isRecord(msg)) {
    sendResponse({ ok: false, error: "Invalid thumbnail payload." });
    return;
  }
  const payload = isRecord(msg.payload) ? msg.payload : {};
  const imageUrl = typeof payload.imageUrl === "string" && payload.imageUrl.trim() ? payload.imageUrl.trim() : "";
  if (!imageUrl) {
    sendResponse({ ok: false, error: "\uC378\uB124\uC77C URL\uC774 \uC5C6\uC2B5\uB2C8\uB2E4." });
    return;
  }
  const activeTask = getLastImmediateTask();
  if (activeTask) {
    activeTask.payload = {
      ...activeTask.payload,
      thumbnailUrl: imageUrl
    };
    await setLastImmediateTask(activeTask);
    sendResponse({ ok: true, message: "\uD604\uC7AC \uBC1C\uD589 \uC791\uC5C5\uC5D0 \uC378\uB124\uC77C\uC774 \uC800\uC7A5\uB418\uC5C8\uC2B5\uB2C8\uB2E4." });
    return;
  }
  await chrome.storage.local.set({ pendingThumbnailUrl: imageUrl });
  sendResponse({ ok: true, message: "\uC378\uB124\uC77C\uC774 \uC800\uC7A5\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uB2E4\uC74C \uBC1C\uD589 \uC2DC \uC790\uB3D9\uC73C\uB85C \uC801\uC6A9\uB429\uB2C8\uB2E4." });
}

// extension/background/background.ts
init_tabManager();
init_pollingFallback();
init_taskStore();

// extension/background/execution/contentExecutor.ts
async function loadMainWorldScript(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    world: "MAIN",
    files: ["content/mainWorld.js"]
  });
}
async function executeMainWorld(tabId, msg) {
  const funcId = msg.funcId;
  const args = Array.isArray(msg.args) ? msg.args : [];
  const findAnywhere = (selector, root = document) => {
    const el = root.querySelector(selector);
    if (el) return el;
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          const found = findAnywhere(selector, doc);
          if (found) return found;
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        const found = findAnywhere(selector, node.shadowRoot);
        if (found) return found;
      }
    }
    return null;
  };
  const findAnywhereAll = (selector, root = document) => {
    const results2 = Array.from(root.querySelectorAll(selector));
    const iframes = root.querySelectorAll("iframe, frame");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc) {
          results2.push(...findAnywhereAll(selector, doc));
        }
      } catch (e) {
      }
    }
    const allElements = root.querySelectorAll("*");
    for (const node of Array.from(allElements)) {
      if (node.shadowRoot) {
        results2.push(...findAnywhereAll(selector, node.shadowRoot));
      }
    }
    return results2;
  };
  const findAll = (selector, root = document) => findAnywhereAll(selector, root);
  const findFirst = (selector, root = document) => findAnywhere(selector, root);
  const func = funcId === "autoAcceptDialog" ? () => {
    const _origConfirm = window.confirm;
    window.confirm = () => true;
    setTimeout(() => {
      window.confirm = _origConfirm;
    }, 3e3);
    return { ok: true };
  } : funcId === "injectInfra" ? (html) => {
    try {
      const hasPayload = html && html !== "null" && html !== "undefined" && html.length > 10;
      if (!hasPayload) {
        return { ok: false, error: "EMPTY_INFRA_HTML" };
      }
      const processVal = (val) => {
        if (!val || val.length < 20) {
          return val.includes("<head>") ? val.replace("<head>", "<head>\n" + html) : html;
        }
        const regexNew = /<!-- Maza Infra -->[\s\S]*?<!-- End Maza Infra -->\n?/g;
        const withoutMaza = val.replace(regexNew, "");
        if (val.includes(html.trim().slice(0, 40))) {
          return null;
        }
        const cleaned = withoutMaza;
        return cleaned.includes("<head>") ? cleaned.replace("<head>", "<head>\n" + html) : html + "\n" + cleaned;
      };
      const cmEls = findAll(".CodeMirror");
      for (const el of cmEls) {
        if (el.CodeMirror) {
          const cm = el.CodeMirror;
          const newVal = processVal(cm.getValue());
          if (newVal === null) return { ok: true, step: "ALREADY_INJECTED" };
          cm.setValue(newVal);
          return { ok: true, step: "SUCCESS" };
        }
      }
      if (window.monaco?.editor) {
        const models = window.monaco.editor.getModels();
        if (models && models.length > 0) {
          const newVal = processVal(models[0].getValue());
          if (newVal === null) return { ok: true, step: "ALREADY_INJECTED" };
          models[0].setValue(newVal);
          return { ok: true, step: "SUCCESS" };
        }
      }
      const htmlTextarea = findAll("textarea").find(
        (t) => t.value.includes("<html") || t.value.includes("<!doctype")
      );
      if (htmlTextarea) {
        const newVal = processVal(htmlTextarea.value);
        if (newVal === null) return { ok: true, step: "ALREADY_INJECTED" };
        const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
        if (setter) setter.call(htmlTextarea, newVal);
        else htmlTextarea.value = newVal;
        htmlTextarea.dispatchEvent(new Event("input", { bubbles: true }));
        htmlTextarea.dispatchEvent(new Event("change", { bubbles: true }));
        return { ok: true, step: "SUCCESS" };
      }
      return { ok: false, error: "NO_EDITOR_FOUND" };
    } catch (err) {
      return { ok: false, error: err?.message || "MAIN_WORLD_INJECT_INFRA_FAILED" };
    }
  } : funcId === "injectPostContent" ? (html) => {
    try {
      let injected = false;
      if (window.monaco?.editor) {
        const models = window.monaco.editor.getModels();
        if (models && models.length > 0) {
          models[0].setValue(html);
          injected = true;
        }
      }
      if (!injected) {
        const cmEl = findFirst(".CodeMirror");
        if (cmEl?.CodeMirror) {
          cmEl.CodeMirror.setValue(html);
          injected = true;
        }
      }
      if (!injected) {
        const textareas = findAll("textarea");
        for (const textarea of textareas) {
          if (textarea.value === "" || textarea.value.includes("<!") || textarea.value.includes("<h") || textarea.value.includes("<p")) {
            const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
            if (setter) setter.call(textarea, html);
            else textarea.value = html;
            textarea.dispatchEvent(new Event("input", { bubbles: true }));
            textarea.dispatchEvent(new Event("change", { bubbles: true }));
            injected = true;
            break;
          }
        }
      }
      if (!injected) {
        const editableDivs = findAll('[contenteditable="true"]');
        for (const div of editableDivs) {
          if (div.innerText.length < 100) {
            div.innerHTML = html;
            div.dispatchEvent(new Event("input", { bubbles: true }));
            injected = true;
            break;
          }
        }
      }
      return { ok: injected, step: injected ? "SUCCESS" : "NO_EDITOR_FOUND" };
    } catch (err) {
      return { ok: false, error: err?.message || "MAIN_WORLD_INJECT_POST_FAILED" };
    }
  } : funcId === "autoCancelDraftDialog" ? () => {
    const _origConfirm = window.confirm;
    window.confirm = (msg2) => {
      if (msg2) {
        if (msg2.includes("\uC800\uC7A5\uB41C \uAE00\uC774 \uC788\uC2B5\uB2C8\uB2E4") || msg2.includes("\uC774\uC5B4\uC11C \uC791\uC131")) {
          return false;
        }
        if (msg2.includes("\uC791\uC131 \uBAA8\uB4DC\uB97C \uBCC0\uACBD") || msg2.includes("\uC11C\uC2DD\uC774 \uC720\uC9C0\uB418\uC9C0")) {
          return true;
        }
      }
      return true;
    };
    return { ok: true };
  } : void 0;
  if (!func) {
    return { ok: false, error: "UNKNOWN_FUNCTION" };
  }
  const results = await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    world: "MAIN",
    func,
    args
  });
  const valid = results.find((r) => r?.result !== void 0)?.result;
  return valid || { ok: false, error: "No valid result from frames" };
}

// extension/background/background.ts
var workerId = globalThis.crypto?.randomUUID?.() ?? `worker-${Date.now()}`;
log("SYSTEM", "MAZA OS Phoenix Engine Started.");
log("SYSTEM", `[WORKER START] ${workerId}`);
initWebSocketAlarmListener();
initPollingAlarmListener();
registerTaskExecutor(executeTask);
registerTaskHandler(executeTask);
setWebSocketConnectedProvider(() => isWebSocketConnected());
setResetPollingStateHandler(() => resetPollingState());
registerPollingAlarm();
var MAZA_SCRAP_CONTEXT_MENU_ID = "maza-scrap-idea";
var transportRefreshPromise = null;
async function forwardObservabilityLog(context, errorMessage, meta) {
  try {
    const storage = await chrome.storage.local.get(["mazaOrigin"]);
    const origin = storage.mazaOrigin?.replace(/\/$/, "") || "";
    const apiBase = origin ? `${origin}/api` : CONFIG.API_BASE_URL;
    await fetch(`${apiBase}/observability/log`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        context,
        error: { message: errorMessage },
        meta
      })
    });
  } catch {
  }
}
async function postObservabilityLog(scope, message, meta) {
  try {
    const storage = await chrome.storage.local.get(["mazaOrigin"]);
    const origin = storage.mazaOrigin?.replace(/\/$/, "") || "";
    const apiBase = origin ? `${origin}/api` : CONFIG.API_BASE_URL;
    await fetch(`${apiBase}/observability/log`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        context: scope,
        error: { message },
        meta
      })
    });
  } catch {
  }
}
function refreshTransport(reason) {
  if (transportRefreshPromise) {
    return transportRefreshPromise;
  }
  transportRefreshPromise = Promise.all([
    pollingLoop(),
    connectWebSocket().catch(() => {
    })
  ]).then(() => {
  }).catch((err) => {
    error("SYSTEM", `Transport refresh failed (${reason}): ${err instanceof Error ? err.message : String(err)}`);
  }).finally(() => {
    transportRefreshPromise = null;
  });
  return transportRefreshPromise;
}
function ensureScrapContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MAZA_SCRAP_CONTEXT_MENU_ID,
      title: "MAZA \uC2A4\uD29C\uB514\uC624\uB85C \uC2A4\uD06C\uB7A9",
      contexts: ["selection"]
    });
  });
}
var _authChangeDebounceTimer = null;
function handleAuthStorageChange(changes) {
  const tokenChanged = changes.mazaToken && changes.mazaToken.newValue !== changes.mazaToken.oldValue;
  const emailChanged = changes.mazaUserEmail && changes.mazaUserEmail.newValue !== changes.mazaUserEmail.oldValue;
  const originChanged = changes.mazaOrigin && changes.mazaOrigin.newValue !== changes.mazaOrigin.oldValue;
  if (!tokenChanged && !emailChanged && !originChanged) return;
  if (_authChangeDebounceTimer) {
    clearTimeout(_authChangeDebounceTimer);
  }
  _authChangeDebounceTimer = setTimeout(() => {
    _authChangeDebounceTimer = null;
    log("SYSTEM", "Auth storage changed (debounced). Resetting polling state and forcing immediate refresh.");
    resetPollingState();
    pollingLoop(true).catch(() => {
    });
    connectWebSocket().catch(() => {
    });
  }, 500);
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  handleAuthStorageChange(changes);
});
chrome.sidePanel?.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);
chrome.action.onClicked.addListener((tab) => {
  if (tab.windowId) {
    chrome.sidePanel.open({ windowId: tab.windowId });
  }
});
chrome.runtime.onInstalled.addListener((details) => {
  ensureScrapContextMenu();
  if (details.reason === "update") {
    resetPollingState();
    void refreshTransport("installed-update");
  }
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "maza-scrap-idea" && info.selectionText) {
    try {
      const payload = {
        content: info.selectionText,
        source_url: tab?.url || "",
        source_title: tab?.title || ""
      };
      if (tab?.windowId) {
        await chrome.sidePanel.open({ windowId: tab.windowId }).catch(console.error);
      }
      await chrome.storage.local.set({ pendingScrap: payload });
      chrome.runtime.sendMessage({
        type: "MAZA_SCRAP_INTENT",
        payload
      }).catch(() => {
      });
      log("SCRAP", "Scrap intent passed to Side Panel");
    } catch (err) {
      error("SCRAP", `Scrap error: ${err instanceof Error ? err.message : String(err)}`);
    }
  }
});
(async () => {
  try {
    const restoredTask = await hydrateLastImmediateTask();
    if (restoredTask) {
      log("SYSTEM", `Restored pending task from storage: ${restoredTask.id}`);
    }
  } catch (restoreErr) {
    error("SYSTEM", `Failed to restore pending task: ${restoreErr instanceof Error ? restoreErr.message : String(restoreErr)}`);
  }
})();
void refreshTransport("boot");
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "IMMEDIATE_ACTION") {
    handleImmediateAction(msg, sendResponse).catch((err) => {
      error("SYSTEM", `handleImmediateAction failed: ${err instanceof Error ? err.message : String(err)}`);
      sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) });
    });
    return true;
  }
  if (msg.type === "MAZA_SYNC_TOKEN") {
    const { token, origin, email } = msg.payload;
    log("SYSTEM", `Token synced from ${origin}.`);
    chrome.storage.local.set({
      mazaToken: token,
      mazaOrigin: origin,
      mazaUserEmail: email || null,
      last_sync: (/* @__PURE__ */ new Date()).toISOString()
    }).then(() => {
      pollingLoop();
      connectWebSocket().catch((err) => console.warn("[Background] WebSocket connection fallback error:", err));
    });
    sendResponse({ ok: true });
    return false;
  }
  if (msg.type === "TOKEN_UPDATED") {
    log("SYSTEM", "Token updated. Triggering immediate poll...");
    pollingLoop();
    connectWebSocket().catch((err) => console.warn("[Background] WebSocket connection fallback error:", err));
    return false;
  }
  if (msg.type === "MAZA_DOM_LOAD_FAILED") {
    error("SYSTEM", `Content script DOM module failed to load: ${msg.error} @ ${msg.url}`);
    if (sender.tab?.id) {
      chrome.tabs.sendMessage(sender.tab.id, {
        type: "MAZA_CONTENT_ERROR",
        detail: "\uC5D0\uB514\uD130 \uBAA8\uB4C8 \uB85C\uB4DC \uC2E4\uD328 \u2014 \uD398\uC774\uC9C0\uB97C \uC0C8\uB85C\uACE0\uCE68 \uD6C4 \uB2E4\uC2DC \uC2DC\uB3C4\uD574\uC8FC\uC138\uC694.",
        error: msg.error
      }).catch(() => {
      });
    }
    return false;
  }
  if (msg.type === "TASK_ERROR") {
    const scope = typeof msg.scope === "string" && msg.scope.trim() ? msg.scope : "UNKNOWN";
    const message = typeof msg.message === "string" && msg.message.trim() ? msg.message : "unknown error";
    void forwardObservabilityLog(scope, message, {
      scope,
      data: msg.data || null,
      source: "extension"
    });
    relayToWebApp({
      type: "MAZA_INFRA_PROGRESS",
      step: "TASK_ERROR",
      detail: `[${scope}] ${message}`
    });
    return false;
  }
  if (msg.type === "TASK_LOG") {
    relayToWebApp(msg);
    if (msg.level === "error") {
      void postObservabilityLog(String(msg.scope || "extension"), String(msg.message || "unknown"), {
        level: msg.level,
        data: msg.data
      });
    }
    return false;
  }
  if (msg.type === "CAPTURE_SCREENSHOT") {
    captureErrorState().then((screenshot) => sendResponse({ ok: true, screenshot })).catch((err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) }));
    return true;
  }
  if (msg.type === "FORCE_POLLING") {
    log("SYSTEM", "Force Polling requested.");
    pollingLoop(true);
    sendResponse({ ok: true, received: true });
    return true;
  }
  if (msg.type === "MAZA_AUTOPILOT_SYNC") {
    if (sender.tab?.id) {
      chrome.tabs.sendMessage(sender.tab.id, msg).catch(() => {
      });
    }
    return false;
  }
  if (msg.type === "FETCH_IMAGE") {
    fetch(msg.url).then((res) => res.blob()).then((blob) => {
      const reader = new FileReader();
      reader.onloadend = () => sendResponse({ ok: true, dataUrl: reader.result });
      reader.readAsDataURL(blob);
    }).catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
  if (msg.type === "TASK_CONFIRMED_PUBLISHING") {
    const taskId = msg.taskId || globalThis.lastImmediateTask?.id;
    if (taskId) {
      log("SYSTEM", `Received TASK_CONFIRMED_PUBLISHING for task ${taskId}. Relaying progress (success report deferred until verification)...`);
      relayToWebApp({
        type: "MAZA_INFRA_PROGRESS",
        step: "PUBLISHING_CLICKED",
        detail: "\uBC1C\uD589 \uC644\uB8CC \uBC84\uD2BC\uC774 \uD074\uB9AD\uB418\uC5C8\uC2B5\uB2C8\uB2E4. \uCD5C\uC885 \uD655\uC778 \uBC0F \uB77C\uC774\uBE0C \uAC80\uC99D\uC744 \uC644\uB8CC\uD560 \uB54C\uAE4C\uC9C0 \uC7A0\uC2DC \uB300\uAE30\uD574 \uC8FC\uC138\uC694."
      });
    } else {
      log("SYSTEM", "Received TASK_CONFIRMED_PUBLISHING but no task id available.");
    }
    return false;
  }
  if (msg.type === "MAZA_SET_THUMBNAIL") {
    handleSetThumbnail(msg, sendResponse).catch((err) => {
      error("SYSTEM", `handleSetThumbnail failed: ${err instanceof Error ? err.message : String(err)}`);
      sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) });
    });
    return true;
  }
  if (msg.type === "CONTENT_SCRIPT_READY") {
    log("SYSTEM", `[READY] tab=${sender.tab?.id ?? "unknown"} worker=${workerId} ts=${Date.now()}`);
    sendResponse({ received: true });
    if (isTaskExecutionInProgress()) {
      const activeTabId = getExecutingTaskTabId();
      if (sender.tab?.id !== activeTabId) {
        log("SYSTEM", `[Duplicate Guard] Task execution already in progress on tab ${activeTabId}. Skipping reactive delivery from tab ${sender.tab?.id}.`);
        return true;
      }
    }
    (async () => {
      const task = await resolveLastImmediateTask() || globalThis.lastImmediateTask;
      if (task && sender.tab?.id) {
        log("SYSTEM", `[DELIVER] task=${task.id} tab=${sender.tab.id} worker=${workerId}`);
        deliverTask(task, sender.tab.id);
      } else {
        log("SYSTEM", `READY received but NO TASK for tab ${sender.tab?.id}.`);
      }
    })();
    return true;
  }
  if (msg.type === "MAZA_INFRA_PROGRESS") {
    relayToWebApp(msg);
    return false;
  }
  if (msg.type === "MANUAL_INJECT_REQUEST") {
    const task = getLastImmediateTask();
    if (task) {
      chrome.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
        if (tabs[0]?.id) deliverTask(task, tabs[0].id, true);
      });
    }
    return false;
  }
  if (msg.type === "LOAD_MAIN_WORLD_SCRIPT" && sender.tab?.id) {
    loadMainWorldScript(sender.tab.id).then(() => sendResponse({ ok: true })).catch((err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) }));
    return true;
  }
  if (msg.type === "EXECUTE_MAIN_WORLD" && sender.tab?.id) {
    executeMainWorld(sender.tab.id, msg).then((result) => sendResponse(result)).catch((err) => sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) }));
    return true;
  }
  if (msg.type === "MAZA_SCRAP_IDEA") {
    (async () => {
      try {
        const storage = await chrome.storage.local.get(["mazaToken", "mazaOrigin"]);
        if (!storage.mazaToken) {
          sendResponse({ ok: false, error: "Not logged in" });
          return;
        }
        const origin = storage.mazaOrigin?.replace(/\/$/, "") || "";
        const apiBase = origin ? `${origin}/api` : CONFIG.API_BASE_URL;
        const res = await fetch(`${apiBase}/scrap`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${storage.mazaToken}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            content: msg.payload.content,
            source_url: msg.payload.source_url || "",
            source_title: msg.payload.source_title || "Gemini"
          })
        });
        sendResponse({ ok: res.ok });
        if (res.ok && sender.tab?.id) {
          chrome.tabs.sendMessage(sender.tab.id, {
            type: "MAZA_IDEA_SAVED",
            title: msg.payload.source_title || msg.payload.content?.substring(0, 40) || "Gemini \uC751\uB2F5"
          }).catch(() => {
          });
        }
      } catch (err) {
        sendResponse({ ok: false, error: err instanceof Error ? err.message : String(err) });
      }
    })();
    return true;
  }
  if (msg.type === "MAZA_CONTEXT_DETECTED") {
    if (msg.context) {
      relayToWebApp(msg.context);
    }
    return false;
  }
  return false;
});
//# sourceMappingURL=background.js.map
