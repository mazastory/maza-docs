// @ts-nocheck
/**
 * Maza Bridge v5 — background/engine/telemetry.js
 * 실패 분석 및 텔레메트리 보고
 */
import { CONFIG } from '../../shared/config.js';
export class Telemetry {
    /**
     * 실패 시점의 스냅샷 보고
     */
    static async reportFailure(jobId, error, tabId) {
        if (!chrome.runtime?.id)
            return;
        console.log(`[Telemetry] 🛡️ Reporting failure for job: ${jobId}`);
        try {
            // 100점 구조: 실패 시점의 DOM 일부 또는 스크린샷 캡처 (보안 주의)
            let domSnippet = '';
            if (tabId) {
                const res = await chrome.scripting.executeScript({
                    target: { tabId },
                    func: () => {
                        // 본문 제외, 주요 상태만 캡처 (XSS 및 개인정보 방어 - innerHTML 수집 중단)
                        return `Title: ${document.title} | URL: ${window.location.href}`;
                    }
                }).catch(() => null);
                domSnippet = res?.[0]?.result || '';
            }
            const payload = {
                jobId,
                error: error.message,
                stack: error.stack,
                url: tabId ? (await chrome.tabs.get(tabId)).url : 'unknown',
                domSnippet,
                timestamp: new Date().toISOString()
            };
            await fetch(`${CONFIG.STUDIO_URL}/api/telemetry/failure`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            console.log('[Telemetry] ✅ Failure snapshot sent to studio.');
        }
        catch (err) {
            console.warn('[Telemetry] Failed to report failure:', err.message);
        }
    }
}
//# sourceMappingURL=telemetry.js.map