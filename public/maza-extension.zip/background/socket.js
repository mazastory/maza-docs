// @ts-nocheck
/**
 * Maza Bridge v3 — background/socket.js
 * WebSocket 연결 및 서버 명령 수신
 *
 * 원칙:
 * - 상태 없음 (Stateless)
 * - Queue 없음
 * - Retry 로직 없음 (서버 책임)
 * - 연결 끊기면 3초 후 재연결만
 */
import { CLIENT_EVENTS } from '../shared/protocol.js';
import { CONFIG } from '../shared/config.js';
import { Telemetry } from './engine/telemetry.js';
/**
 * WebSocket 연결 상태 확인 및 강제 연결 (Offscreen 중계 방식)
 */
export async function connectSocket() {
    if (!chrome.runtime?.id)
        return;
    console.log('[Maza Bridge] connectSocket() called. Ensuring offscreen persistence...');
    chrome.runtime.sendMessage({ type: 'HEARTBEAT_PING' }).catch(() => {
        console.warn('[Maza Bridge] Offscreen not responding to connect request.');
    });
}
/**
 * 서버로 메시지 전송 (Offscreen 중계)
 */
export function send(message) {
    if (chrome.runtime?.id) {
        chrome.runtime.sendMessage({ type: 'SEND_TO_SERVER', payload: message });
    }
}
/**
 * 서버 명령 처리: 활성 탭에 DOM 액션 전달
 */
export async function handleAction(payload) {
    if (!chrome.runtime?.id)
        return;
    try {
        // ── 특수 플로우: 포스트 자동 발행 (vNext Engine) ──
        if (payload.action === 'PUBLISH_POST') {
            console.warn('[Maza Bridge] PUBLISH_POST reached background. Should have been handled by Offscreen Orchestrator.');
            return { ok: false, error: 'Wrong routing for PUBLISH_POST' };
        }
        // ── 특수 플로우: 인프라 자동 주입 (Orchestrator로 이관) ──
        if (payload.action === 'INJECT_INFRA') {
            console.log('[Maza Bridge] Routing INJECT_INFRA to Offscreen Orchestrator.');
            chrome.runtime.sendMessage({ type: 'INJECT_INFRA_REQUEST', jobId: payload.jobId, data: payload.data });
            return { ok: true, status: 'enqueued' };
        }
        // ── 기본 플로우: 활성 탭에 액션 전달 ──
        const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
        const activeTab = activeTabs[0];
        if (!activeTab) {
            send({ type: CLIENT_EVENTS.ACTION_ERROR, jobId: payload.jobId, error: 'No active tab found' });
            return;
        }
        const defaultResult = await chrome.tabs.sendMessage(activeTab.id, {
            type: 'RUN_DOM_ACTION',
            action: payload.action,
            data: payload.data,
            jobId: payload.jobId,
        });
        send({
            type: CLIENT_EVENTS.ACTION_RESULT,
            jobId: payload.jobId,
            result: defaultResult,
        });
    }
    catch (err) {
        console.error('[Maza Bridge] Action failed:', err);
        // 100점 구조: 일반 액션 에러도 스냅샷 보고
        const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
        Telemetry.reportFailure(payload.jobId, err, activeTabs[0]?.id).catch(() => { });
        send({
            type: CLIENT_EVENTS.ACTION_ERROR,
            jobId: payload.jobId,
            error: err.message,
        });
    }
}
async function updateWebAppProgress(step) {
    try {
        const tabs = await chrome.tabs.query({ url: `${CONFIG.STUDIO_URL}/*` });
        for (const tab of tabs) {
            await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: (stepName) => {
                    window.postMessage({ type: 'MAZA_INFRA_PROGRESS', step: stepName }, '*');
                },
                args: [step]
            }).catch(err => console.log('Failed to update progress on tab', tab.id, err));
        }
    }
    catch (err) {
        console.warn('Could not update progress:', err);
    }
}
//# sourceMappingURL=socket.js.map