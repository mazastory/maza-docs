"use strict";
(() => {
  // extension/sidebar/api.ts
  async function getIdeaVaultCount() {
    const storage = await chrome.storage.local.get(["mazaToken", "mazaOrigin"]);
    if (!storage.mazaToken) return null;
    const origin = storage.mazaOrigin?.replace(/\/$/, "") || "";
    const apiBase = origin ? `${origin}/api` : "https://mazastudio.kr/api";
    const res = await fetch(`${apiBase}/scrap/count`, {
      headers: { "Authorization": `Bearer ${storage.mazaToken}` }
    });
    if (!res.ok) return null;
    const data = await res.json();
    return typeof data?.count === "number" ? data.count : 0;
  }

  // extension/sidebar.ts
  console.log("[MAZA OS] Sidebar v1.2.0 Ready.");
  document.addEventListener("DOMContentLoaded", () => {
    const logList = document.getElementById("log-list");
    const statusText = document.getElementById("engine-status");
    const activeTaskEl = document.getElementById("active-task");
    const userEmailEl = document.getElementById("user-email");
    const tokenStatusEl = document.getElementById("token-status");
    const vaultCountEl = document.getElementById("vault-count");
    const geminiActive = document.getElementById("gemini-active");
    const geminiCard = document.getElementById("method-gemini");
    const logClearBtn = document.getElementById("log-clear");
    const clipperOverlay = document.getElementById("clipper-overlay");
    const clipperClose = document.getElementById("clipper-close");
    const clipperText = document.getElementById("clipper-text");
    const clipperMemo = document.getElementById("clipper-memo");
    const clipperSaveBtn = document.getElementById("clipper-save-btn");
    const clipperSaveText = document.getElementById("clipper-save-text");
    let currentScrapPayload = null;
    function showClipper(payload) {
      if (!clipperOverlay || !clipperText || !clipperMemo) return;
      currentScrapPayload = payload;
      clipperText.textContent = `"${payload.content}"`;
      clipperMemo.value = "";
      clipperOverlay.classList.add("show");
    }
    function hideClipper() {
      if (clipperOverlay) clipperOverlay.classList.remove("show");
      currentScrapPayload = null;
    }
    function addLog(message) {
      if (!logList) return;
      const now = /* @__PURE__ */ new Date();
      const timeStr = `${now.getHours()}:${String(now.getMinutes()).padStart(2, "0")}`;
      const div = document.createElement("div");
      div.className = "log-item";
      const timeSpan = document.createElement("span");
      timeSpan.className = "log-time";
      timeSpan.textContent = timeStr;
      div.appendChild(timeSpan);
      div.appendChild(document.createTextNode(` ${message}`));
      logList.insertBefore(div, logList.firstChild);
    }
    async function updateVaultCount() {
      if (!vaultCountEl) return;
      try {
        const count = await getIdeaVaultCount();
        if (count !== null) {
          vaultCountEl.textContent = `${count}\uAC1C \uC800\uC7A5\uB428`;
        }
      } catch {
      }
    }
    async function updateConnectionInfo() {
      chrome.storage.local.get(["mazaToken", "mazaUserEmail"], (data) => {
        if (tokenStatusEl && userEmailEl) {
          if (data.mazaToken) {
            tokenStatusEl.textContent = "\uC5F0\uACB0\uB428";
            tokenStatusEl.className = "badge badge-success";
            userEmailEl.textContent = data.mazaUserEmail || "\uB85C\uADF8\uC778\uB428";
            updateVaultCount();
          } else {
            tokenStatusEl.textContent = "\uC5F0\uACB0 \uB04A\uAE40";
            tokenStatusEl.className = "badge badge-error";
            userEmailEl.textContent = "\uB85C\uADF8\uC778 \uD544\uC694";
            if (vaultCountEl) vaultCountEl.textContent = "0\uAC1C \uC800\uC7A5\uB428";
          }
        }
      });
    }
    async function detectCurrentTab() {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const isGemini = tab?.url?.includes("gemini.google.com") ?? false;
        if (geminiActive) geminiActive.style.display = isGemini ? "flex" : "none";
        if (geminiCard) {
          if (isGemini) {
            geminiCard.classList.add("active-page");
          } else {
            geminiCard.classList.remove("active-page");
          }
        }
      } catch {
      }
    }
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.type === "TASK_STARTED") {
        if (activeTaskEl) {
          activeTaskEl.textContent = `${msg.taskType} \uC2E4\uD589 \uC911...`;
          activeTaskEl.style.color = "var(--text)";
        }
        if (statusText) statusText.textContent = `Running: ${msg.taskType}`;
        addLog(`Task Started: ${msg.taskType}`);
      }
      if (msg.type === "TASK_LOG") {
        addLog(msg.message);
      }
      if (msg.type === "TASK_PENDING") {
        const card = document.getElementById("pending-task-card");
        const title = document.getElementById("pending-task-title");
        if (card && title) {
          card.style.display = "block";
          title.textContent = msg.task.payload.title;
          addLog(`Dispatcher: targeting ${msg.task.domain}`);
        }
      }
      if (msg.type === "MAZA_AUTOPILOT_SYNC") {
        if (activeTaskEl) {
          activeTaskEl.textContent = `Orchestrating: ${msg.payload.targetDomain}`;
          activeTaskEl.style.color = "var(--primary)";
        }
        addLog(`Sync: Target \u2192 ${msg.payload.targetDomain}`);
      }
      if (msg.type === "TASK_CLEARED") {
        const card = document.getElementById("pending-task-card");
        if (card) card.style.display = "none";
        if (activeTaskEl) {
          activeTaskEl.textContent = "\uB300\uAE30 \uC911 \u2014 Standby";
          activeTaskEl.style.color = "var(--muted)";
        }
        if (statusText) statusText.textContent = "OS Engine Polling...";
        addLog("Draft Cleared.");
      }
      if (msg.type === "MAZA_IDEA_SAVED") {
        addLog(`\u{1F4A1} \uC544\uC774\uB514\uC5B4 \uAE08\uACE0 \uC800\uC7A5: ${(msg.title || "").substring(0, 30)}...`);
        updateVaultCount();
      }
      if (msg.type === "MAZA_SCRAP_INTENT") {
        showClipper(msg.payload);
      }
    });
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.mazaToken || changes.mazaUserEmail) {
        updateConnectionInfo();
      }
    });
    chrome.tabs.onActivated.addListener(() => {
      updateConnectionInfo();
      detectCurrentTab();
    });
    chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
      if (changeInfo.status === "complete") {
        updateConnectionInfo();
        detectCurrentTab();
      }
    });
    document.getElementById("manual-inject-btn")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "MANUAL_INJECT_REQUEST" }).then(() => {
        addLog("Manual Injection Requested...");
      }).catch((err) => {
        const message = err instanceof Error ? err.message : String(err);
        addLog(`Manual injection request failed: ${message}`);
      });
    });
    document.getElementById("open-studio")?.addEventListener("click", () => {
      chrome.storage.local.get("mazaOrigin", (data) => {
        const origin = data.mazaOrigin || "";
        const url = origin.includes("localhost") ? "http://localhost:5174" : "https://mazastudio.kr";
        chrome.tabs.create({ url });
      });
    });
    document.getElementById("open-vault")?.addEventListener("click", () => {
      chrome.storage.local.get("mazaOrigin", (data) => {
        const origin = data.mazaOrigin || "";
        const url = origin.includes("localhost") ? "http://localhost:5174/idea-vault" : "https://mazastudio.kr/idea-vault";
        chrome.tabs.create({ url });
      });
    });
    document.getElementById("start-manual")?.addEventListener("click", () => {
      addLog("Force Polling Requested...");
      chrome.runtime.sendMessage({ type: "FORCE_POLLING" }).catch((err) => {
        const message = err instanceof Error ? err.message : String(err);
        addLog(`Force polling request failed: ${message}`);
      });
    });
    logClearBtn?.addEventListener("click", () => {
      if (logList) {
        logList.innerHTML = "";
      }
      addLog("Event log cleared.");
    });
    clipperClose?.addEventListener("click", () => {
      hideClipper();
      chrome.storage.local.remove("pendingScrap");
    });
    clipperSaveBtn?.addEventListener("click", async () => {
      if (!currentScrapPayload) return;
      try {
        const storage = await chrome.storage.local.get(["mazaToken", "mazaOrigin"]);
        if (!storage.mazaToken) {
          addLog("Error: Not logged in");
          return;
        }
        if (clipperSaveText) clipperSaveText.textContent = "\uC800\uC7A5 \uC911...";
        const origin = storage.mazaOrigin?.replace(/\/$/, "") || "";
        const apiBase = origin ? `${origin}/api` : "https://mazastudio.kr/api";
        const memo = clipperMemo ? clipperMemo.value : "";
        const finalContent = currentScrapPayload.content + (memo ? `

[\uBA54\uBAA8]
${memo}` : "");
        const res = await fetch(`${apiBase}/scrap`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${storage.mazaToken}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            ...currentScrapPayload,
            content: finalContent
          })
        });
        if (res.ok) {
          if (clipperSaveText) clipperSaveText.textContent = "\u{1F389} \uC800\uC7A5 \uC644\uB8CC!";
          addLog(`\u{1F4A1} \uC544\uC774\uB514\uC5B4 \uAE08\uACE0 \uC800\uC7A5: ${currentScrapPayload.content.substring(0, 20)}...`);
          updateVaultCount();
          setTimeout(() => {
            hideClipper();
            if (clipperSaveText) clipperSaveText.textContent = "\uAE08\uACE0\uC5D0 \uC800\uC7A5\uD558\uAE30";
          }, 1200);
        } else {
          throw new Error(`Status ${res.status}`);
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        addLog(`Save error: ${message}`);
        if (clipperSaveText) clipperSaveText.textContent = "\uC800\uC7A5 \uC2E4\uD328 (\uC7AC\uC2DC\uB3C4)";
      } finally {
        chrome.storage.local.remove("pendingScrap");
      }
    });
    updateConnectionInfo();
    detectCurrentTab();
    chrome.storage.local.get(["pendingScrap"], (data) => {
      if (data.pendingScrap) {
        showClipper(data.pendingScrap);
        chrome.storage.local.remove("pendingScrap");
      }
    });
  });
})();
//# sourceMappingURL=sidebar.js.map
