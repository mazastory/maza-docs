// @ts-nocheck
/**
 * Maza Bridge v3 — content/injector.js
 * 컨텐츠 스크립트 진입점
 *
 * 원칙:
 * - MutationObserver 없음
 * - setInterval 없음
 * - 오직 background의 명령을 기다렸다가 실행
 */

'use strict';

// 중복 로드 방지
if (window.__MAZA_INJECTOR_LOADED__) {
  console.log('[Maza Bridge] Content script already loaded.');
} else {
  window.__MAZA_INJECTOR_LOADED__ = true;

  // ── ESM Module Bootstrap ───────────────────────────────
  // Manifest V3 Content Scripts don't support top-level imports.
  // We use dynamic import() to load our modules as valid ESM.
  const bootstrap = async () => {
    try {
      // Background와 통신 가능한 extension context URL 사용
      const scripts = [
        'content/domActions.js',
        'content/detectors.js',
        'content/extractors.js'
      ];

      for (const script of scripts) {
        // Cache busting to ensure latest code is loaded
        const url = chrome.runtime.getURL(`${script}?t=${Date.now()}`);
        await import(url);
      }
      console.log('[Maza Bridge] 📦 Modules bootstrapped via Dynamic Import');
    } catch (err) {
      console.error('[Maza Bridge] ❌ Bootstrap failed:', err);
    }
  };

  bootstrap();

  // ── Background 명령 수신 ────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'PING') {
      sendResponse({ ok: true });
      return;
    }

    if (msg.type !== 'RUN_DOM_ACTION') return false;

    async function retryWithBackoff(fn, retries = 3, baseDelay = 1500) {
      let attempt = 0;
      while (attempt < retries) {
        try {
          return await fn();
        } catch (error) {
          attempt++;
          console.warn(`[Maza Bridge] DOM Action failed, retrying (${attempt}/${retries})...`, error);
          if (attempt >= retries) throw error;
          // Exponential backoff
          await new Promise(r => setTimeout(r, baseDelay * Math.pow(2, attempt - 1)));
        }
      }
    }

    (async () => {
      try {
        // window.MAZA_DOM이 로드될 때까지 잠깐 대기
        const start = Date.now();
        while (!window.MAZA_DOM && Date.now() - start < 3000) {
          await new Promise(r => setTimeout(r, 100));
        }

        if (!window.MAZA_DOM) {
          throw new Error('MAZA_DOM not ready');
        }

        const result = await retryWithBackoff(() => window.MAZA_DOM.run(msg.action, msg.data || {}));
        sendResponse({ ok: true, result, jobId: msg.jobId });
      } catch (err) {
        console.error('[Maza Bridge] DOM action failed:', err);
        sendResponse({ ok: false, error: err.message, jobId: msg.jobId });
      }
    })();

    return true; // 비동기 응답
  });

  // ── 발행 완료 자동 감지 ────────────────────────────────
  // 발행 후 리다이렉트된 URL 감지 → background로 보고
  const checkIfPublished = () => {
    if (chrome.runtime?.id && window.MAZA_DETECT && window.MAZA_DETECT.isPublishedPage()) {
      chrome.runtime.sendMessage({
        type: 'PAGE_PUBLISHED',
        url: window.location.href,
        title: document.title,
      }).catch(() => {});
    }
  };

  // 페이지 로드 완료 후 1회 확인
  if (document.readyState === 'complete') {
    setTimeout(checkIfPublished, 500);
  } else {
    window.addEventListener('load', () => setTimeout(checkIfPublished, 500));
  }

  // ── 인증 정보 동기화 ────────────────────────────────
  window.addEventListener('message', (event) => {
    // 보안: 로컬호스트나 익스텐션 내부 발송 메시지만 허용
    if (!event.origin.includes('localhost') && !event.origin.includes('127.0.0.1') && !event.origin.includes(chrome.runtime.id)) {
      return;
    }

    if (event.data.type === 'MAZA_SYNC_AUTH') {
      if (!chrome.runtime?.id) return; // 익스텐션 재로드 시 에러 방지
      
      const { token, userId, email } = event.data;
      chrome.storage.local.set({ 
        mazaToken: token, 
        mazaUserId: userId, 
        mazaEmail: email,
        lastSync: Date.now()
      });
      console.log('[Maza Bridge] 🔑 Auth token synced and stored.');
    }
  });

  // ── 핸드쉐이크: 준비 완료 알림 ──
  const reportReady = () => {
    if (!chrome.runtime?.id) return;
    
    // 1. Background로 직접 보고 (Event-driven)
    chrome.runtime.sendMessage({ 
      type: 'CONTENT_READY', 
      url: window.location.href 
    }).catch(() => {});

    // 2. 웹앱으로 보고 (localhost 한정)
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
      window.postMessage({ type: 'MAZA_EXT_READY' }, '*');
    }
  };

  if (document.readyState === 'complete') {
    reportReady();
  } else {
    window.addEventListener('load', reportReady);
  }

  console.log('[Maza Bridge] ✅ Content script ready:', window.location.hostname);
}
