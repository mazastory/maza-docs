export interface JobPayload {
  id: string;
  url: string;
  title: string;
  html: string;
  autoClickWrite?: boolean;
  steps?: string[];
  selectors?: Record<string, string>;
  tabId?: number;
}

export interface Job {
  id: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  retryCount: number;
  maxRetries: number;
  priority: number;
  createdAt: number;
  payload: JobPayload;
}

export type FSMState = 
  | 'IDLE' 
  | 'NAVIGATING' 
  | 'WAITING_EDITOR' 
  | 'EXECUTING' 
  | 'VERIFYING' 
  | 'PUBLISHING' 
  | 'HEALING' 
  | 'VISUAL_FALLBACK'
  | 'DONE' 
  | 'ERROR';

export interface RPCMessage {
  type: string;
  action?: string;
  jobId?: string;
  data?: any;
  method?: string;
  params?: any;
  [key: string]: any;
}
