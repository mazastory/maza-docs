// @ts-nocheck
// This script runs in the MAIN world, bypassing the extension's isolated world restrictions.
// It listens for a custom event from the content script, injects the code into Monaco/CodeMirror, and saves.

document.addEventListener('MAZA_INJECT_START', (e) => {
  try {
    const data = e.detail;
    let content = '';
    let isMonaco = false;
    let isCodeMirror = false;
    
    if (window.monaco && window.monaco.editor && window.monaco.editor.getModels().length > 0) {
      isMonaco = true;
      content = window.monaco.editor.getModels()[0].getValue();
    } else if (document.querySelector('.CodeMirror')) {
      isCodeMirror = true;
      content = document.querySelector('.CodeMirror').CodeMirror.getValue();
    } else {
      throw new Error("에디터(Monaco/CodeMirror) 객체에 접근할 수 없습니다.");
    }

    const headIndex = content.indexOf("<head>");
    if (headIndex === -1) throw new Error("<head> 태그를 찾을 수 없습니다.");

    const injectHtml = data.html;

    // 1. 이미 정확히 동일한 코드가 주입되어 있는지 확인 (Idempotent)
    if (content.includes(injectHtml)) {
      document.dispatchEvent(new CustomEvent('MAZA_INJECT_PROGRESS', { detail: 'ALREADY_INJECTED' }));
      document.dispatchEvent(new CustomEvent('MAZA_INJECT_SUCCESS'));
      setTimeout(() => alert('[Maza Studio] 이미 완벽한 최신 인프라 코드가 주입되어 있습니다!\nMaza Studio 탭으로 돌아가주세요.'), 500);
      return; // 중복 주입 방지 (성공 처리 후 조기 종료)
    }

    // 2. 구버전 또는 잘못된 Maza Infra 블록 클린업
    // (이전 생성 규칙: <!-- Maza Infra --> 부터 gtag config 스크립트 끝나는 곳까지)
    const mazaBlockRegex = /<!-- Maza Infra -->[\s\S]*?<!-- Global site tag \(gtag\.js\) -->[\s\S]*?<\/script>\s*<script>[\s\S]*?<\/script>/g;
    content = content.replace(mazaBlockRegex, '');

    // 3. (혹시 남아있을 수 있는) 개별 메타/태그 찌꺼기 제거
    content = content.replace(/<meta name="google-site-verification" content="[^"]+"\s*\/?>\n?/g, '');
    content = content.replace(/<!-- Global site tag \(gtag\.js\) -->\n?/g, '');
    content = content.replace(/<script async src="https:\/\/www\.googletagmanager\.com\/gtag\/js\?id=[^"]+"><\/script>\n?/g, '');
    content = content.replace(/<script>\s*window\.dataLayer=window\.dataLayer\|\|\[\];function gtag\(\)\{dataLayer\.push\(arguments\);\}gtag\('js',new Date\(\)\);gtag\('config','[^']+'\);\s*<\/script>\n?/g, '');

    // 다시 <head> 인덱스 계산 (내용이 변경되었을 수 있으므로)
    const newHeadIndex = content.indexOf("<head>");
    if (newHeadIndex === -1) throw new Error("<head> 태그를 찾을 수 없습니다.");

    document.dispatchEvent(new CustomEvent('MAZA_INJECT_PROGRESS', { detail: 'CODE_INJECTED' }));
    
    const newContent = content.slice(0, newHeadIndex + 6) + "\n" + injectHtml + content.slice(newHeadIndex + 6);

    // 값 업데이트
    if (isMonaco) {
      window.monaco.editor.getModels()[0].setValue(newContent);
    } else if (isCodeMirror) {
      document.querySelector('.CodeMirror').CodeMirror.setValue(newContent);
    }

    // 저장 버튼 클릭
    const saveBtn = document.querySelector('.btn_apply') || document.querySelector('#btn_save') || document.querySelector('button.apply');
    if (saveBtn) {
      document.dispatchEvent(new CustomEvent('MAZA_INJECT_PROGRESS', { detail: 'SAVE_CLICKED' }));
      saveBtn.click();
      setTimeout(() => alert('[Maza Studio] 인프라 코드가 성공적으로 갱신(저장)되었습니다!\nMaza Studio 탭으로 돌아가주세요.'), 500);
    }

    document.dispatchEvent(new CustomEvent('MAZA_INJECT_SUCCESS'));
  } catch (err) {
    document.dispatchEvent(new CustomEvent('MAZA_INJECT_ERROR', { detail: err.message }));
  }
});
