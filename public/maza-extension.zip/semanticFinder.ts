/**
 * Maza Bridge v4 — content/semanticFinder.ts
 * Intelligent Element Discovery without brittle CSS selectors
 */

export const SemanticFinder = {
  /**
   * Find a button by its visible text (supports fuzzy match)
   */
  findButtonByText(text: string, root: Element | Document = document): HTMLButtonElement | null {
    const buttons = Array.from(root.querySelectorAll('button, a, input[type="button"], input[type="submit"]'));
    return (buttons.find(btn => {
      const btnText = btn.textContent?.trim().toLowerCase() || (btn as HTMLInputElement).value?.toLowerCase() || '';
      return btnText.includes(text.toLowerCase());
    }) as HTMLButtonElement) || null;
  },

  /**
   * Find an element by ARIA role and optional text
   */
  findByRole(role: string, text?: string, root: Element | Document = document): HTMLElement | null {
    const elements = Array.from(root.querySelectorAll(`[role="${role}"]`));
    if (!text) return elements[0] as HTMLElement || null;
    
    return (elements.find(el => {
      return el.textContent?.trim().toLowerCase().includes(text.toLowerCase());
    }) as HTMLElement) || null;
  },

  /**
   * Find a label's associated input
   */
  findInputByLabel(labelText: string, root: Element | Document = document): HTMLInputElement | null {
    const labels = Array.from(root.querySelectorAll('label'));
    const targetLabel = labels.find(l => l.textContent?.trim().toLowerCase().includes(labelText.toLowerCase()));
    
    if (targetLabel) {
      if (targetLabel.htmlFor) {
        return document.getElementById(targetLabel.htmlFor) as HTMLInputElement;
      }
      return targetLabel.querySelector('input, textarea, select') as HTMLInputElement;
    }
    
    // Fallback: search for inputs with placeholder
    return (root.querySelector(`input[placeholder*="${labelText}" i], textarea[placeholder*="${labelText}" i]`) as HTMLInputElement) || null;
  },

  /**
   * Find the "most likely" content editor
   */
  findEditor(root: Element | Document = document): HTMLElement | null {
    // 1. Common IDs/Classes
    const commonSelectors = [
      '[contenteditable="true"]',
      '.ProseMirror',
      '.mce-content-body',
      '#editor',
      '.editor'
    ];
    for (const sel of commonSelectors) {
      const el = root.querySelector(sel);
      if (el) return el as HTMLElement;
    }
    
    // 2. Look for large textareas or divs
    const divs = Array.from(root.querySelectorAll('div[contenteditable], textarea'));
    return (divs.sort((a, b) => b.innerHTML.length - a.innerHTML.length)[0] as HTMLElement) || null;
  },

  /**
   * Find any element by multiple heuristics with Scoring
   */
  smartFind(hint: string, root: Element | Document = document): HTMLElement | null {
    const candidates = Array.from(root.querySelectorAll('button, a, input, textarea, [role="button"], [contenteditable]'));
    const hintLower = hint.toLowerCase();
    
    const scored = candidates.map(el => {
      let score = 0;
      const text = (el.textContent || (el as any).value || (el as any).placeholder || '').trim().toLowerCase();
      const id = el.id.toLowerCase();
      const cls = el.className.toString().toLowerCase();
      const role = el.getAttribute('role')?.toLowerCase();

      // 1. Exact text match (Highest)
      if (text === hintLower) score += 100;
      else if (text.includes(hintLower)) score += 50;

      // 2. ID/Class hint match
      if (id.includes(hintLower) || cls.includes(hintLower)) score += 30;

      // 3. ARIA Role match
      if (role === hintLower || (role === 'button' && hintLower.includes('button'))) score += 20;

      // 4. Visibility boost
      const rect = el.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) score += 10;
      
      return { el, score };
    });

    const best = scored.sort((a, b) => b.score - a.score)[0];
    return best && best.score > 30 ? (best.el as HTMLElement) : null;
  }
};
