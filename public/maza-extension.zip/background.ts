/**
 * Maza Bridge v3 — background/background.js
 * Service Worker 진입점
 *
 * 원칙:
 * - Queue 없음
 * - setInterval 없음
 * - AI 로직 없음
 * - Retry 없음
 * 오직: WebSocket 연결 유지 + 메시지 라우팅
 *
 * [P0 수정] bootstrap 3중 호출 제거 — bootstrapOnce() 로 통합
 * [P1 수정] sendMessage().catch() → try/await/catch 로 안전화
 * [P1 수정] HEARTBEAT alarm period 0.5 → 1분으로 상향
 */

import { connectSocket, handleAction, send } from './socket.js';
import { safeNotify } from '../shared/utils.js';
import { handleRpcCall } from './rpcHandler.js';

// ── Persistence: Offscreen Document 관리 ───────────────
let creatingOffscreen: Promise<void> | null = null; // 생성 잠금 (Lock)

async function setupOffscreen() {
  const OFFSCREEN_PATH = 'offscreen.html';

  // 1. 이미 열려있는지 확인
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_PATH)]
  });
  if (existingContexts.length > 0) return;

  // 2. 생성 잠금 확인 (이미 진행 중이면 해당 프로미스 대기)
  if (creatingOffscreen) {
    try { await creatingOffscreen; } catch (e) {}
    return;
  }

  // 3. 생성 프로세스 시작 및 잠금
  console.log('[Maza Bridge] 🚀 Creating offscreen document...');
  creatingOffscreen = chrome.offscreen.createDocument({
    url: OFFSCREEN_PATH,
    reasons: ['LOCAL_STORAGE'],
    justification: 'Keep WebSocket connection alive for background automation'
  });

  try {
    await creatingOffscreen;
    console.log('[Maza Bridge] ✅ Offscreen document created.');
  } catch (err: any) {
    if (!err?.message?.includes('Only a single offscreen document')) {
      console.error('[Maza Bridge] Failed to create offscreen document:', err);
    }
  } finally {
    creatingOffscreen = null;
  }
}

// ── Heartbeat: Offscreen 생존 확인 ───────────────
async function initializeAlarms() {
  const alarms = await chrome.alarms.getAll();

  // [P1] periodInMinutes 0.5 → 1 (MV3 throttle 방어)
  if (!alarms.some(a => a.name === 'MAZA_HEARTBEAT')) {
    chrome.alarms.create('MAZA_HEARTBEAT', { periodInMinutes: 1 });
  }

  if (!alarms.some(a => a.name === 'MAZA_WAKEUP')) {
    chrome.alarms.create('MAZA_WAKEUP', { periodInMinutes: 1 });
  }

  // WebSocket 연결 보장
  connectSocket();
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'MAZA_HEARTBEAT') {
    // [P1] sendMessage().catch() → try/await/catch 로 안전화
    try {
      await chrome.runtime.sendMessage({ type: 'HEARTBEAT_PING' });
    } catch (e) {
      console.log('[Maza Bridge] Offscreen may be dead, restarting...');
      setupOffscreen();
    }
  }
  if (alarm.name === 'MAZA_WAKEUP') {
    setupOffscreen();
  }
});

// ── [P0] Bootstrap 통합 — 3중 호출 방지 ──────────────────
// MV3 Service Worker는 onStartup, onInstalled, 즉시 실행 3곳에서
// 모두 진입 가능하므로, 인메모리 플래그로 1회만 실행되도록 보장.
let _bootstrapped = false;

import { runtime } from '../shared/runtime.js';

async function bootstrapOnce(reason: string) {
  if (_bootstrapped) {
    console.log(`[Maza Bridge] Bootstrap skipped (already ran). trigger: ${reason}`);
    return;
  }
  _bootstrapped = true;
  console.log(`[Maza Bridge] 🚀 Bootstrap triggered by: ${reason}`);

  // 1. Ensure Runtime & APIs are ready
  await runtime.bootstrap();

  // 2. Initialize Core Services
  await setupOffscreen();
  await initializeAlarms();
}

// 3가지 진입점 모두 bootstrapOnce() 로 통합
chrome.runtime.onStartup.addListener(() => bootstrapOnce('onStartup'));
chrome.runtime.onInstalled.addListener(() => bootstrapOnce('onInstalled'));
// Service Worker 재시작 시 즉시 복구 (suspend/resume 대응)
bootstrapOnce('immediate');

// ── 컨텐츠 스크립트 ↔ 팝업 ↔ 오프스크린 메시지 처리 ──────────────────
chrome.runtime.onMessage.addListener((msg: any, sender: chrome.runtime.MessageSender, sendResponse: (response?: any) => void) => {
  // 1. 서버로부터 온 명령 처리 (Offscreen에서 중계됨)
  if (msg.type === 'RUN_ACTION') {
    handleAction(msg).then(result => {
      try { sendResponse(result); } catch (e) {}
    }).catch(err => {
      try { sendResponse({ ok: false, error: err.message }); } catch (e) {}
    });
    return true;
  }

  if (msg.type === 'PING_SERVER') {
    send({ type: 'PONG' });
    return true;
  }

  // 2. 익스텐션 상태 확인
  if (msg.type === 'EXTENSION_STATUS') {
    sendResponse({ ok: true, alive: true });
    return true;
  }

  // 3. Offscreen RPC Call Handling
  if (msg.type === 'RPC_CALL') {
    handleRpcCall(msg.method, msg.params)
      .then(res => sendResponse(res))
      .catch(err => sendResponse({ ok: false, error: err.message }));
    return true; // Keep message channel open for async response
  }

  if (msg.type === 'MANUAL_PUBLISH') {
    console.log('[Maza Bridge] 🖱️ Manual publish requested for:', msg.post.id);

    const post = msg.post;
    const content = post.content || {};

    // 플랫폼별 URL 생성
    let url = '';
    if (content.platform === 'tistory') {
      url = `https://${content.domain}/manage/newpost`;
    } else if (content.platform === 'naver') {
      const naverId = content.domain.split('.')[0];
      url = `https://blog.naver.com/${naverId}?PostWrite.naver`;
    }

    if (!content.domain || !url) {
      safeNotify('publish-error', {
        type: 'basic',
        iconUrl: '/icons/icon128.png',
        title: '발행 불가',
        message: '도메인 또는 플랫폼 정보가 누락되었습니다.',
      });
      return;
    }

    // Forward to Offscreen Orchestrator as high priority
    chrome.runtime.sendMessage({
      type: 'MANUAL_JOB_REQUEST',
      jobId: `manual-${post.id}-${Date.now()}`,
      data: {
        postId: post.id,
        url: url,
        title: content.title,
        html: content.html,
        tags: content.tags,
        selectors: content.selectors || null,
        autoClickWrite: true
      }
    });
    
    sendResponse({ ok: true, message: 'Job enqueued' });
    return true;
  }
});
