import { PlatformAdapter } from './index.js';

/**
 * Maza Bridge v4 — platforms/tistory.ts
 * 
 * 티스토리 전용 어댑터 및 Self-Healing 셀렉터 관리
 */

export const TistoryAdapter: PlatformAdapter = {
  name: 'tistory',
  
  // 기본 셀렉터 (우선순위 순)
  selectors: {
    title: [
      '#post-title-dashboard',
      'input.tf_g[placeholder*="제목"]',
      'textarea.tf_g[placeholder*="제목"]',
      'input[placeholder*="제목"]',
      'textarea[placeholder*="제목"]',
      '.title_area input',
      '.title_area textarea',
      '#title',
      'input[name="title"]'
    ],
    tags: [
      'input#tagText',
      'input[name="tagText"]',
      'input[placeholder*="태그"]',
      'input[placeholder*="tag"]',
      '.tag_g input',
      '.tf_tag'
    ],
    editor: [
      '.ProseMirror[contenteditable="true"]',
      '.content_editable',
      '.ke-editable',
      '.ke-content',
      '#editor-content',
      '[contenteditable="true"]'
    ],
    iframe: '#editor-content-iframe',
    publish: [
      'button[data-testid="btn-publish"]',
      '.btn_publish',
      'button.publish',
      'button:contains("발행")'
    ]
  },

  /**
   * 에디터 진입 전 특수 동작 (예: 자동 클릭)
   */
  async preAction(tabId, url) {
    if (url.includes('/manage') && !url.includes('/post/write')) {
      return { action: 'CLICK_DASHBOARD_WRITE' };
    }
    return null;
  },

  /**
   * 주입 후 검증 로직 (100점 구조: E-E-A-T 기반 실제 데이터 존재 확인)
   */
  async verify(tabId) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, { 
        type: 'RUN_DOM_ACTION', 
        action: 'VERIFY_CONTENT_DOM',
        data: {
          minTitleLength: 2,
          minBodyLength: 100
        }
      });
      return response?.ok === true;
    } catch (err: any) {
      console.warn('[TistoryAdapter] Verification failed:', err.message);
      return false;
    }
  }
};
