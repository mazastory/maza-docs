/**
 * Maza Bridge v4 — background/rpcHandler.js
 * RPC Handler for Offscreen Document to delegate Chrome Extension API calls
 */

import { delay } from '../shared/utils.js';
import { NavigationManager } from './engine/navigationManager.js';
import { getPlatformAdapter } from './platforms/index.js';

const readyResolvers = new Map<number, (value: boolean) => void>();

chrome.runtime.onMessage.addListener((msg: any, sender: chrome.runtime.MessageSender) => {
  if (msg.type === 'CONTENT_READY' && sender.tab?.id) {
    const resolve = readyResolvers.get(sender.tab.id);
    if (resolve) {
      console.log(`[RPC] 📡 Received CONTENT_READY from tab ${sender.tab.id}`);
      resolve(true);
      readyResolvers.delete(sender.tab.id);
    }
  }
});

export async function handleRpcCall(method: string, params: any): Promise<any> {
  console.log(`[RPC] Executing ${method}`, params);
  
  switch (method) {
    case 'OPEN_EDITOR_TAB':
      return await openEditorTab(params.url);
      
    case 'WAIT_EDITOR_READY':
      return await waitEditorReady(params.tabId, params.autoClick, params.timeout);
      
    case 'INJECT_CONTENT':
      return await injectContent(params.tabId, params.data);
      
    case 'VERIFY_CONTENT':
      return await verifyContent(params.tabId);
      
    case 'TAKE_SNAPSHOT':
      return await takeSnapshot(params.tabId);
      
    case 'TAKE_SCREENSHOT':
      return await takeScreenshot(params.tabId);
      
    case 'CLICK_COORDINATES':
      return await clickCoordinates(params.tabId, params.x, params.y);
      
    case 'STORAGE_GET':
      return new Promise((resolve) => {
        chrome.storage.local.get(params.keys, (result) => resolve({ ok: true, result }));
      });
      
    case 'STORAGE_SET':
      return new Promise((resolve) => {
        chrome.storage.local.set(params.data, () => resolve({ ok: true }));
      });
      
    default:
      throw new Error(`Unknown RPC method: ${method}`);
  }
}

async function openEditorTab(url: string): Promise<{ ok: boolean; tabId: number }> {
  const tab: chrome.tabs.Tab = await new Promise((resolve, reject) => {
    chrome.tabs.create({ url, active: true }, (tab) => {
      if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
      else resolve(tab);
    });
  });
  
  if (!tab.id) throw new Error('Failed to create tab with valid ID');

  // Use NavigationManager to wait for initial load
  const controller = new AbortController();
  await (NavigationManager as any).navigateAndWait(tab.id, url, controller.signal);
  return { ok: true, tabId: tab.id };
}

async function waitEditorReady(tabId: number, autoClick: boolean, timeoutMs: number = 60000): Promise<{ ok: boolean }> {
  // Handshake implementation
  const handshakePromise = new Promise((resolve, reject) => {
    readyResolvers.set(tabId, resolve);
    
    const timer = setTimeout(() => {
      readyResolvers.delete(tabId);
      reject(new Error('에디터 로딩 타임아웃 (Event-driven)'));
    }, timeoutMs);

    // Try a ping just in case it's already ready
    safeSendMessage(tabId, { type: 'PING' }, 2000)
      .then((res: any) => {
        if (res && res.ok) {
          clearTimeout(timer);
          readyResolvers.delete(tabId);
          resolve(true);
        }
      })
      .catch(() => {});
  });

  await handshakePromise;

  // Platform specific pre-actions
  const tab: chrome.tabs.Tab = await new Promise(r => chrome.tabs.get(tabId, r));
  const adapter = getPlatformAdapter(tab.url || '');
  const preAction = await adapter.preAction(tabId, tab.url || '');
  
  if (preAction?.action === 'CLICK_DASHBOARD_WRITE' && autoClick) {
    await safeSendMessage(tabId, { type: 'MAZA_RUN_ACTION', action: 'CLICK_DASHBOARD_WRITE' }).catch(() => {});
    await delay(2000);
    // Recursively wait again if redirected
    await waitEditorReady(tabId, false, timeoutMs); 
  }

  return { ok: true };
}

async function injectContent(tabId: number, data: any): Promise<{ ok: boolean; result: any }> {
  await delay(1000);
  
  const tab: chrome.tabs.Tab = await new Promise(r => chrome.tabs.get(tabId, r));
  const adapter = getPlatformAdapter(tab.url || '');

  const result: any = await safeSendMessage(tabId, {
    type: 'RUN_DOM_ACTION',
    action: 'PUBLISH_CONTENT_DOM',
    data: { ...data, selectors: adapter.selectors }
  });

  if (!result || !result.ok) {
    throw new Error(result?.error || '본문 주입 실패');
  }
  return { ok: true, result };
}

async function verifyContent(tabId: number): Promise<{ ok: boolean; isValid: boolean }> {
  const tab: chrome.tabs.Tab = await new Promise(r => chrome.tabs.get(tabId, r));
  const adapter = getPlatformAdapter(tab.url || '');
  
  const isValid = await adapter.verify(tabId);
  return { ok: true, isValid };
}

async function takeSnapshot(tabId: number): Promise<{ ok: boolean; html: string }> {
  const result: any = await safeSendMessage(tabId, {
    type: 'RUN_DOM_ACTION',
    action: 'TAKE_SNAPSHOT_DOM'
  });
  return { ok: true, html: result?.html };
}

async function takeScreenshot(tabId: number): Promise<{ ok: boolean; dataUrl: string }> {
  const tab: chrome.tabs.Tab = await new Promise(r => chrome.tabs.get(tabId, r));
  if (!tab.windowId) throw new Error('Tab has no windowId');
  
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 50 });
  return { ok: true, dataUrl };
}

async function clickCoordinates(tabId: number, x: number, y: number): Promise<{ ok: boolean }> {
  // 1. Get viewport metadata from the tab
  const [viewport]: any[] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => ({
      width: window.innerWidth,
      height: window.innerHeight,
      dpr: window.devicePixelRatio || 1
    })
  });

  const { width, height, dpr } = viewport.result;
  
  // 2. Map 0-1000 coordinates to viewport pixels
  const clickX = Math.round((x / 1000) * width);
  const clickY = Math.round((y / 1000) * height);

  console.log(`[RPC] 🎯 Visual Click: (${x},${y}) -> Viewport: (${clickX},${clickY}) DPR: ${dpr}`);

  // 3. Dispatch via Debugger (Uses physical pixels, so multiply by DPR)
  await chrome.debugger.attach({ tabId }, '1.3');
  
  try {
    const params = {
      x: clickX * dpr,
      y: clickY * dpr,
      button: 'left',
      clickCount: 1
    };

    await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', { ...params, type: 'mousePressed' });
    await chrome.debugger.sendCommand({ tabId }, 'Input.dispatchMouseEvent', { ...params, type: 'mouseReleased' });
    
    // Optional: add a small delay to let UI react
    await delay(500);
  } finally {
    await chrome.debugger.detach({ tabId });
  }

  return { ok: true };
}

async function safeSendMessage(tabId: number, message: any, timeout: number = 60000): Promise<any> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`메시지 응답 타임아웃 (${message.type})`));
    }, timeout);

    chrome.tabs.sendMessage(tabId, message, (response) => {
      clearTimeout(timer);
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}
