// @ts-nocheck
/**
 * Maza Bridge v4 — background/engine/navigationManager.js
 * 고도화된 탭 내비게이션 관리자
 * 
 * 기능:
 * - 페이지 로딩 안정성 검사 (Stability Check)
 * - 리다이렉트 루프 감지 기초
 * - 타임아웃 및 중단 처리
 */

export class NavigationManager {
  /**
   * 탭을 특정 URL로 이동시키고 완전히 로드될 때까지 대기
   */
  static async navigateAndWait(tabId, url, signal) {
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');

    console.log(`[NavigationManager] 🌐 Navigating tab ${tabId} to ${url}`);

    return new Promise((resolve, reject) => {
      let isResolved = false;

      const cleanup = () => {
        chrome.tabs.onUpdated.removeListener(listener);
        signal?.removeEventListener('abort', onAbort);
      };

      const onAbort = () => {
        if (isResolved) return;
        isResolved = true;
        cleanup();
        reject(new DOMException('Aborted', 'AbortError'));
      };

      const listener = (updatedTabId, changeInfo, tab) => {
        if (updatedTabId !== tabId) return;

        // 100점 구조: 'complete' 상태 확인 후 추가 안정성 대기
        if (changeInfo.status === 'complete') {
          console.log(`[NavigationManager] ✅ Tab ${tabId} navigation complete.`);
          isResolved = true;
          cleanup();
          resolve(tab);
        }
      };

      // 리스너 등록
      chrome.tabs.onUpdated.addListener(listener);
      signal?.addEventListener('abort', onAbort);

      // 실제 이동 명령
      chrome.tabs.update(tabId, { url }).catch(err => {
        isResolved = true;
        cleanup();
        reject(err);
      });

      // 타임아웃 (30초)
      setTimeout(() => {
        if (!isResolved) {
          isResolved = true;
          cleanup();
          reject(new Error('내비게이션 타임아웃 (30초)'));
        }
      }, 30000);
    });
  }

  /**
   * 탭이 특정 상태(URL 포함 여부 등)가 될 때까지 대기
   */
  static async waitForUrl(tabId, urlPart, timeout = 15000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (!chrome.runtime?.id) return false;
      const tab = await new Promise(r => chrome.tabs.get(tabId, r)).catch(() => null);
      if (tab?.url?.includes(urlPart)) return true;
      await new Promise(r => setTimeout(r, 1000));
    }
    return false;
  }
}
