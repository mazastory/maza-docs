// @ts-nocheck
/**
 * Maza Bridge v3 — offscreen.js
 * WebSocket 브릿지 (Offscreen Document에서 실행)
 *
 * [P1 강화] Zombie socket 방지 — 재연결 전 기존 ws 명시적 close
 * [P1 강화] Reconnect 횟수 제한 (최대 10회, 이후 수동 복구 대기)
 * [P1 강화] ping/pong 타임아웃 — 30초 응답 없으면 소켓 강제 재연결
 * [기존 유지] Exponential Backoff (3s → 6s → 12s → 최대 30s) + Jitter
 */
import { CLIENT_EVENTS } from './shared/protocol.js';
import { CONFIG } from './shared/config.js';
import { orchestrator } from './offscreen/orchestrator.js';
const WS_URL = CONFIG.WS_URL;
const MAX_RECONNECT_ATTEMPTS = 10;
let ws = null;
let reconnectDelay = 3000;
let reconnectCount = 0;
let reconnectTimer = null;
let pingTimer = null;
/**
 * Zombie Socket 정리 — 기존 ws를 강제 종료하고 이벤트 핸들러 제거
 */
function destroySocket() {
    if (ws) {
        ws.onopen = null;
        ws.onmessage = null;
        ws.onerror = null;
        ws.onclose = null;
        try {
            ws.close();
        }
        catch (e) { }
        ws = null;
    }
    // ping 타이머 정리
    clearTimeout(pingTimer);
    pingTimer = null;
}
/**
 * Keepalive Ping — 프록시/NAT idle 타임아웃 방지용
 * OPEN 상태이면 연결이 살아있다고 신뢰. pong 응답 대기하지 않음.
 * 실제 단절 감지는 ws.onclose 에만 의존.
 */
function schedulePing() {
    clearTimeout(pingTimer);
    pingTimer = setTimeout(() => {
        if (!ws || ws.readyState !== WebSocket.OPEN)
            return;
        try {
            ws.send(JSON.stringify({ type: CLIENT_EVENTS.PONG, timestamp: Date.now() }));
            console.log('[Maza Offscreen] 💓 Keepalive ping sent.');
        }
        catch (e) {
            console.warn('[Maza Offscreen] Ping send failed:', e);
        }
        // 다음 ping 재예약 (pong 타임아웃 없음 — 살아있는 연결 오판 차단)
        schedulePing();
    }, 30000); // 30초마다 keepalive
}
function connect() {
    // 1. 재연결 횟수 초과 시 더 이상 시도하지 않음
    if (reconnectCount >= MAX_RECONNECT_ATTEMPTS) {
        console.error(`[Maza Offscreen] ❌ Max reconnect attempts reached. Waiting for manual recovery.`);
        return;
    }
    // 2. 이미 연결 중이거나 연결된 상태면 스킵
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
        console.log('[Maza Offscreen] Socket already active or connecting. Skipping connect().');
        return;
    }
    // 3. 기존 예약된 타이머가 있다면 취소 (중복 실행 방지)
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
    // Zombie socket 정리 후 새 연결 생성
    destroySocket();
    reconnectCount++;
    console.log(`[Maza Offscreen] 🔌 Connecting to WebSocket... (attempt ${reconnectCount}/${MAX_RECONNECT_ATTEMPTS})`);
    ws = new WebSocket(WS_URL);
    ws.onopen = () => {
        console.log('[Maza Offscreen] ✅ Connected to server.');
        reconnectDelay = 3000; // 성공 시 지연 초기화
        reconnectCount = 0; // 성공 시 횟수 초기화
        schedulePing(); // ping 사이클 시작
    };
    ws.onmessage = (event) => {
        // 메시지 수신 시 ping 사이클 재시작 (idle 방지)
        schedulePing();
        try {
            const payload = JSON.parse(event.data);
            console.log('[Maza Offscreen] 📥 Received:', payload.type || payload.action);
            // Route actions directly to orchestrator
            if (payload.action === 'PUBLISH_POST') {
                orchestrator.enqueuePublishJob(payload.jobId, payload.data);
            }
            else if (payload.action === 'INJECT_INFRA') {
                orchestrator.enqueueInfraJob(payload.jobId, payload.data);
            }
            else {
                // Fallback for other commands to Service Worker
                chrome.runtime.sendMessage(payload).catch(() => { });
            }
        }
        catch (err) {
            console.error('[Maza Offscreen] Parsing error:', err);
        }
    };
    ws.onerror = (err) => {
        console.warn('[Maza Offscreen] WS Error:', err);
        // onerror 이후 onclose가 반드시 호출되므로 여기서는 별도 처리 불필요
    };
    ws.onclose = () => {
        clearTimeout(pingTimer);
        if (reconnectCount >= MAX_RECONNECT_ATTEMPTS) {
            console.error('[Maza Offscreen] ❌ Too many reconnect failures. Stopped.');
            return;
        }
        // Exponential Backoff + Jitter (서버 동시 재연결 분산)
        const jitter = Math.floor(Math.random() * 1000);
        const totalDelay = reconnectDelay + jitter;
        console.log(`[Maza Offscreen] ❌ Disconnected. Reconnecting in ${(totalDelay / 1000).toFixed(1)}s... (attempt ${reconnectCount}/${MAX_RECONNECT_ATTEMPTS})`);
        clearTimeout(reconnectTimer);
        reconnectTimer = setTimeout(connect, totalDelay);
        // Exponential Backoff 최대 60초
        reconnectDelay = Math.min(reconnectDelay * 2, 60000);
    };
}
// ── Heartbeat & Message Router ──────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'HEARTBEAT_PING') {
        if (ws && ws.readyState === WebSocket.OPEN) {
            try {
                ws.send(JSON.stringify({ type: CLIENT_EVENTS.PONG, timestamp: Date.now() }));
            }
            catch (e) { }
        }
        else if (ws && (ws.readyState === WebSocket.CONNECTING)) {
            console.log('[Maza Offscreen] WS is still connecting, skipping HEARTBEAT.');
        }
        else {
            // 런타임이 아직 부트스트랩 중이라면 재연결 시도하지 않음
            runtime.ready().then(() => {
                // 부트스트랩 완료 후에만 연결 상태를 보고 결정
                if (!ws || (ws.readyState !== WebSocket.OPEN && ws.readyState !== WebSocket.CONNECTING)) {
                    console.warn('[Maza Offscreen] WS disconnected on HEARTBEAT. Reconnecting...');
                    reconnectCount = 0;
                    reconnectDelay = 3000;
                    connect();
                }
            });
        }
        return;
    }
    if (msg.type === 'INJECT_INFRA_REQUEST') {
        orchestrator.enqueueInfraJob(msg.jobId, msg.data);
        return;
    }
    if (msg.type === 'MANUAL_JOB_REQUEST') {
        orchestrator.enqueuePublishJob(msg.jobId, msg.data, true);
        return;
    }
    if (msg.type === 'SEND_TO_SERVER') {
        if (ws && ws.readyState === WebSocket.OPEN) {
            try {
                ws.send(JSON.stringify(msg.payload));
            }
            catch (e) {
                console.warn('[Maza Offscreen] Failed to send message:', e);
            }
        }
        else {
            console.warn('[Maza Offscreen] ⚠️ Cannot send: WS not connected');
        }
        return;
    }
});
// Listen for orchestrator updates and forward to server
window.addEventListener('MAZA_ORCHESTRATOR_UPDATE', (e) => {
    const { jobId, state, progress, error, task, log, replayData } = e.detail;
    if (ws && ws.readyState === WebSocket.OPEN) {
        try {
            ws.send(JSON.stringify({
                type: CLIENT_EVENTS.ACTION_PROGRESS,
                jobId,
                state,
                progress,
                error,
                task,
                log,
                replayData
            }));
        }
        catch (err) { }
    }
});
import { runtime } from './shared/runtime.js';
// Start orchestrator and WebSocket after Runtime is ready
runtime.bootstrap().then(() => {
    orchestrator.start();
    connect();
}).catch(err => {
    console.error('[Maza Offscreen] ❌ Failed to bootstrap runtime:', err);
});
//# sourceMappingURL=offscreen.js.map